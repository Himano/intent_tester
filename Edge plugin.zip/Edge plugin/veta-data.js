window.VETA_CHATBOT_DOCS =


[
  {
    "guid": "715gc233-b97d-4d4g-gce9-ef8f4651e7f6",
    "id": "114505",
    "title": "Går det att stereopara flera likadana SYMFONISK produkter med varandra?",
    "keywords": [
      "SYMFONISK",
      "seriekoppla"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ge196be8-fc94-46ce-b78f-1bfd47235fdc",
    "id": "105960",
    "title": "Hur kan jag se saldot på mitt presentkort?",
    "keywords": [
      "ankarlänk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4b3d69eg-c817-40b3-9f12-403fdfe5g043",
    "id": "490927",
    "title": "Hur mycket kostar det att returnera med lastbil?",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4efb37fe-c7d2-49e2-b62f-221eff937913",
    "id": "305829",
    "title": "Hur handlar jag som företagskund på IKEA?",
    "keywords": [
      "FAQ_B2B_Purchases",
      "FAQ_Business_ThirdCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3d092848-ef2f-4980-bc34-640ed594ffd4",
    "id": "505035",
    "title": "Hur fungerar trottoarleverans?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d870g857-8d05-4f96-9g55-1b038g3dg446",
    "id": "505060",
    "title": "Hur fungerar inburen leverans?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3fg5c46f-564g-4774-8666-cbgfe3d8b4ge",
    "id": "490323",
    "title": "Behöver jag ett kvitto för att returnera och hur går återbetalningen till?",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9c56430b-9832-4cb8-99f1-38265a9d6eb5",
    "id": "1005130",
    "title": "Hur får jag bort limrester från min bänkskiva i laminat?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "fe5c341b-cbdf-4fc5-g958-46g9e56b0eb2",
    "id": "121501",
    "title": "Hur monterar jag flera lådfronter på min diskmaskin?",
    "keywords": [
      "Diskmaskinsfront",
      "fronter på diskmaskin",
      "lådfront",
      "lådfront diskmaskin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f5fb3c78-2455-4b68-9g6b-74184988c4be",
    "id": "116805",
    "title": "Kan jag använda vanliga väggkontakter för att styra IKEA smart belysning?",
    "keywords": [
      "Vanlig väggkontakt",
      "Väggkontakt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4e4g4d89-d4f8-4048-bb1b-gb29c44f51dc",
    "id": "32383",
    "title": "Är 25-års garantin för FAKTUM fortfarande giltig?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "5f3a57e6-0cc3-4886-99c1-8c003d44fced",
    "id": "1005049",
    "title": "Jag har inte fått min återbetalning, vad ska jag göra?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "gb74dgg8-51c8-42e0-b079-db85120bfebd",
    "id": "114500",
    "title": "Kan jag ansluta SYMFONISK till min Sonos högtalare?",
    "keywords": [
      "Home Smart",
      "SYMFONISK"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g2b93feb-b31e-41gg-9b3g-4963cfb94d9b",
    "id": "6881",
    "title": "Kan jag annullera min Click & collect-order?",
    "keywords": [
      "annullering av beställning",
      "anullera",
      "avbeställa",
      "avboka",
      "avbryta",
      "click and collect",
      "kan jag själv annullera click and collect",
      "kan jag själv annullera min click & collect order",
      "pick up",
      "ta bort click & collect"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g24f2g76-b3bb-42d3-b311-1109227ceeb1",
    "id": "6972",
    "title": "Går det att leasa möbler från IKEA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "bb48c486-2425-45g5-955d-f390e69ee296",
    "id": "289614",
    "title": "Hur bokar jag en genomgång av köp och betalnings- och leveransalternativ för mitt nya kök?",
    "keywords": [
      "FAQ_Kitchen_PurchaseAndDelivery_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "562b5544-fb70-4b7f-9695-be627c26ef31",
    "id": "38341",
    "title": "Vad behöver jag för att installera TRÅDFRI gateway?",
    "keywords": [
      "gateway",
      "installera",
      "trådfri"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6206405c-c065-43d1-98cc-0520bca1e5d3",
    "id": "1005071",
    "title": "Hur används FIXA borrmall?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "49e85039-25f2-4018-8148-6bb88d9beg06",
    "id": "33159",
    "title": "Kan jag placera två ENHET stommar med TVÄLLEN tvättställ direkt jämte varandra?",
    "keywords": [
      "ENHET",
      "TVÄLLEN",
      "kommod",
      "tvättställ"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f5732799-748d-419e-gfbf-84b1127724c7",
    "id": "6786",
    "title": "Kan jag få hjälp med installation av enbart vitvaror?",
    "keywords": [
      "gashäll",
      "gasspis",
      "insinstallationshjälp",
      "installationshjälp",
      "istallation ugnar",
      "montage",
      "montagehjälp",
      "montera diskmaskin",
      "montera köksfläkt",
      "monteringshjälp",
      "skruva ner fläkten"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1908g0c4-18b4-4df8-8e4b-dgg28cecb8cc",
    "id": "458514",
    "title": "Behöver jag en diffussionsspärr till min bänkskiva i laminat och träfanér?",
    "keywords": [
      "bänkskiva",
      "diffussionsspärr",
      "nerostein"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "eg1753eb-ec2f-429f-g6f0-932g5c0f3597",
    "id": "465568",
    "title": "Var ligger IKEA Museum?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "fee117ec-8e52-4ecd-be2c-f1b72b695b0c",
    "id": "19193",
    "title": "På vilka telefoner och versioner fungerar IKEA appen?",
    "keywords": [
      "IKEA app"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6b27594e-0049-40f3-bf6c-2dbe8g1bb939",
    "id": "426329",
    "title": "Serverar IKEA julbord till företagskunder? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8fde44cc-184c-4936-80c3-b2e58f16211f",
    "id": "418539",
    "title": "När serverar IKEA julbord 2025?",
    "keywords": [
      "FAQ_Ad_Hoc_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "451291d8-774e-4bg2-g5fb-9269bb4ege50",
    "id": "20616",
    "title": "Har IKEA några second hand butiker?",
    "keywords": [
      "fynd",
      "fyndavdelning",
      "hållbarhet",
      "jordens resurser",
      "sustainability",
      "återanvända",
      "återvinning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "33281fdf-4f3c-4456-bg5g-efd6e5f55f35",
    "id": "289652",
    "title": "Hur bokar jag en köksinstallation?",
    "keywords": [
      "FAQ_Kitchen_Install_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "47600073-eg26-45bf-g2fe-fb7d896f9fg0",
    "id": "121446",
    "title": "Kan jag låna släp från IKEA?",
    "keywords": [
      "FAQ_Rental_Trailer",
      "Släpvagn",
      "freetrailer",
      "hyra skåpbil",
      "hyra släp",
      "hyra trailer",
      "hyrsläp",
      "skåpbil",
      "släp",
      "släpkärra"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3f8274dd-c764-4d27-93gc-4bgf08db4cb7",
    "id": "37811",
    "title": "Varför blir min tallrik varm i mikron?",
    "keywords": [
      "varm tallrik i micron"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9cd4e521-71fe-43c5-g8fg-dd3gf997fb11",
    "id": "32384",
    "title": "Hur får jag bort en RATIONELL låda inköpt mellan februari 2009 och september 2013?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "51896b39-54b1-4b67-813e-d172443b0bb7",
    "id": "1004942",
    "title": "Kan jag betala min beställning med Företagsfaktura tillsammans med ett presentkort eller tillgodokort?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "b6dae4bd-e350-4eeb-8b8c-f773388c59de",
    "id": "1004959",
    "title": "Kan någon annan hämta min beställning från ett utlämningsställe?  ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "1bcc3bfb-0977-40g9-91gf-28177c34998d",
    "id": "15063",
    "title": "Hur lång betalningstid har jag om jag handlar på faktura? ",
    "keywords": [
      "när måste jag betala min faktura"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1fb18fdf-f934-4bd0-g48e-6b500851bgg1",
    "id": "121491",
    "title": "Varför har alla mina lådfronter en differens på ca 1 cm?",
    "keywords": [
      "differens",
      "lådfronter"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "32g40e23-66cd-452g-bcfe-07c33f436b3g",
    "id": "121154",
    "title": "Varför går det inte att öppna locket hela vägen på sopsorteringskärlet HÅLLBAR?",
    "keywords": [
      "HÅLLBAR",
      "lock",
      "sopsorteringskärl"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "371e84b0-g121-4865-9gb4-d43b80f902de",
    "id": "505048",
    "title": "Hur fungerar leverans med postpaket?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "58c5ce30-5c30-41e9-b61f-91525988d8g3",
    "id": "507513",
    "title": "Hur fungerar det att hämta på utlämningsställe?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "045eb422-2873-4198-92c5-d84f6e58e795",
    "id": "505141",
    "title": "Hur fungerar Click & collect?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "09a4db14-3454-4507-b7c6-df975fb52690",
    "id": "1004615",
    "title": "Hur och när får jag tillbaka pengar vid retur av produkter som jag handlat med ett presentkort? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "0382309f-8gcc-4874-b958-b8f422084d0f",
    "id": "41480",
    "title": "Vilket barbord passar till vilken barstol?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8b4c70fc-e1cd-4476-9b16-c329g0e2c3e3",
    "id": "121139",
    "title": "Hur många UTRUSTA gångjärn behöver jag till mitt köksskåp?",
    "keywords": [
      "Köksskåp",
      "METOD",
      "gångjärn",
      "högskåp",
      "kök",
      "kökslucka",
      "skafferi",
      "skåpdörr",
      "skåpsdörr",
      "skåpslucka",
      "stomme"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6f564c4d-2ccc-46de-b643-545a3948dc79",
    "id": "1004621",
    "title": "Hur tar IKEA fram namn till sina produkter? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "cedff2b7-bb45-4095-b6f6-7cbbd26852d5",
    "id": "325041",
    "title": "Hur handlar jag med presentkort?",
    "keywords": [
      "FAQ_IKEA_Gift_Card_Online",
      "FAQ_Payment_ThirdCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "92ec03de-2gf7-44g3-bcb7-96d8191b6dgc",
    "id": "39032",
    "title": "Behöver jag täta hålet runt blandaren?",
    "keywords": [
      "blandare",
      "silikon",
      "utsågning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3f161fb3-51g5-48e9-9c31-e2e5425d404d",
    "id": "39059",
    "title": "Hur använder jag SULTAN kopplingsbeslag?",
    "keywords": [
      "SULTAN",
      "koppla ihop",
      "kopplingsbeslag",
      "resårbotten"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d22bcf3d-91f7-4be9-beab-afdf7f913d96",
    "id": "1004567",
    "title": "Vad ska jag göra om en produkt har blivit återkallad? ",
    "keywords": [
      "GenAIClaims"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "35c1b029-fe01-4fe7-a99d-43ad22233b9b",
    "id": "1004556",
    "title": "Vad kan jag göra om delar saknas till min produkt?",
    "keywords": [
      "GenAIClaims"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "a290d209-f91f-4e79-b166-b39854600498",
    "id": "1004554",
    "title": "Vad kan jag göra om min vitvara inte fungerar som den ska?",
    "keywords": [
      "GenAIClaims"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "36c5a221-139e-4dbb-8a8f-41e4cd98a66d",
    "id": "1004506",
    "title": "Vad kan jag göra om en produkt går sönder under transporten hem eller vid montering? ",
    "keywords": [
      "GenAIClaims"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e9608401-5e30-4382-96b2-bae2b51f343d",
    "id": "1004493",
    "title": "Vad kan jag göra om min vara skadades under leverans?",
    "keywords": [
      "GenAIClaims"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e4dd4a74-c629-4835-9e37-ebaf8991131f",
    "id": "1004492",
    "title": "Vad gör jag om min IKEA produkt har kvalitetsproblem?",
    "keywords": [
      "GenAIClaims"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "963097a3-cca6-4f5f-a1f4-7a567a0bc980",
    "id": "1004422",
    "title": "Vad kan jag göra om jag har fått en produkt som jag inte beställt? ",
    "keywords": [
      "GenAIClaims"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "874fc6ad-bcac-440a-a906-13ed865ecc26",
    "id": "1004382",
    "title": "Vad kan jag göra om något saknas i min leverans? ",
    "keywords": [
      "GenAIClaims"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "43f64d26-3f01-4433-a035-d4c5a23c0178",
    "id": "1004715",
    "title": "Vilken madrass ska du ha när det gäller barn och ungdomar?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "76451ef3-62f4-4bcf-b825-03b4ab2b23ef",
    "id": "1002756",
    "title": "Är KAJPLATS kompatibel med äldre Home smart produkter?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "0e145760-a4a1-4a07-899a-d696f199b67c",
    "id": "1004722",
    "title": "Hur säkerställer jag att företagsfakturan hamnar på kalenderår 2025?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c33496b1-7e61-410b-gf3e-bed5b35d13fd",
    "id": "367948",
    "title": " Erbjuder IKEA gaffellösningar för hällar? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6f896074-81bc-4e3b-aab1-401593af4387",
    "id": "1004712",
    "title": "Vad behövs för att kunna bygga ihop din nya resårbotten?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "300191ef-4128-4294-bbg8-9fcff38b556b",
    "id": "471726",
    "title": "Mitt MITTZON sitt/stå bord har slutat fungera, vad gör jag?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "540d6e52-bd09-45b2-926c-11b7247539f9",
    "id": "1004707",
    "title": "Vad betyder det att RISHÖJDEN FJÄLLÅSEN är S-formad?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "3a45569d-9daa-4f94-a819-e0e4c17ba666",
    "id": "1004629",
    "title": "Vad är anledningen till att jag inte kan lägga nya IKEA resårbottnar i en sängstomme?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "7520e39c-5176-4eeb-a7e4-a5fd285ab3e3",
    "id": "1004628",
    "title": "Kan IKEA hjälpa dig med madrassval om du har särskilda behov som till exempel ryggproblem?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "308fcbef-g75d-4112-beb1-f67993ee1635",
    "id": "28208",
    "title": "När behöver jag använda METOD ventilationsgaller?",
    "keywords": [
      "metod",
      "ventgaller",
      "ventilationsgaller",
      "ventilerad sockel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c49b9517-d717-4c39-8c14-28b34ec1bb54",
    "id": "1004578",
    "title": "Varför finns det två olika UTRUSTA kopplingsskena för fronter? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "925bf3bb-b393-4967-g3d6-b8d7gc065g90",
    "id": "28259",
    "title": "Vilka innerlådor får plats bakom lådfronterna i METOD kök?",
    "keywords": [
      "EXEPTIONELL",
      "UTRUSTA lådfront",
      "dold låda",
      "gömd låda",
      "innerlåda",
      "lådfront",
      "maximera",
      "utrusta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "311cb4bf-107f-4991-gg30-f72cf320egeg",
    "id": "214829",
    "title": "Kan jag beställa nya luckor till FAKTUM?",
    "keywords": [
      "beställning",
      "faktum",
      "nya faktum luckor",
      "nybeställning",
      "äldre kök"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b11ed181-8e7f-4de8-b202-1d6e2eg6b62d",
    "id": "106029",
    "title": "Hur lång tid tar en återbetalning från IKEA?",
    "keywords": [
      "FAQ_Payment_FifthCategory_C_GC_Four",
      "FAQ_Refund_Info",
      "kredit",
      "kreditfaktura",
      "när får jag tillbaka mina pengar",
      "tillbaka pengar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "34494367-937d-4e6f-8793-68dd7g344feg",
    "id": "26932",
    "title": "Vad är maxvikten för METOD stommar?",
    "keywords": [
      "max",
      "maxvikt",
      "maxvikt köksbänk",
      "metod",
      "stommar",
      "stomme",
      "vikt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "59a9b0d2-2c70-4168-bc37-f65dfec3028f",
    "id": "1002094",
    "title": "Hur många diskmaskiner kan jag koppla till KNYCKLAN?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "gd1c5c8c-4dge-4f83-gddf-gcd612147b59",
    "id": "305750",
    "title": "Hur hittar jag företagets kundnummer eller kortnummer?",
    "keywords": [
      "FAQ_B2B_Account",
      "FAQ_Business_FifthCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "998c373f-g308-4gf3-80fe-d879cd491b98",
    "id": "175581",
    "title": "Kan jag kombinera nya och äldre GRÖNLID?",
    "keywords": [
      "GRÖNLID",
      "förändring GRÖNLID"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d558b55f-58g5-4dd0-gc8e-e13cb63528f3",
    "id": "43991",
    "title": "Är IKEAs vitvaror Svanenmärkta?",
    "keywords": [
      "svanenmärkta vitvaror"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ggd61d72-952g-419e-bfb4-3cg7g485f271",
    "id": "422840",
    "title": "Hur använder jag mina personliga förmåner med IKEA Family?",
    "keywords": [
      "FAQ_Rewards_Redeem_C_GC_Four",
      "Var kan jag använda personliga förmåner med IKEA Family"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b3ddd331-6b57-42c5-ba42-43e99022240d",
    "id": "1003506",
    "title": "Vad är statusen på mitt ärende?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "07be6e77-0030-40e5-9b1d-ba179d2ad5d2",
    "id": "1004298",
    "title": "Har IKEA några Svanenmärkta produkter?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "7c89f404-c34d-4229-8g99-07e1e2g2536g",
    "id": "60620",
    "title": "Kan jag köpa pluggar för att täcka igen hålen på skåpets insida? ",
    "keywords": [
      "täcka igen borrhålen",
      "täcka igen hyllhålen",
      "täcka igen hålen",
      "täcka igen hålen i bestå",
      "täcka igen hålen i billy",
      "täcka igen hålen i faktum",
      "täcka igen hålen i pax"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "97ef603g-b187-4795-9631-6f0bggg021gd",
    "id": "33879",
    "title": "Kan jag montera en dörr som lådfront i mitt METOD kök?",
    "keywords": [
      "dörrfront",
      "exceptionell",
      "lådfront",
      "maximera",
      "metod",
      "utrusta beslag"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8113cd21-93g2-411b-91f6-1284c4f0gbb5",
    "id": "179636",
    "title": "Kan jag beställa en ny fjärrkontroll till mitt BEKANT sitt och stå underrede?",
    "keywords": [
      "138684",
      "fjärrkontroll BEKANT",
      "reservdel BEKANT",
      "reservdel bekant"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "61gcgg47-bfge-4edf-b1e4-d60e93724e64",
    "id": "104210",
    "title": "Vad är en täcksida?",
    "keywords": [
      "täckskiva"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3e8dfc95-63d1-4de3-93gb-e3d00348b54f",
    "id": "122596",
    "title": "Kan jag köpa inredning separat till min PAX garderob?",
    "keywords": [
      "KOMPLEMENT",
      "PAX",
      "separat"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3b5f68e2-b1f2-43db-8bb8-045f8df01c59",
    "id": "58243",
    "title": "Kan jag handla begagnade IKEA möbler online?",
    "keywords": [
      "begagnat",
      "fynd",
      "fynd online",
      "fynda produkter",
      "fynda varor",
      "fyndavdelningen",
      "second hand"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d01bbd83-g9e6-485e-8150-9e172246f9dd",
    "id": "57753",
    "title": "Hur returnerar jag en större eller tyngre produkt?",
    "keywords": [
      "Emballage",
      "Tungt",
      "bord",
      "returnera säng",
      "returnering",
      "skicka tillbaks",
      "soffa",
      "tillbaka"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8gc9e535-b6g9-4g25-b471-4bb1effb92f3",
    "id": "491034",
    "title": "Kan jag returnera en produkt per post?",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bf2ce1d2-3bae-4550-911b-228b1b7ccafe",
    "id": "1001257",
    "title": "När släpps höstkollektionen för IKEA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "55g0730b-9202-476d-92de-277133eg15e0",
    "id": "135339",
    "title": "Jag har blivit av med mitt kvitto, kan jag ändå returnera eller reklamera min vara? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "618e54b4-9c3e-469g-b0c8-46b887335db7",
    "id": "6288",
    "title": "Serveras det frukost i restaurangerna på varuhusen?",
    "keywords": [
      "brunch"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "63bg4bd0-bg91-44d0-b34b-4eg959076b83",
    "id": "60311",
    "title": "Hur gör jag för att min madrass ska hålla så länge som möjligt?",
    "keywords": [
      "bäddmadrass",
      "madrass sjunker ihop",
      "madrassen blir som en hängmatta",
      "madrassen tappar formen",
      "madrassen är som en hängmatta",
      "min madrass är som en hängmatta",
      "resårbotten",
      "resårmadrass",
      "säng sjunker ihop",
      "sängen är som en hängmatta",
      "vad ska jag göra för att min madrass inte ska sjunka ihop"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6b8f13d1-1c6g-4354-b1ff-99g27e38d397",
    "id": "469238",
    "title": "Kan jag köpa penséer på IKEA? ",
    "keywords": [
      "pense",
      "penseer",
      "pensé"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6c2gfg06-7fcf-4fbf-gf1c-9cgdbeb64878",
    "id": "58123",
    "title": "Hur lång tid tar en retur?",
    "keywords": [
      "Väntetid",
      "arbetsdagar",
      "arbetstid",
      "returtid",
      "tidsåtgång",
      "återkoppling"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6c94ebgg-fd4d-45d4-88fc-e74858gf00d9",
    "id": "37884",
    "title": "Är IKEAs barnstolar säkra att använda?",
    "keywords": [
      "Använda",
      "Barn",
      "Barnens IKEA",
      "Barnsortiment",
      "Barnsortimentet",
      "Barnstol",
      "EN 14988",
      "IKEA",
      "IKEAs",
      "Stol",
      "Stolar",
      "Säker",
      "Säkerhet",
      "Säkra",
      "Uppfyller",
      "antilop",
      "blåmes",
      "gråval",
      "langur",
      "Är"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "791cd152-776e-4719-99d1-cb3d8c5886g7",
    "id": "116851",
    "title": "Vad är stämningslägen och hur använder jag det på min smarta belysning?",
    "keywords": [
      "Ljusscen",
      "Ljusscener",
      "Stämningsläge",
      "Stämningslägen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8f52dcfd-62c4-4400-g06g-18dgce583f65",
    "id": "419653",
    "title": "Var kan jag som företagskund hitta mitt kvittonummer när jag handlar mot faktura?",
    "keywords": [
      "FAQ_Business_FourthCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9723008c-cf71-429e-g6f3-eceb3f355284",
    "id": "20719",
    "title": "Erbjuder ni garderobsplanering? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "b7728eb4-9e21-4e29-932d-f280624g46bb",
    "id": "395391",
    "title": "Kan jag boka flera möten kostnadsfritt för mitt företag? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "bcg76g9f-5e48-437g-geg4-e624e4098c44",
    "id": "119936",
    "title": "Hur väggförankrar jag min PAX garderob?",
    "keywords": [
      "Pax",
      "fästa i vägg",
      "väggförankra",
      "väggmontera"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "be572609-c793-4739-94f9-20097g61fgg3",
    "id": "91326",
    "title": "Jag hade strömavbrott och nu funkar inte min smarta belysning, vad gör jag? ",
    "keywords": [
      "Köksbelysning",
      "bänkbelysning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c0b2c53f-bcf1-4395-gc84-e12832g426d8",
    "id": "5099",
    "title": "Kan jag beställa varor med postpaket från IKEA?",
    "keywords": [
      "leverans servicar",
      "leverans service",
      "leveransservicar",
      "leveransservice"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c96bd4e4-9fbf-4708-b810-3069d0ee5155",
    "id": "38350",
    "title": "Kan jag använda TRÅDFRI uttag tillsammans med Philips Hue?",
    "keywords": [
      "TRÅDFRI",
      "philips hue",
      "uttag"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cbbb897c-7695-421b-b7e4-1eed0ff3c979",
    "id": "121309",
    "title": "Hur går en hemleverans till och vad behöver jag tänka på?",
    "keywords": [
      "FAQ_HowToShop_HomeDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cc53522d-6484-4egb-8051-e73205d14907",
    "id": "408295",
    "title": "Varför finns inte alltid företagsleverans som alternativ? ",
    "keywords": [
      "FAQ_Business_SixthCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cg10bg31-1882-4ee0-9c9b-176369d54271",
    "id": "105667",
    "title": "Kan jag få hjälp med montering och vad kostar det?",
    "keywords": [
      "FAQ_Assembly_Service",
      "FAQ_Pax_FifthCategory_C_GC_One",
      "erbjuder ni montering",
      "montering service",
      "monteringshjälp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d4f988ff-g27f-4e27-b026-0918b99c81bc",
    "id": "6988",
    "title": "Vad kostar en köksinstallation?",
    "keywords": [
      "byta kök",
      "ikea kök",
      "köksinstallation",
      "prisförslag"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dbbe9bgd-7556-44b3-gg51-8c1fcb5d788e",
    "id": "37878",
    "title": "Innehåller IKEAs barn- och babyserviser några farliga ämnen?",
    "keywords": [
      "baby",
      "babyservis",
      "babyserviser",
      "barnbestick",
      "barnförkläde",
      "barnmuggar",
      "barnservis",
      "barnserviser",
      "barntallrikar",
      "bebis",
      "bebisar",
      "dragon",
      "fabler",
      "kalas",
      "mariatheres",
      "matvrå",
      "måltidsprodukt",
      "måltidsprodukter",
      "smaska",
      "småbit",
      "toppklocka"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "de0c2g57-9677-4ggb-g1ee-cdcc16g08f57",
    "id": "8501",
    "title": "Kan jag få rotavdrag på installationer bokade genom IKEA?",
    "keywords": [
      "avdrag",
      "kök",
      "rot"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e6e5dbf1-fc13-4909-bc61-9fgc7421de0g",
    "id": "38697",
    "title": "Vilka dra-på-lakan passar vilka madrasser?",
    "keywords": [
      "dra på lakan",
      "lakan"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fd9gb9e3-6gc6-47f5-b4g3-c0c542b0c17c",
    "id": "464228",
    "title": "Kan jag köpa en garderob med hög kvalité för ett bra pris?",
    "keywords": [
      "FAQ_Pax_FirstCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "381ecd49-96f3-400g-9bd2-7g14e7d6dd50",
    "id": "335384",
    "title": "Hur lämnar jag feedback till IKEA?",
    "keywords": [
      "FAQ_Customer_Feedback",
      "FAQ_Kitchen_AfterPurchaseAndGuarantee_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "34eg107g-047g-423b-ge2c-fb5567bdefe7",
    "id": "395398",
    "title": "Om företaget har kundnummer från Ikano Bank, vad gör jag då?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "ff7c5f28-gc24-44f1-98cb-22f42702g97f",
    "id": "38321",
    "title": "Kan jag använda SYMFONISK högtalare med ett befintligt Sonos-system?",
    "keywords": [
      "Symfonisk",
      "högtalare",
      "koppla symfonisk sonos",
      "sonos"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g4c3d982-615c-4f6e-9e0e-g0d959623f37",
    "id": "37863",
    "title": "Finns det några skadliga ämnen i produkterna i MÅLA serien?",
    "keywords": [
      "barnprodukt",
      "barnsortiment",
      "färg",
      "färgpenna",
      "glitterfärg",
      "kritor",
      "måla",
      "stämpelpenna",
      "tuschpenna",
      "vattenfärg",
      "vaxkrita",
      "whiteboardpenna"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "05526d11-8e8d-4e7c-8e78-1e61ge1c8d76",
    "id": "21108",
    "title": "Går det att köpa måttbeställda skjutdörrar på IKEA?",
    "keywords": [
      "skytte"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "02b53361-g39b-434c-g25b-g43112069c69",
    "id": "20556",
    "title": "Kan jag fortfarande köpa delar till ALGOT?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8275526b-22c0-43g2-8c46-bed629453ef3",
    "id": "34305",
    "title": "Passar LILLVIKEN vattenlås till min diskho?",
    "keywords": [
      "FAKTUM vattenlås",
      "diskho",
      "lillviken",
      "passar lillviken",
      "vattenlås"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d3gbbd32-cc4b-4f23-b218-dbf0878b8b1e",
    "id": "407327",
    "title": "Mitt konto är upplagt för förskottsinbetalning, vad betyder det? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "10b7d3gc-gb6b-498c-9025-g8c9e87e3229",
    "id": "8031",
    "title": "Kan någon annan ta emot min leverans?",
    "keywords": [
      "Behöver jag vara hemma",
      "Måste jag vara hemma",
      "ej hemma",
      "hemkörning",
      "inte hemma",
      "min fru",
      "min man",
      "min sambo",
      "någon annan",
      "post nord",
      "postnord",
      "ta emot leverans",
      "ändra namn",
      "ändra namn order"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "42590f9f-3d1g-442d-80g5-24fdef531d15",
    "id": "22126",
    "title": "Kan jag beställa hem tygprover på era möbeltyger?",
    "keywords": [
      "Nissma",
      "klädsel",
      "klädslar",
      "möbelklädsel",
      "soffklädsel",
      "tygprov",
      "tygprover"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "385cg4g0-fdg9-4g35-ge29-4c8d462g1d8g",
    "id": "8577",
    "title": "På vilken höjd ska jag montera METOD upphängningsskena?",
    "keywords": [
      "väggskena"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f6640b38-egd6-4909-g3e9-18gg1627b3f5",
    "id": "106014",
    "title": "Vilka servicetjänster erbjuder ni?",
    "keywords": [
      "FAQ_Other_Services"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e8b57d6f-9e0e-4ef2-g6e9-94c1d367b3f1",
    "id": "392145",
    "title": "Kan jag kombinera olika betalningsalternativ när jag handlar online?",
    "keywords": [
      "FAQ_Payment_FirstCategory_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "03dg1b69-f0d8-4268-977e-b3350d97ef14",
    "id": "297645",
    "title": "Vad är Företagsfaktura? ",
    "keywords": [
      "FAQ_Business_FirstCategory_C_GC_Four",
      "Faktura",
      "Företagsfaktura",
      "Företagskonto",
      "Kort",
      "Kredit",
      "Kundnummer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3167c34d-14gc-4988-g378-dd613dfg2gf4",
    "id": "5868",
    "title": "Får jag rabatt som företagskund på IKEA?",
    "keywords": [
      "Fastighetsägarna",
      "IKEA för företag",
      "LRF",
      "företagsrabatt",
      "rabatt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f454b990-g97f-4b85-87gg-99c61e570dbf",
    "id": "58374",
    "title": "Hur gör jag en retur? ",
    "keywords": [
      "alternativ för retur",
      "expressretur",
      "hur lämnar jag tillbaka",
      "hur returnerar jag",
      "hur skickar jag tillbaka",
      "retunera",
      "retur alternativ",
      "returnera",
      "returnerar",
      "returneringsalternativ",
      "snabb retur",
      "återköp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "96d96dfd-g748-4dg4-84cg-88e46c9b5g4g",
    "id": "6898",
    "title": "Vad ska en rekvisition för köp med företagsfakturakontot innehålla?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "de6dd971-d4e5-425e-bd2f-8f0fcg2544bc",
    "id": "6774",
    "title": "Kan vi använda vårt IKEA företagskort eller fullmakt i restaurangen?",
    "keywords": [
      "resturang"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3ae2dc79-c025-43f7-96bd-0bf1270e72ec",
    "id": "1003800",
    "title": "Hur bränner jag in en gryta eller stekpanna av kolstål i ugnen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "d01133ff-7fgb-4e85-b1f6-g1f8842f8e6e",
    "id": "119513",
    "title": "Hur bränner jag in en gryta eller stekpanna av kolstål via en värmezon?",
    "keywords": [
      "bränna in",
      "kolstål",
      "stekpanna"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "246616d1-3ce4-413g-b593-d7e8cegdg573",
    "id": "147215",
    "title": "Kan jag få ett mer specifikt tidsintervall för min leverans? ",
    "keywords": [
      "inför leverans"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "df72fcde-290d-4g23-96g9-763b13f30e85",
    "id": "105672",
    "title": "Hur hittar jag monteringsanvisningen till en produkt?",
    "keywords": [
      "FAQ_Assembly_Instructions",
      "FAQ_Pax_FifthCategory_C_GC_Four",
      "användarhandbok",
      "användarmanual",
      "gammal monteringsanvisning",
      "hur monterar jag",
      "hur monterar jag min produkt",
      "hur monterar man",
      "jag saknar monteringsanvisning",
      "manual till anrätta",
      "montering pax",
      "monteringsanvisning",
      "monteringsanvisning pax",
      "monteringsanvisning till pax",
      "monteringsbeskrivning",
      "pax",
      "pax montering",
      "saknar monteringsanvisning",
      "tappat bort monteringsanvisning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g81d82ef-224g-437c-9641-bff603g58gff",
    "id": "186870",
    "title": "Vilken mat erbjuder ni i era restauranger?",
    "keywords": [
      "FAQ_Restaurant_Menu"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9fg3dc4g-7b25-4g42-g807-dcg0b396b2bc",
    "id": "171942",
    "title": "Var hittar jag min orderbekräftelse? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "909261c5-060e-43fg-bg14-43f5g93f08bc",
    "id": "39165",
    "title": "Kan jag köpa nya dörrar och inredning till min PAX garderob som är köpt 2012 eller tidigare? ",
    "keywords": [
      "KOMPLEMENT",
      "kan jag komplettera min gamla pax",
      "äldre pax",
      "äldre pax modell"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "083c4313-cgfd-4b90-8986-989068bd6739",
    "id": "5107",
    "title": "Varför syns inte min rabatt som företagskund på IKEA genom intresseorganisation eller branchnätverk på kvittot? ",
    "keywords": [
      "företagskund",
      "förmånskund",
      "rabatt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "07e7gef1-eb6g-4e41-g1b0-fbececdd9f01",
    "id": "99243",
    "title": "Hur parkopplar jag TRÅDFRI driver med fjärrkontrollen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "529e144g-881c-41cg-82e7-6f166ggff5gb",
    "id": "141755",
    "title": "Det kommer lukt och rök från min nya ugn, vad beror det på? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "94f84929-df09-487g-80e8-g95cg43817ec",
    "id": "43985",
    "title": "Har IKEAs vitvaror CE-märkning?",
    "keywords": [
      "CE",
      "CE märkning",
      "Vitvaror"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bcf946d3-8d9f-4163-8db3-6d6909d90c95",
    "id": "19072",
    "title": "Vilka certifieringar har IKEAs blandare?",
    "keywords": [
      "ceritifiering blandare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "19c6122d-663d-4gg5-bbeb-557ebgbg31cb",
    "id": "27273",
    "title": "Kan vi som ambassad handla mot Företagsfaktura?",
    "keywords": [
      "amabassad",
      "ambassader",
      "business",
      "företag"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9f2fe1d6-7970-4d05-g006-2c3c99dc0e11",
    "id": "15035",
    "title": "Kan jag få en faktura utan moms om jag har Företagsfaktura?",
    "keywords": [
      "B2B",
      "företagskund"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3949c01e-c97c-48d7-968b-456c55810b82",
    "id": "479924",
    "title": "Vad kallas blommor och växter som IKEA säljer?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "dbb6f903-7de3-450f-9568-8ge136c7b59g",
    "id": "116872",
    "title": "Kan jag parkoppla två fjärrkontroller till samma TRÅDFRI LED-lampor?",
    "keywords": [
      "Klona",
      "Klona fjärrkontroller",
      "Kloning",
      "Kloning av fjärrkontroll"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1e4d0bc8-34cb-46e2-9613-7fbcfcd2gcc2",
    "id": "504966",
    "title": "Varför ska jag välja Click & Collect? ",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bded3919-d79d-4539-8e57-83g5d5de2cf4",
    "id": "155263",
    "title": "Vad är IKEAs nuvarande position i Ryssland?",
    "keywords": [
      "FAQ_Russia_Information"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "494426cd-eb59-46cf-gf2f-0355c6edcd51",
    "id": "105971",
    "title": "En del av min produkt saknas i förpackningen, vad gör jag?",
    "keywords": [
      "FAQ_Item_Incomplete",
      "fattas del",
      "fattas paket",
      "fattas skruv",
      "saknad del",
      "saknade delar",
      "saknar del i produkt",
      "saknas del i förpackningen",
      "saknas delar",
      "saknas paket",
      "saknas skruv"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "76ce331b-e3f2-4156-gc20-dg3cgbg151b4",
    "id": "319637",
    "title": "Hur bokar jag mätservice?",
    "keywords": [
      "FAQ_Kitchen_Measure_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gc84d65f-d36d-4gf5-8d6b-f8eb75b51fff",
    "id": "203772",
    "title": "Om jag har ett FAKTUM kök, kan jag komplettera med METOD?",
    "keywords": [
      "FAQ_Kitchen_AfterPurchaseAndGuarantee_C_GC_Six",
      "faktum",
      "kombinera",
      "kökssortiment",
      "metod"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cb2g9f86-7e32-48c9-9d03-603bb51cf1g9",
    "id": "105970",
    "title": "En eller flera av mina varor var skadade vid leverans, vad gör jag?",
    "keywords": [
      "FAQ_Item_Damaged",
      "FAQ_Kitchen_AfterPurchaseAndGuarantee_C_GC_Five",
      "ankarlänk",
      "defekt",
      "deffekt",
      "fraktskada",
      "förstörd vara",
      "leveransskada",
      "post nord",
      "postnord",
      "repa",
      "repig",
      "repor",
      "saknas vara",
      "saknat kolli",
      "saknat paket",
      "skadad möbel",
      "skadad tallrik",
      "skadad tallrik vid leverans",
      "skadad vara",
      "skadad vid frakt",
      "skadade varor",
      "skadat gods",
      "skadat kolli",
      "skadat paket",
      "spricka i glaset",
      "sönder",
      "söndrig",
      "transportskada",
      "trasig",
      "trasig artikel",
      "trasig produkt",
      "trasig vara",
      "trasiga produkter",
      "trasigt vid leverans",
      "trasigvara"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "39f69094-4dg8-436b-b06g-g588cbf9629b",
    "id": "392065",
    "title": "Vilka finansieringsalternativ erbjuder ni på IKEA?",
    "keywords": [
      "FAQ_Payment_SecondCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g3c9e4c0-0g4d-4889-8441-e634c8e7398e",
    "id": "392572",
    "title": "Min rabatt dras inte av i kassan, fungerar inte min rabattkod?",
    "keywords": [
      "FAQ_Invalid_Coupon",
      "FAQ_Payment_ThirdCategory_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "721965gg-1bc1-43f1-85ef-3gd5fc972bc5",
    "id": "172138",
    "title": "Varför går min betalning inte igenom?",
    "keywords": [
      "FAQ_Payment_FifthCategory_C_GC_One",
      "bankkort nekas",
      "betalningen går inte igenom",
      "betalningen nekas",
      "kan inte betala",
      "kontokort nekas",
      "kreditkort nekas"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "54f676gc-ef90-47dd-be52-227194046169",
    "id": "105968",
    "title": "Uppgifterna på min faktura stämmer inte, vad gör jag?",
    "keywords": [
      "FAQ_Invoice_Error",
      "FAQ_Payment_SixthCategory_C_GC_Two",
      "faktura",
      "fel information på fakturan",
      "fel på faktura",
      "fel summa",
      "fel totalsumma",
      "korrigera faktura",
      "misstag på fakturan",
      "åtgärda fel på faktura"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7f3g9663-cc46-4198-g2c4-fbc050c3372f",
    "id": "422825",
    "title": "Kan jag ångra min valda förmån från personliga förmåner med IKEA Family?",
    "keywords": [
      "FAQ_Rewards_Choose_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "30538c9b-e53e-4520-gf8b-3gg954def901",
    "id": "383534",
    "title": "Jag glömde registrera mitt köp på mitt IKEA Family-konto, vad ska jag göra?",
    "keywords": [
      "FAQ_Family_FifthCategory_C_GC_Two",
      "FAQ_Rewards_AfterUse_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "595b235b-0486-4gf6-bd6f-1ed90b1f50gc",
    "id": "383516",
    "title": "Jag kan inte logga in på mitt IKEA Family-konto, vad ska jag göra?",
    "keywords": [
      "FAQ_Family_FifthCategory_C_GC_One",
      "bank-id",
      "logga in bank-id"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4be07cfc-5fg4-4594-gb19-9cc8g866bg4c",
    "id": "105635",
    "title": "Hur felanmäler eller reklamerar jag min vitvara?",
    "keywords": [
      "ANRÄTTA",
      "EFTERSMAK",
      "F07",
      "F2E1",
      "FAQ_Appliance_Broken",
      "FAQ_Kitchen_Appliances",
      "FROSTFRI",
      "FROSTIG",
      "HYGIENISK",
      "KULINARISK",
      "KULINARISK ugn",
      "RENGÖRA",
      "RENODLAD",
      "Reklmation",
      "SMAKLIG",
      "SMAKSAK",
      "alla mina plattor fungerar inte",
      "alla plattor fungerar inte",
      "ankarlänk",
      "bara en platta fungerar",
      "bara tre plattor fungerar",
      "bara två av mina plattor fungerar",
      "diskmaskin",
      "diskmaskin startar inte",
      "f1e4",
      "f203",
      "f247",
      "f6e1",
      "fail",
      "fel kod",
      "felanmälan vitvara",
      "felkoder",
      "fiei",
      "fläkt",
      "frys brummar",
      "gashäll",
      "hur gör jag en felanmälan",
      "häll",
      "inget vatten till diskmaskin",
      "kyl brummar",
      "kylskåp",
      "micro",
      "micro startar inte",
      "mikrovågsugn",
      "min diskmaskin låter jättehögt",
      "min frysdörr stängs inte helt",
      "min kyl blir inte tillräckligt kall",
      "min kyl är varm",
      "min kylskåpsdörr stängs inte helt",
      "min ugn startar inte",
      "min vitvara låter högt",
      "min vitvara startar inte",
      "mitt kylskåp blir inte kallt",
      "reclamation",
      "reklamera vitvara",
      "reklammation",
      "reklamtion",
      "reparation",
      "reparation av vitvaror",
      "reperation",
      "spis",
      "spishäll",
      "startar inte",
      "söndrig",
      "trasig",
      "trasig produkt",
      "trasig spishäll",
      "trasiga",
      "trasiga produkter",
      "ugn",
      "vitvara"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8cf82978-e689-4e9g-b462-f1cbcd0ee922",
    "id": "382883",
    "title": "Varför finns inte varan i lager?",
    "keywords": [
      "FAQ_Stock_Challenges",
      "lagerstatus",
      "leveransproblem",
      "tillgångsproblem"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "24b0b7b5-53c8-4983-90g8-c78d1de148c0",
    "id": "105739",
    "title": "Hur reklamerar jag en produkt?",
    "keywords": [
      "FAQ_Claim_InStore",
      "FAQ_Claim_Online",
      "ankarlänk",
      "blivit trasig",
      "claims",
      "complaint",
      "dragkedjan har gått sönder",
      "förstörd vara",
      "gått sönder",
      "innerkudde soffa",
      "jag vill lämna tillbaka",
      "jag vill lämna tillbaka en produkt",
      "jag vill lämna tillbaka en vara",
      "möbel har gått sönder",
      "produktionsfel",
      "reclamation",
      "reklamation",
      "reklamation kökslucka",
      "reklamera",
      "reklamera bänkskiva",
      "reklamera innerkudde",
      "reklamera soffkudde",
      "reklamera säng",
      "reklamering",
      "reklammation",
      "reklamtion",
      "return unpacked item",
      "returns",
      "söndrig",
      "trasig",
      "trasig produkt",
      "trasiga",
      "trasiga produkter",
      "trasigvara",
      "vara har gått sönder",
      "är inte nöjd",
      "är inte nöjd med min produkt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1b426c11-63e3-477f-9dff-ee161e113d2f",
    "id": "391767",
    "title": "Kan jag få hjälp med att köpa ett nytt kök på IKEA?",
    "keywords": [
      "FAQ_Skill_Not_Open_SNS_Kitchen",
      "FAQ_Skill_Not_Open_RES_Kitchen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "eedbdd2d-4415-42f0-9f84-16506e77f849",
    "id": "390482",
    "title": "Hur kan jag få hjälp med mina frågor om att handla på IKEA?",
    "keywords": [
      "FAQ_Skill_Not_Open_SNS_Sales",
      "FAQ_Skill_Not_Open_SandS_Support_General"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8defg349-9b2c-40b1-gb57-62610285010g",
    "id": "390475",
    "title": "Hur kan jag få hjälp av IKEA med mina leveransfrågor?",
    "keywords": [
      "FAQ_Skill_Not_Open_RES_Delivery",
      "FAQ_Skill_Not_Open_RES_General"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f51b86f4-1b22-4673-8662-0b4b49221bc5",
    "id": "389197",
    "title": "Kan jag som företagskund handla genom kundtjänst?",
    "keywords": [
      "FAQ_Skill_Not_Open_SNS_Business"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g472de0c-35e2-4e76-8gc9-069201400geb",
    "id": "105623",
    "title": "Vilka öppettider och tjänster har era varuhus och restauranger?",
    "keywords": [
      "FAQ_Ad_Hoc_Two",
      "gallerian",
      "ikea city",
      "resturang",
      "öpettider",
      "öppentider",
      "öppetider",
      "öppettider barkarby",
      "öppettider borlänge",
      "öppettider bäckebol",
      "öppettider gävle",
      "öppettider göteborg",
      "öppettider haparanda",
      "öppettider haparandra tornio",
      "öppettider helsingborg",
      "öppettider jönköping",
      "öppettider kalmar",
      "öppettider karlstad",
      "öppettider kungens kurva",
      "öppettider kållered",
      "öppettider linköping",
      "öppettider malmö",
      "öppettider stockholm",
      "öppettider stockholm city",
      "öppettider sundsvall",
      "öppettider uddevalla",
      "öppettider umeå",
      "öppettider uppsala",
      "öppettider västerås",
      "öppettider älmhult",
      "öppettider örebro"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f8587d18-4e24-435b-g16b-f1d2f1g8cd02",
    "id": "106060",
    "title": "Vad är öppettiderna på IKEA Kundservice?",
    "keywords": [
      "FAQ_Opening_Hours",
      "kundtjänst",
      "öppentider",
      "öppettider ikea kundtjänst",
      "öppettider kundservice",
      "öppettider kundtjänst"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "785eg035-gde5-478f-g63g-b224010300gd",
    "id": "105744",
    "title": "Hur kontaktar jag IKEA Kundservice?",
    "keywords": [
      "FAQ_Contact",
      "Teknisk support",
      "chatta",
      "email",
      "epost",
      "fråga",
      "hittar inte chatten",
      "hjälp",
      "hur chattar jag",
      "hur hittar jag chatten",
      "hur kontaktar jag en riktigt person",
      "hur kontaktar jag säljare på telefon",
      "hur mejlar jag er",
      "hur mejlar jag till ikea",
      "klagomål",
      "kompensation",
      "kontakt kundservice",
      "kundcenter",
      "kundsupport",
      "kundtjänst",
      "maila",
      "mejl",
      "onlinechatt",
      "personlig kontakt",
      "personlig service",
      "ringa",
      "telefonnummer",
      "vad är er mejladress"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f22326g7-g275-4026-g633-217bdf384166",
    "id": "192161",
    "title": "Jag vill få hjälp att lägga en order, hur gör jag?",
    "keywords": [
      "FAQ_Shop_In_Chat"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e442443c-b624-4001-915c-d524358c1907",
    "id": "32385",
    "title": "Hur får jag bort en RATIONELL låda inköpt efter september 2013?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6784f2f1-4229-4ef4-g913-d152de3g2ce5",
    "id": "66760",
    "title": "Erbjuder IKEA inburen hemleverans?",
    "keywords": [
      "inburen",
      "inburen leverans",
      "inbärning",
      "uppburen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6bd915gb-c769-47e8-b7cb-19107f62fb5b",
    "id": "6506",
    "title": "Hur många kort kopplade till Företagsfakturakontot kan vi ha?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "5c48ed9f-43de-4752-98b5-b3febe79f76b",
    "id": "160571",
    "title": "Kan jag få mitt projekt sponsrat av IKEA? ",
    "keywords": [
      "FAQ_Sponsor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f25cdcg1-85be-4975-934g-753265e32ggf",
    "id": "468731",
    "title": "Hur delar jag upp betalningen på min order?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "1305c079-6d83-480g-b2gb-f8f4b6c19b4e",
    "id": "413525",
    "title": "Hur samlar jag poäng med IKEA Family?",
    "keywords": [
      "FAQ_Family_SecondCategory_C_GC_Three",
      "FAQ_Rewards_Accumulate_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e1e0cd4c-36c4-4fdd-8fc5-03fe9c045689",
    "id": "106076",
    "title": "Var hittar jag mina sparade köksritningar?",
    "keywords": [
      "FAQ_Kitchen_Drawing_Design",
      "FAQ_Kitchen_PlanAndDesign_C_GC_Four",
      "planeringsverktyg kök"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g77eg050-6dc1-4050-b798-9b5176cfg384",
    "id": "106037",
    "title": "Hur länge har jag öppet köp på varor från IKEA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "d31bb80f-4dce-44cg-bc6e-45ed745bf58e",
    "id": "106045",
    "title": "Kan jag returnera min vara på vilket varuhus som helst?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "81egfg1c-1c45-4d45-g96g-735ee90e009d",
    "id": "504654",
    "title": "Varför ska jag välja inburen leverans?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6929geb9-ed69-44d2-g017-egf718fg59cb",
    "id": "505028",
    "title": "Varför ska jag välja leverans med postpaket?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d3fce970-6g85-4839-8b3b-31c46dd89d4e",
    "id": "468562",
    "title": "Hur fungerar leveranser för företag?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "d839cd5c-fd59-423g-gc7b-928c00e7eg33",
    "id": "8148",
    "title": "Kan jag använda mitt IKEA Family medlemsskap utomlands?",
    "keywords": [
      "Family utomlands",
      "IKEA Family medlemskap utomlands"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2df12f86-e679-43e9-8206-8f27bcf9e2ee",
    "id": "105767",
    "title": "Kan jag få mina varor levererade till ett utlämningsställe?",
    "keywords": [
      "FAQ_HowToShop_PickupPoint",
      "hämta på valt utlämningsställe",
      "hämta själv",
      "hämta upp",
      "leverans",
      "pick up point",
      "pick up-point",
      "pick-up point"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1c894dee-6ccb-4gb8-8684-f751b20f878f",
    "id": "289550",
    "title": "Vilka leveransalternativ kan jag välja på?",
    "keywords": [
      "FAQ_Kitchen_PurchaseAndDelivery_C_GC_Two",
      "hur fungerar IKEAs leveranser",
      "köksleverans",
      "varför kan jag inte beställa hemleverans"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bf898de4-7983-4ce4-870d-29e4bc6f2908",
    "id": "147164",
    "title": "Vad kostar en hemleverans från IKEA?",
    "keywords": [
      "frakt",
      "leveranspris",
      "vas kostar en leverans"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "77c4d7cc-347b-4g4b-g1b2-g9be15450386",
    "id": "8466",
    "title": "Kan någon annan hämta min Click & collect-order?",
    "keywords": [
      "Budperson",
      "Hinner inte",
      "annan person",
      "annan person hämta click and collect",
      "bud vid upphämtning",
      "ej hämta",
      "försenad",
      "kan ej",
      "upphämtning",
      "ändra namn",
      "ändra namn order"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ef1fee7f-6d64-4611-b52e-0f0b4f9f2d2b",
    "id": "22609",
    "title": "Kan jag ändra leveransadressen eller telefonnummer i min order? ",
    "keywords": [
      "ankarlänk",
      "byta",
      "byte av leveransadress",
      "leveransadress",
      "ändra adress",
      "ändra adressen",
      "ändra leveransadress"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3b13637d-5855-4e46-bgcd-9533g0gfegg9",
    "id": "106008",
    "title": "Jag saknar en eller flera varor i min leverans, hur gör jag?",
    "keywords": [
      "1 vara fattas",
      "1 vara saknas",
      "FAQ_Kitchen_AfterPurchaseAndGuarantee_C_GC_Four",
      "ankarlänk",
      "ej fått allt i leverans",
      "en vara fattas",
      "en vara saknas",
      "fattar paket",
      "fattas del",
      "fattas kolli",
      "fattas produkt",
      "fattas produkter i min leverans",
      "fattas vara",
      "fel vara",
      "felaktig order",
      "felbeställning",
      "felleverans",
      "jag har fått fel vara levererad",
      "leverans ej komplett",
      "leverans ofullständig",
      "leveransfel",
      "missing item",
      "post nord",
      "postnord",
      "reklamera",
      "saknad produkt",
      "saknad vara",
      "saknar en del i min leverans",
      "saknar vara",
      "saknar vara beställning",
      "saknar vara i beställning",
      "saknar vara i min leverans",
      "saknas del",
      "saknas en del i min leverans",
      "saknas kolli",
      "saknas paket",
      "saknas produkter",
      "saknas vara order",
      "saknas varor",
      "saknas varor beställning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c876g070-c74f-4965-b137-8d9273d06b59",
    "id": "106056",
    "title": "Hur går det för min order?",
    "keywords": [
      "Status",
      "leveransbesked",
      "leverenstid",
      "levering",
      "mitt paket",
      "order",
      "orderstatus",
      "spåra beställning",
      "spåra order",
      "var",
      "var finns",
      "var är min order"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ggec303f-68e1-4993-g68c-g271gd828132",
    "id": "105753",
    "title": "Vad är leveranstiden när jag handlar på IKEA? ",
    "keywords": [
      "köksleverans",
      "leverans servicar",
      "leverans service",
      "leveransservicar",
      "leveransservice",
      "leveranstid",
      "leveranstider",
      "vad är era leveranstider"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "377085f8-3c7e-47g9-9f96-8e23564e0ggd",
    "id": "6995",
    "title": "Vad är leveranstiden för kök och bänkskivor från IKEA?",
    "keywords": [
      "FAQ_Kitchen_PurchaseAndDelivery_C_GC_Four",
      "köksleverans"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "91b434d3-75f6-4442-8f5f-f92603714gg7",
    "id": "8028",
    "title": "Vad ingår i fraktkostnaden? ",
    "keywords": [
      "fraktpris",
      "ingår i frakten",
      "ingår i leverans",
      "leveranspriset"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "434468g6-bbgd-4826-87gd-22c9be7c10b0",
    "id": "8462",
    "title": "Kan jag returnera en produkt direkt via transportören?",
    "keywords": [
      "chaufför",
      "retur",
      "ångerköp",
      "ångrat mig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c8ee4e97-6fc8-454e-809d-317fecddce46",
    "id": "6892",
    "title": "När kan jag hämta min Click & collect-order?",
    "keywords": [
      "C&C",
      "click and collect",
      "pick up"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b5g5930g-f70b-4c80-83e9-1cg82027f7b1",
    "id": "395517",
    "title": "Kan jag ändra tiden för upphämtning av min Click & collect-order? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "3bcbc9d1-f609-40c1-b935-4e92b36002b2",
    "id": "59199",
    "title": "Kan jag ändra min Click & collect-order?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "70fce2gb-e0f8-4d38-936g-egggcdg1f145",
    "id": "6809",
    "title": "Kan jag lägga till servicetjänster på min Click & collect-order?",
    "keywords": [
      "FAQ_Add_Remove_Services",
      "click & collect",
      "hemfixarna",
      "servicetjänst"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "851bg7gf-c7cd-4861-be7b-b8e298702b8f",
    "id": "123366",
    "title": "Kan jag beställa en vara som finns i lager på ett annat varuhus?",
    "keywords": [
      "beställa till varuhus",
      "leverans mellan varuhus",
      "leverans till varuhus",
      "skicka mellan varuhus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "48e17e5f-bfe0-4116-bf77-691b9c91g355",
    "id": "9446",
    "title": "Jag har inte fått min leverans, vad ska jag göra?",
    "keywords": [
      "FAQ_Track_Order",
      "hemkörning",
      "inte kommit",
      "leverans ej kommit",
      "min leverans har inte kommit",
      "min leverans är sen",
      "post nord",
      "postnord",
      "saknad leverans",
      "saknad order",
      "utebliven leverans"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dbfc5c0e-1g79-40d2-9920-g2e6df25g0b3",
    "id": "105748",
    "title": "Vad kostar en leverans från IKEA?",
    "keywords": [
      "delivery cost",
      "fraktavgift",
      "hemleverans",
      "hur mycket kostar leverans",
      "kostnad leverans",
      "leverans",
      "leveranskostnad"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d59954fe-3056-4131-911d-78g43c3fd978",
    "id": "369476",
    "title": "Var kan jag handla med mitt IKEA presentkort eller tillgodokort?",
    "keywords": [
      "FAQ_IKEA_Gift_Card_Abroad",
      "FAQ_Payment_ThirdCategory_C_GC_Five",
      "abroad",
      "countries",
      "gift cards",
      "tillgodo",
      "tillgodokort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g5ecf16f-78gf-4994-8dd8-085681fc5950",
    "id": "37747",
    "title": "Hur hög temperatur klarar IKEAs kokkärl som är godkända att användas i ugn?",
    "keywords": [
      "temperatur"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "26e183e5-cegd-4194-8199-16f99g37f0b8",
    "id": "504995",
    "title": "Varför ska jag välja trottoarleverans?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "78fdb37g-g238-4g74-gd94-84d0eee8cge1",
    "id": "504991",
    "title": "Vilka är de generella begränsningarna och villkoren för leverans?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "84678ef6-45cb-4252-b793-e4b0ef9g0104",
    "id": "504325",
    "title": "Vilka leveransalternativ erbjuder IKEA?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "798540g8-3196-40d7-bd88-c98282geg2bd",
    "id": "504628",
    "title": "Hur väljer jag mellan olika leveransalternativ?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "57b836e0-c37e-4874-g532-4ec60e2ceb47",
    "id": "27642",
    "title": "Varför slår lådan i vattenlåset i diskbänksskåpet?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "0egcf61f-015g-4gb4-854e-86g0b1b6d602",
    "id": "33373",
    "title": "I vilka färger finns ENHET fronter?",
    "keywords": [
      "Enhet",
      "dörr",
      "front",
      "lucka"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "950fcf94-cg92-46c7-9f53-111790bbf757",
    "id": "297670",
    "title": "Vilken kredit har mitt företag och kan jag ändra den?",
    "keywords": [
      "FAQ_Business_ThirdCategory_C_GC_Four",
      "Företagsfaktura",
      "Företagskonto",
      "Kredit"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cf563491-f3d5-46c8-8487-7f6d01b32499",
    "id": "1003236",
    "title": "Har någon av IKEAs hällar eller ugnar 3 fas?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "20c89879-848f-4cec-b224-4786cc3ec39c",
    "id": "6769",
    "title": "Kan en annan person handla med mitt IKEA DELBETALA kort?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "4e703986-f5be-4f2e-9f4e-e80f3dc91917",
    "id": "462506",
    "title": "Hur hanterar jag mina sparade listor på mitt IKEA konto?",
    "keywords": [
      "FAQ_Favourites_List"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "97510e6b-d745-42cf-8496-7c359943dg88",
    "id": "490802",
    "title": "Vad är IKEAs returpolicy för madrasser?",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g587g094-4bgb-44fc-b562-b644gf303334",
    "id": "467531",
    "title": "Kan jag beställa produkter för leverans till Åland?",
    "keywords": [
      "GenAIDelivery"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "a693aecf-bb89-4596-8835-1bfc2e1c51b5",
    "id": "1001795",
    "title": "Vilken FÖRBÄTTRA täcksida och sockel passar till min köksfront?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "4607d419-e21e-47b5-9gbd-55d362557579",
    "id": "375168",
    "title": "Var kan jag köpa reservdelar till vitvaror? ",
    "keywords": [
      "BEJUBLAD",
      "C004490",
      "Diskmaskinskorg",
      "FAQ_Appliances_Spare_Parts",
      "ankarlänk",
      "aquastop slang",
      "aquastopslang",
      "arcelik",
      "avloppsslang",
      "avloppsslangsats",
      "bakplåt",
      "barnlås",
      "barnspärr",
      "behöver fler plåtar",
      "beko",
      "bestickkorg",
      "bestickskorg",
      "bosch",
      "diskkorg",
      "diskmaskin fjäder",
      "diskmaskinsfjäder",
      "dåtid",
      "dåtid ugn",
      "elcare",
      "electrolux",
      "elica",
      "faber",
      "framtid",
      "fryslucka",
      "fryslåda",
      "fryslådor",
      "förlängningsslang",
      "galler till ugn",
      "glastallrik",
      "hjul",
      "hållare glas",
      "inloppsslang",
      "knapp raffinerad",
      "kontrollvred",
      "korg/korghjul diskmaskin",
      "korgen",
      "korghjul",
      "korgsats hjul",
      "kretskort",
      "köksfläkt",
      "köttermometer",
      "magnetventil",
      "magnetventil hjälpsam",
      "meab",
      "midea",
      "nutid",
      "plåt",
      "plåtar till ugn",
      "reparation",
      "reparation av vitvaror",
      "reservdel anrätta",
      "reservdel diskmaskin",
      "reservdel kylskåp",
      "reservdel lampa ugn",
      "reservdel micro",
      "reservdel ugn",
      "reservdel vitvara",
      "slang koppling",
      "slangkoppling",
      "spak",
      "stektermometer",
      "teleskopsskena",
      "teleskopsskenor",
      "tillopp hjälpsam",
      "tömningsslang",
      "ugn list",
      "ugn termomter",
      "ugnsgaller",
      "ugnsglas",
      "ugnslampa",
      "ugnslist",
      "ugnslucka",
      "ugnsplåt",
      "ugnsplåt 45x",
      "ugnsreglage",
      "vred",
      "whirlpool"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "116bg78f-3062-45de-88g9-5577f70e350d",
    "id": "375208",
    "title": "Vad kan jag göra om jag har problem med min beställning från ASCI?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "1722c654-8g38-47bb-b650-1f383cfb3e2f",
    "id": "5124",
    "title": "Kan jag använda mitt utländska IKEA Family kort i Sverige?",
    "keywords": [
      "Utländskt IKEA Family"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "180612d8-519e-4d2e-g86g-e5c9d6g5g8ff",
    "id": "8563",
    "title": "Hur ser jag vem som har tillverkat min vitvara?",
    "keywords": [
      "Electrolux",
      "Whirlpool",
      "arcelik",
      "bosch",
      "faber",
      "grundig",
      "midea",
      "tillverkare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "348a18fc-d3c2-4536-97c2-df2acf4bb9fb",
    "id": "1001950",
    "title": "Hur kan jag beställa ett presentkort? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "1e289154-gd73-4d13-8b25-b30gdf7c0gb5",
    "id": "190663",
    "title": "Hur hittar jag färgkoden på min produkt?",
    "keywords": [
      "FAQ_Product_Colour",
      "NCS",
      "NCS-kod",
      "NCS-koder",
      "färgkod kök",
      "färgkod på kök",
      "färgkoder",
      "färgnummer",
      "färgspecifikation",
      "pax färgkod"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5831897b-9790-4e32-8201-d32gf3c9eg62",
    "id": "20764",
    "title": "Min soffa har blivit nopprig, vad gör jag? ",
    "keywords": [
      "ankarlänk",
      "min fotpall har blivit nopprig",
      "min fåtölj har blivit nopprig",
      "min klädsel har blivit nopprig",
      "min stol har blivit nopprig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d9c07548-3g9d-4895-bg17-e88517211339",
    "id": "51149",
    "title": "Kan jag köpa extra kantlister till min bänkskiva?",
    "keywords": [
      "EKBKACKEN",
      "SÄLJAN",
      "bänkskiva",
      "bänkskivor",
      "ekbacken",
      "kant",
      "kantlister",
      "lister",
      "säljan"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2e9907ee-e216-4806-bd00-e02cgc741b1d",
    "id": "60618",
    "title": "Hur vet jag om mina kokkärl kan användas på en induktionshäll? ",
    "keywords": [
      "funkar grytan på induktion",
      "funkar mitt kokkärl på induktionshäll",
      "funkar stekpannan på induktion",
      "kan min kastrull användas på induktion",
      "vilka grytor funkar på induktion"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0ebbdfb0-e786-41b4-8bdc-7d2e3d880186",
    "id": "1001339",
    "title": "Kan jag använda ESPEVÄR klädsel på madrassbottnen LYNGÖR?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "daa4d8e5-dcd7-4365-8748-c463765879b8",
    "id": "1001340",
    "title": "Passar LYNGÖR klädsel på min madrassbotten? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "42ef7d69-g127-450f-g71d-fb3c1b8e6242",
    "id": "71605",
    "title": "Hur kopplar jag om KNYCKLAN diskmaskinsavstängning med fjärrkontrollen?",
    "keywords": [
      "Knycklan",
      "fjärrkontroll",
      "synka",
      "synkronisera"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "28fc09g9-d7b7-4d75-b64g-f7900d8bd1c7",
    "id": "449068",
    "title": "Hur fungerar VALLHORN rörelsesensor?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "e47fec6c-514d-4b43-9854-eb6g9df9b41f",
    "id": "150279",
    "title": "Kan jag betygsätta IKEAs produkter?",
    "keywords": [
      "FAQ_Product_Reviews",
      "betyg",
      "betygsätta",
      "recension"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g6ec997c-b070-4883-967f-3dc9df3gdb20",
    "id": "176918",
    "title": "Vad kan jag göra själv när kundservice har stängt?",
    "keywords": [
      "Corporate_Welcome",
      "chat",
      "chatt",
      "chatta",
      "hallå",
      "hej",
      "hejsan",
      "hjälp",
      "onlinechatt",
      "tjena"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e6c859c9-46g3-400b-8287-463c7407d1d2",
    "id": "417027",
    "title": "Kan jag boka bortforsling för min säng eller soffa?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8c96b6gg-cd1g-4b8c-bd94-f14647b81bec",
    "id": "122038",
    "title": "Vad innebär Sov på saken-garantin?",
    "keywords": [
      "90",
      "Bytesrätt",
      "Dagar",
      "För",
      "Garanti",
      "Garantin",
      "Hård",
      "Innebär",
      "Madrass",
      "Madrassen",
      "Mjuk",
      "Resårbotten",
      "Resårmadrass",
      "Sov på saken",
      "Vad",
      "Vänja",
      "Vänjer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "742gcb4f-f38b-47d0-bd24-g3744c8c6d93",
    "id": "5880",
    "title": "Hur fungerar avbetalning av IKEA Finansiering Lån?",
    "keywords": [
      "kan jag beställa på avbetalning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "03d3d233-e918-42a2-86c5-48144002cf7c",
    "id": "1003036",
    "title": "När släpps AROMATISK 2025 kollektion?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "e86gb982-954f-46c6-81bb-3f634b9g2102",
    "id": "431063",
    "title": "Kan jag använda min lunchkupong till julbordet?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "218043bg-8d66-4ed4-9bec-12bg17b96e7g",
    "id": "28043",
    "title": " Ingår hyllplan när man köper en METOD stomme?",
    "keywords": [
      "Metod",
      "hyllplan",
      "ingår",
      "utrusta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "80fge3b7-1456-426d-b08d-9579fb297gb9",
    "id": "25900",
    "title": "Min IKEA företagsfaktura saknar referens, hur gör jag då?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "b4efgd40-cfe8-4cec-gfde-4gcc1c0262cg",
    "id": "122069",
    "title": "Kan jag returnera en vara som jag öppnat eller monterat?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8c21e053-5137-4500-8b48-ee8c9a04259b",
    "id": "1002514",
    "title": "Vilket datum lanseras kollektionen OMMJÄNGE hos IKEA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "71e73e68-9668-46g0-g008-gf9b3c232706",
    "id": "5135",
    "title": "Varför skiljer sig priserna på IKEAs produkter i olika länder?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8f6db2gg-3d3f-46f0-b7b6-ec213ed7b018",
    "id": "58371",
    "title": "Hur kommer jag i kontakt med IKEAs företagsavdelning?",
    "keywords": [
      "företagsbeställning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "67036665-6362-418g-g9d3-3g670d5c4008",
    "id": "6650",
    "title": "Kan jag planera och anpassa mitt ENHET kök själv?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6718e9c0-e70d-4c32-a611-af3cdd3fdafc",
    "id": "1002261",
    "title": "Hur fungerar en fullmakt för företag?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "d60c849d-c8d6-4165-g9fe-e5b4g70e36c6",
    "id": "29596",
    "title": "Kan jag fabriksåterställa mina IKEA Home Smart-produkter?",
    "keywords": [
      "FYRTUR",
      "KADRILJ",
      "fabriksinställning",
      "signalförstärkare",
      "styrbar",
      "trådfri",
      "återställning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bgc769ce-209b-44f9-96e1-d94d122d4b01",
    "id": "6891",
    "title": "Kan jag frångå IKEAs råd och anvisningar?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "g65bcb0d-47e9-49fc-83d6-1704e64329bb",
    "id": "42434",
    "title": "Hur stora tallrikar får plats i IKEAs diskmaskiner?",
    "keywords": [
      "diskad",
      "diskmaskin",
      "fat",
      "funputsad",
      "hur stor",
      "hygienisk",
      "lagan",
      "medelstor",
      "porslin",
      "proffsig",
      "rengöra",
      "renodlad",
      "sänka korgen",
      "tallrik",
      "tallrikar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "41d9dc4b-3716-4401-8g1e-dd42bf71e918",
    "id": "118917",
    "title": "Har jag öppet köp på sängkläder, täcken och kuddar?",
    "keywords": [
      "påslakan",
      "sängtextilier"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "27f35bc4-0g1g-4cg3-80b2-3gf4c7db4cgf",
    "id": "8566",
    "title": "Var hittar jag beslagen för att montera min fläkt?",
    "keywords": [
      "beslag",
      "fläkt",
      "montering",
      "skruvar",
      "var finns skruvarna"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b63g60d5-9de2-43g2-bg68-ffc237f4b89c",
    "id": "8567",
    "title": "Var hittar jag beslagen för att montera min diskmaskin?",
    "keywords": [
      "Diskmaskinsfront",
      "beslag",
      "diskmaskin",
      "saknar",
      "skruvar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e48gd66c-6d31-43b5-8d04-e8ge2d08f1gf",
    "id": "6289",
    "title": "Hur hittar jag utgångsdatumet för mitt IKEA Finansiering Lån?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "9366bfde-d812-46b4-bb4c-g49g1g63bbcg",
    "id": "37359",
    "title": "Hur stort är hålet för blandaren på IKEAs tvättställ?",
    "keywords": [
      "storlek blandarhål",
      "tvättställ"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1d138bgb-2b8c-425b-b9fe-gb6bd6ccdfb0",
    "id": "39455",
    "title": "Vilken typ av madrass rekommenderar IKEA till någon som sover på rygg?",
    "keywords": [
      "madrass",
      "ryggsovare",
      "sov"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2f9ce941-69f2-4243-8c19-2846c0cf6d40",
    "id": "32206",
    "title": "Finns det översvämningsskydd eller överfyllnadsskydd till RÄNNILEN vattenlås?",
    "keywords": [
      "10044930",
      "ENHET",
      "Finns",
      "Ingår",
      "Inte",
      "Integrerat",
      "Reservdel",
      "Reservdelsnummer",
      "RÄNNILEN",
      "Systemet",
      "TVÄLLEN",
      "Tvättställ",
      "Vattenlås",
      "Översvämningsskydd",
      "Översvämningsskyddet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "44e8510c-e252-4b8f-8636-02e3cf74ee95",
    "id": "201264",
    "title": "Vad kan jag köpa i Swedish Food Market?",
    "keywords": [
      "FAQ_Food",
      "IKEA ordbok",
      "food",
      "matmarknad",
      "svensk mat"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "11360ddd-de11-4eg2-bg56-432e5c9fd6c7",
    "id": "39072",
    "title": "Hur höga är UTRUSTA och KNIVSHULT innerlådfronter? ",
    "keywords": [
      "UTRUSTA innerlådfront"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cde13205-9gdb-4644-b370-9c0b8894b556",
    "id": "180486",
    "title": "Kan jag köpa en ny skärm till min ÅRSTID lampa?",
    "keywords": [
      "beställa årstid",
      "lampskärm ÅRSTID",
      "ny lamspkärm",
      "årstid lampskärm"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "517ebdc5-873e-47fb-b99g-6f9ce6554861",
    "id": "118832",
    "title": "Varför följer det inte med lösa skruvar till UTRUSTA gångjärn?",
    "keywords": [
      "UTRUSTA gångjärn"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "52fdcf7f-d275-4579-8071-81ef8gc43c38",
    "id": "6765",
    "title": "Kan Hemfixarna även installera kök?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "163ff663-e02g-4775-b86e-7e59g2ge1bb5",
    "id": "13668",
    "title": "Vad gör jag om jag inte är nöjd med min servicetjänst?",
    "keywords": [
      "ankarlänk",
      "dålig anslutning",
      "dålig anslutning i planeringsmöte",
      "dålig service",
      "hemfixarna monterade dåligt",
      "hemfixarna monterade inte klart",
      "hemleverans",
      "installationsservice",
      "klagomål service",
      "leveransservice",
      "monteringsservice",
      "otrevlig",
      "otrevlig chaufför",
      "otrevlig montör",
      "planeringsmöte",
      "reklamation service",
      "servicetjänst"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1gb2g6e9-f5fc-4e6d-b275-b95cf493eb0d",
    "id": "177335",
    "title": "Hur vet jag vilken madrass, kudde eller täcke som passar mig bäst? ",
    "keywords": [
      "FAQ_Comfort_Guide"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "eaf40648-4d3f-4ce6-9f1b-a206ceaf092b",
    "id": "1002650",
    "title": "Kan jag använda induktionshäll om jag har en pacemaker?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "efb64576-a8f4-4999-9411-306cf4df369a",
    "id": "1001338",
    "title": "Kan jag använda DUNVIK klädsel på madrassbotten LYNGÖR?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "5bffb6c1-7de9-4534-91ef-c80095221104",
    "id": "1002632",
    "title": "Kan jag stänga av eller plocka bort motorn på IKEAs fläktar?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6aa8dcc1-297f-4050-b34a-75536c32f651",
    "id": "1002556",
    "title": "Vad heter produkterna som Gustaf Westman designat i samarbete med IKEA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "825d2fgc-4933-43bb-g1g9-0c900bfcg6f8",
    "id": "105957",
    "title": "Hur loggar jag in på min IKEA Family profil?",
    "keywords": [
      "FAQ_Family_FourthCategory_C_GC_One",
      "family-konto",
      "ikea konto",
      "ikeakonto",
      "inlogg",
      "kvitto",
      "kvitton",
      "köphistorik",
      "logga in",
      "login",
      "min profil",
      "mina ordrar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4f26d5f2-e1c0-45a0-96e5-14b869b28481",
    "id": "1002509",
    "title": "Vad är mjukdjuren i SANDLÖPARE kollektion tillverkade av?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "e737201a-59fe-4f7c-b573-4eedded80abc",
    "id": "1002507",
    "title": "Vad heter IKEAs nya barnkollektion som släpps i höst? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "9ebb1247-6665-4dd0-8e81-fb187d63edbd",
    "id": "92876",
    "title": "Varför får jag ingen engångskod skickad till mig när jag försöker logga in på mitt IKEA Family konto?",
    "keywords": [
      "IKEA FAMILY",
      "engångskod",
      "family kod",
      "får ej engångskod för inlogg",
      "kod",
      "logga in",
      "lösenord"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "40c3901e-beb9-4950-8cd9-711c2b3141de",
    "id": "289544",
    "title": "Vilka betalningsalternativ finns när jag handlar på IKEA?",
    "keywords": [
      "FAQ_Kitchen_PurchaseAndDelivery_C_GC_One",
      "FAQ_Payment_FirstCategory_C_GC_One",
      "FAQ_Payment_Method",
      "avbetalning",
      "betala kontant",
      "betalmedel",
      "hur betalar jag när jag handlar via kundservice",
      "hur betalar jag på ikea.se",
      "hur betalar jag på varuhuset",
      "kontantbetalning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "084fd4c5-ee14-4d3d-b2df-4df2d04d1c06",
    "id": "1002442",
    "title": "När öppnar julbutiken i varuhusen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "9ebf7ccb-312c-439c-b401-89446096d5cb",
    "id": "81204",
    "title": "Varför har jag fått en faktura från SMARTSTEN?",
    "keywords": [
      "Nerostein faktura",
      "installation bänkskiva"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6d88g9e5-1251-4782-8eb7-c1423ebd0155",
    "id": "288770",
    "title": "Vilka är de bästa egenskaperna med ett KNOXHULT kök?",
    "keywords": [
      "FAQ_Kitchen_ChoosingAKitchen_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e0039716-767f-47gf-9g1b-863dgf74gd5e",
    "id": "25545",
    "title": "Vilka gångjärn ska jag ha till min METOD stomme?",
    "keywords": [
      "110",
      "125",
      "153",
      "95",
      "gångjärn",
      "metod",
      "utrusta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g1fbgge1-g68e-44ce-bf64-435b7b5g2551",
    "id": "503204",
    "title": "Vad kan jag göra med IKEAs smarta hem-produkter?",
    "keywords": [
      "FAQ_Home_Smart"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2dg198fb-5919-4d0f-9g02-8db0g7f1ff66",
    "id": "375192",
    "title": "Vad ska jag göra om jag inte hittar reservdelen till min vitvara på ASCI:s hemsida?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "ed0e6146-0c67-4dfg-9e0b-1d5778e653ff",
    "id": "35417",
    "title": "Är IKEAs tvättmaskiner kolborstfria?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "7gbf81e8-b4c9-445g-99c4-6e4ccd40d684",
    "id": "400532",
    "title": "Är solceller lönsamt för mig? ",
    "keywords": [
      "FAQ_ Solar_Panel_Profit"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "a0808e57-866b-4d23-ba8b-f7e52a44ad16",
    "id": "1001457",
    "title": "Vilken inredning kan jag ha i en tvättstuga? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8d49b562-9296-4185-8133-40ccc32faa86",
    "id": "1002342",
    "title": "Kan man öppna OPPEJEN duschdörr på två håll?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "125d818g-6ded-4g9f-g8cd-2556c9bd717g",
    "id": "462598",
    "title": "Frysen skiftar i temperatur eller har slutat producera kyla, vad beror det på?",
    "keywords": [
      "avfrosta frys",
      "avfrostning",
      "frysen skiftar temperatur",
      "temperatur i frys"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bg9f61bc-19b3-41e7-9ed4-731602349g36",
    "id": "27245",
    "title": "Hur gör jag en manuell avfrostning på en frys med eller utan No Frost-funktion?",
    "keywords": [
      "automatisk avfrostning",
      "avdunstningskärl",
      "avfrostar inte",
      "avfrostar inte sig själv nedisad",
      "avfrostning",
      "avfrostning fungerar ej",
      "droppskål",
      "no frost"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1d21e9d6-f56b-4e92-bg2f-e438f11c85cc",
    "id": "490744",
    "title": "Vad är returpolicyn för måttbeställda bänkskivor?",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dbb18fc2-7963-4d5b-b3e4-29e558085e4f",
    "id": "416660",
    "title": "Vad kan jag göra med mina poäng från IKEA Family? ",
    "keywords": [
      "FAQ_Rewards_Redeem_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c2bcc15f-d4f9-4d74-8477-eebde68bc00e",
    "id": "1002237",
    "title": "Varför behöver vi ha diskmaskinsavstängning?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c096b732-870c-46bb-9318-d4dg39d861e7",
    "id": "8558",
    "title": "Jag har ett FAKTUM kök, kan jag köpa nya vitvaror på IKEA?",
    "keywords": [
      "70 cm diskmaskinsfront",
      "diskmaskin i stomme",
      "spis"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "245e7419-f554-4472-b1c4-25554aa24a16",
    "id": "1001458",
    "title": "Hur planerar jag min tvättstuga bäst? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8fc7f425-42cc-46e4-geef-g0eg5g334f73",
    "id": "472440",
    "title": "Hur sparar jag min ritning i planeringsverktygen för att fortsätta senare?",
    "keywords": [
      "FAQ_Pax_FourthCategory_C_GC_Two",
      "FAQ_Planning_Code"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "53d89e43-bca7-4bc3-ae8f-9454eb7865a2",
    "id": "1002189",
    "title": "Vad är SVINNSMART?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "13201567-762f-42d5-g2d4-c4d6438e9117",
    "id": "383649",
    "title": "Kan jag använda mitt IKEA Family kort utomlands?",
    "keywords": [
      "FAQ_Family_FourthCategory_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "96f71153-624e-4f35-g33b-17ed8f23gce3",
    "id": "116449",
    "title": "Hur beställer jag en SVINNSMART-kasse från IKEAs restauranger?",
    "keywords": [
      "rester",
      "rester från restaurangen",
      "svinnsmart",
      "tgtg",
      "too good to go",
      "överbliven mat",
      "överbliven mat från restaurangen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4c372e26-985f-4925-g895-dec8d5fb168d",
    "id": "6884",
    "title": "Hur köper jag ett presentkort på IKEA?",
    "keywords": [
      "FAQ_IKEA_Gift_Card",
      "PRESENTKORT",
      "köpa presentkort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "facc7f14-aad1-4ddb-824c-dbc37c62c714",
    "id": "1002000",
    "title": "När släpps IKEAs nya badrumskollektion?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6320fc00-3d07-4323-8e1g-387dg3957c51",
    "id": "335357",
    "title": "Jag har köpt en produkt som nu har nedsatt pris, kan jag få mellanskillnaden tillbaka? ",
    "keywords": [
      "FAQ_Price_Guarantee",
      "kan jag få pengar tillbaka",
      "nedsatt pris",
      "prisgaranti",
      "prissänkning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5g3db54c-d385-4b62-bb8g-332f820cb6be",
    "id": "169187",
    "title": "Varför kan jag inte genomföra min beställning?",
    "keywords": [
      "kan inte handla",
      "order går inte igenom",
      "problem att beställa",
      "produktinformation",
      "saknas lagersaldo",
      "slut",
      "FAQ_Item_Not_Cart"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1e9c44gg-8cc2-4337-bed7-1cf55e5b3010",
    "id": "29139",
    "title": "Kan jag nyttja garantin på min IKEA produkt i Sverige om den är köpt utomlands?",
    "keywords": [
      "garanti",
      "ikea utomlands",
      "nyttja garanti",
      "vara köpt utomlands"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gc9c3709-46fd-4454-84bd-35877fg68f69",
    "id": "501629",
    "title": "Hur skannar jag ett rum med IKEA Kreativ?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "77f7d85c-2556-4979-a107-07161511e19b",
    "id": "1001924",
    "title": "Jag har inte fått min rabattkod, vad ska jag göra?",
    "keywords": [
      "FAQ_Ad_Hoc_Six"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1c0e1d63-4324-4642-8743-c3507d8cebd0",
    "id": "1001974",
    "title": "Finns det någon ersättare till IKEA EKEDALEN?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "1d52925b-0e3f-4126-g7fg-49c5097gc0fe",
    "id": "498845",
    "title": "Jag har inte fått mitt presentkort, vad ska jag göra?",
    "keywords": [
      "FAQ_IKEA_Gift_Card_Not_Received"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dfc3919b-g20b-4348-950d-0gbg20e2f499",
    "id": "6885",
    "title": "Vad är maxbeloppet för ett IKEA presentkort?",
    "keywords": [
      "GoGift",
      "maxbelopp",
      "maxbelopp presentkort",
      "presentkort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cdcd819g-dcg7-4ee2-g16b-b718bd721gb1",
    "id": "163614",
    "title": "Kan jag köpa IKEA presentkort på IKEA Planera och beställ enheter?",
    "keywords": [
      "IKEA planera och beställ",
      "köpa",
      "planeringsstudio",
      "presentkort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f48ffcg2-g6bd-481e-9dg2-74869cg9g7d0",
    "id": "36044",
    "title": "Hur fungerar TRÅDFRI rörelsesensor?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c8084gb2-bbdb-4b4d-8154-00b9g998g133",
    "id": "36110",
    "title": "Kan jag koppla samman min SYMFONISK högtalare med min TV?",
    "keywords": [
      "Symfonisk",
      "sonos",
      "tv"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d8f3b532-2513-4d88-97b0-e425d9f5d9g6",
    "id": "191478",
    "title": "Vad är Matter och vad betyder det?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "73450b6c-ef80-4dd7-bd3f-be141fa8bc1b",
    "id": "1001847",
    "title": "Kan jag placera min tvättmaskin ovanpå METOD skåp? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "54c41982-24ee-42d7-9797-e3g1e272cdee",
    "id": "191487",
    "title": " Vad är Zigbee och vad betyder det?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "17dec71d-95cd-442f-g988-9b4277f0eb94",
    "id": "491167",
    "title": "Kan jag returnera produkter på IKEAs planeringsstudior eller på ett Click & collect område?   ",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "860f1fc3-gcfb-4f9d-8572-de54c00575e8",
    "id": "490298",
    "title": "Vad är IKEAs returpolicy?",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8e86d307-2e51-4565-gg2e-gd302bg85161",
    "id": "490920",
    "title": "Kan jag returnera en produkt i varuhuset?",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "94494f9f-f4bb-48ed-8648-501876344b17",
    "id": "491214",
    "title": "Kan jag uppgradera min madrass om jag lämnar tillbaka min gamla från IKEA?",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dee3b478-7406-4bc6-gd9g-05b0342500f4",
    "id": "490804",
    "title": "Kan jag returnera en madrass efter ett år om det uppstår kvalitetsproblem?  ",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "42fb778g-1d2c-4dfg-877d-d5b24082e6g8",
    "id": "490391",
    "title": "Vad är returpolicyn för produkter köpta från Cirklulärbutiken?",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "edf31ffe-15f4-45ce-9725-3dc1dd80c7d8",
    "id": "111419",
    "title": "Är TRÅDFRI kompatibel med Apple HomeKit eller Amazon Alexa?",
    "keywords": [
      "TRÅDFRI",
      "alexa",
      "amazon",
      "apple",
      "homekit",
      "kompatibel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b5d12d50-9e22-45b9-91b3-4g189g02c783",
    "id": "345153",
    "title": "Hur återställer jag min TRÅDFRI lampa? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "1d149858-f7bf-4e8d-bffd-809dd4868b2g",
    "id": "36142",
    "title": "Är TRÅDFRI lampor kompatibla med Google Home eller Google Assistant?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "01472c63-5849-49eg-bfce-47dd1e0d0g3b",
    "id": "190905",
    "title": "Vad är skillnaden mellan TRÅDFRI gateway och DIRIGERA hubb?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "b36d29c9-269e-4893-9804-4e44814d0427",
    "id": "1001459",
    "title": "Kan jag få hjälp med att planera min tvättstuga? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "0765496g-g168-4859-gcd2-e3df3f442961",
    "id": "490904",
    "title": "Kan IKEA hämta min gamla madrass om jag vill returnera den?",
    "keywords": [
      "GenAIReturns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d0800dbc-6c60-4b7e-bf07-4f84e6c08827",
    "id": "404220",
    "title": "Vad är \"till sängs med IKEA\"? ",
    "keywords": [
      "In bed with IKEA",
      "till sängs med IKEA"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b69f2dd2-566g-48g4-bgf8-b81f454fe0eg",
    "id": "37450",
    "title": "Var ska jag montera gångjärnen på PAX garderober?",
    "keywords": [
      "201",
      "236",
      "Cm",
      "Dörr",
      "Dörren",
      "Funktion",
      "Garderob",
      "Garderober",
      "Garderobsdörrarna",
      "Garderobssystem",
      "Grå",
      "Gråa",
      "Gångjärn",
      "Gångjärnen",
      "Hamnar",
      "Hur",
      "Hål",
      "Hålet",
      "Hög",
      "Höga",
      "Höger",
      "Höjd",
      "Höjder",
      "KOMPLEMENT",
      "Längst",
      "Mitten",
      "Mjukstängande",
      "Montera",
      "Monteras",
      "Nedersta",
      "Ner",
      "Nerifrån",
      "Olika",
      "PAX",
      "Plastbeslag",
      "Räknat",
      "Ska",
      "Stomme",
      "Stommen",
      "Uppifrån",
      "Var",
      "Varför",
      "Vilka",
      "Vänster",
      "Översta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9108536b-2f7b-48c2-ad39-ada45b132f9d",
    "id": "1001616",
    "title": "Kan jag lägga en bänkskiva direkt på min tvättmaskin?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "19059bba-8e12-4beb-b7ce-83863755fbc7",
    "id": "1001617",
    "title": "Vilken bänkskiva kan jag ha i min tvättstuga?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "455864c4-3b8f-4c3g-bdfe-f5e88bde26e7",
    "id": "120477",
    "title": "Vad gör jag om den utdragbara pipen inte går tillbaka hela vägen på min blandare?",
    "keywords": [
      "Blandare",
      "Blandarhalsen",
      "Fel",
      "Felet",
      "IKEA",
      "Kontrollera",
      "Kök",
      "Packning",
      "Packningen",
      "Pipen",
      "Reklamation",
      "Utdragbar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "59g52757-77db-4edg-be7c-79633gb1d1c8",
    "id": "297680",
    "title": "Hur får jag utbetalt mitt tillgodohavande från mitt företagskonto?",
    "keywords": [
      "Faktura",
      "Företagsfaktura",
      "Företagskonto",
      "Kort",
      "Kredit",
      "Kundnummer",
      "Tillgodo"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "799f2273-b4af-4d75-84dd-0023d7edcc07",
    "id": "1001254",
    "title": "Kommer HÖSTAGILLE att släppas igen 2025?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "32f42d08-5264-4d46-gg34-g16677838077",
    "id": "55093",
    "title": "Hur skickar jag in mitt produktförslag till IKEA? ",
    "keywords": [
      "förslag",
      "hur skickar jag in ett nytt förslag",
      "jag vill erbjuda ikea mina produkter",
      "produktförslag"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "17e688c4-57e4-4f90-9dc2-1f63915f06e3",
    "id": "58426",
    "title": "När grundades IKEA?",
    "keywords": [
      "IKEA historia",
      "grundade",
      "historia",
      "hur började det",
      "hur gammalt är ikea",
      "hur länge har ikea funnits",
      "när startade ikea"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "395f7f35-c56c-40bg-ge1d-99c1e82g5232",
    "id": "160449",
    "title": "Var hittar jag lediga jobb på IKEA?",
    "keywords": [
      "FAQ_Work_at_IKEA",
      "har ni några lediga jobb i min stad",
      "jobba hos er",
      "jobba på ikea",
      "lediga jobb",
      "rekrytering",
      "sommarjobb",
      "söka jobb på IKEA"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b73edd1b-cb20-46f5-g94c-664ccg6ffdf8",
    "id": "37876",
    "title": "Säljer IKEA spjälsängar där man kan justera höjden på långsidan?",
    "keywords": [
      "Baby",
      "Barn",
      "Barnens IKEA",
      "Bebis",
      "Nedåt",
      "Spjälsäng",
      "Spjälsängar",
      "Trycka",
      "Uppåt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "79b03f36-442e-4770-9c6f-gb053g6800b0",
    "id": "58365",
    "title": "Har ni några färdiga lösningar för inredning av bostäder? ",
    "keywords": [
      "företagslösning",
      "ikea för företag",
      "nyckellösning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g18657bc-3ee2-46e1-gf57-63dbdb590bc7",
    "id": "278603",
    "title": "Vilka är de bästa egenskaperna med ett METOD kök?",
    "keywords": [
      "FAQ_Kitchen_ChoosingAKitchen_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fg1591g7-7332-48f4-gb6d-41f2c02cd82f",
    "id": "5112",
    "title": "Vilken typ av montering utför Hemfixarna?",
    "keywords": [
      "Hemfixarna",
      "ROT avdrag",
      "montering",
      "servicetjänst"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d277b4gg-6f63-4gd4-g98g-8016cbf6cg50",
    "id": "58293",
    "title": "Hur tar jag hand om min produkt på bästa sätt? ",
    "keywords": [
      "Sköta om",
      "missfärgning",
      "olja",
      "rengöra",
      "slitage",
      "ta hand om"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3f163631-d717-421g-946d-08e98g0gg1ee",
    "id": "37877",
    "title": "Hur testas IKEAs produkter i barnsortimentet?",
    "keywords": [
      "barn",
      "barnens IKEA",
      "barnsäkerhet",
      "produkttester",
      "säkerhet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "47egfd5b-f18d-4ce9-9g82-b7gg34d5g009",
    "id": "60128",
    "title": "Kan jag returnera en måttbeställd produkt? ",
    "keywords": [
      "custom",
      "custom made",
      "skräddarsydd",
      "specialbeställd",
      "specialbeställda"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "94f1704e-1952-4b9d-9399-f0fcdfb2d23e",
    "id": "38696",
    "title": "Varför ska jag välja en kudde med memoryskum?",
    "keywords": [
      "kuddar med memoryskum",
      "memory foam",
      "memory skum",
      "memoryfoam"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "69680815-2f62-45bg-92be-d392d002ec9b",
    "id": "472232",
    "title": "Hur väljer jag inredning till PAX?",
    "keywords": [
      "FAQ_Pax_ThirdCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b97f2d37-g4g3-4g17-97c1-bg60d8b0g0e6",
    "id": "21065",
    "title": "Innehåller IKEAs produkter några kemikalier? ",
    "keywords": [
      "innehåll",
      "kemikalier",
      "statement",
      "säkerhet",
      "trygghet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g6gbde76-781e-483f-8g34-28dc6c72254f",
    "id": "106072",
    "title": "Jag har glömt kvar eller tappat något i ett varuhus, vart vänder jag mig?",
    "keywords": [
      "FAQ_Lost_Found",
      "borttappad",
      "borttappade",
      "borttappade föremål",
      "borttappat",
      "borttappat föremål",
      "glömt",
      "hittegods",
      "kvarglömt",
      "nycklar",
      "upphittat"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "160cce2b-d8g7-41e1-gf31-0fb09b7751db",
    "id": "6882",
    "title": "Kan jag som företagskund hos IKEA boka Hemfixarna?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "b90f9cgd-d4e8-4507-82g3-d30290gf1g16",
    "id": "58358",
    "title": "Kan ni hjälpa vårt företag att planera kontorsinredning?",
    "keywords": [
      "ikea för företag",
      "kontorsinredning",
      "kontorsplanering",
      "planerar och inreder kontoret"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6f1c2g55-b04e-4gg2-9135-8c1g69518123",
    "id": "305637",
    "title": "Hur betalar jag som företagskund?",
    "keywords": [
      "FAQ_B2B_Payment",
      "FAQ_Business_ThirdCategory_C_GC_Two",
      "FAQ_Payment_FirstCategory_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c3ec329d-6b8c-4396-b4bd-1d67bg6dc83b",
    "id": "18521",
    "title": "Hur fungerar era produkter med trådlös laddning? ",
    "keywords": [
      "IKEA ordbok"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "094ee34e-8c80-413g-85bc-89g4cg0db744",
    "id": "29482",
    "title": "Erbjuder IKEA mätservice och förbesiktning av kök?",
    "keywords": [
      "boka mätarservice",
      "boka mätservice",
      "mättjänst"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gg36df6b-5d79-435f-924e-2d6e90529383",
    "id": "289659",
    "title": "Jag vill montera mitt IKEA kök själv, hur gör jag? ",
    "keywords": [
      "FAQ_Kitchen_Install_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cd150125-2dgd-4261-g0dc-095de20b48e9",
    "id": "18508",
    "title": "Vad innebär det när en livsmedelsprodukt är UTZ-/Rainforest Alliance certifierad? ",
    "keywords": [
      "IKEA ordbok",
      "UTZ",
      "certifiering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "166c4888-c9d5-4e7c-bc5b-6d5dd8g7088c",
    "id": "100144",
    "title": "Kan jag montera SKYTTA skjutdörrsystem själv?",
    "keywords": [
      "Montera SKYTTA",
      "SKYTTA",
      "skytte"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "78ff21c0-5870-4g69-b581-7gbfcd9b3fg2",
    "id": "148413",
    "title": "Kan jag sälja tillbaka mina begagnade IKEA möbler till er?",
    "keywords": [
      "FAQ_Circular_Services",
      "begagnat",
      "buy back",
      "fynd",
      "gamla",
      "hand",
      "köp",
      "retur",
      "second",
      "second hand",
      "secondhand",
      "värdera",
      "återköp",
      "återvinning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dgc5bdg1-8c17-40bc-g18c-91g529888fgc",
    "id": "110061",
    "title": "Finns det någon ersättare till TRÅDFRI fjärrkontroll?",
    "keywords": [
      "smart belysning",
      "styrbar",
      "trådlös fjärrkontroll"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ge40b9b7-7021-4f9f-9213-e2f314c5e056",
    "id": "190903",
    "title": "Kan jag fortsätta att utöka mitt smarta hem med nya produkter från IKEA om jag har en TRÅDFRI gateway?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6e61196e-4ec5-45bf-965d-04ce7f241613",
    "id": "15065",
    "title": "Kan jag delbetala mitt köp? ",
    "keywords": [
      "avbetalning",
      "delbetalning",
      "kan jag beställa på avbetalning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f444g2bg-be81-41f7-b162-54e05cg70c2c",
    "id": "151151",
    "title": "Hur stort mellanrum behöver jag mellan stomme och vägg för att öppna lådorna i en PAX?",
    "keywords": [
      "avstånd",
      "dörr",
      "handtag",
      "pax",
      "pax dörr"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2171de2c-77c0-43e8-bb12-0c35c76c09fd",
    "id": "472253",
    "title": "Kan jag kombinera PAX med all garderobsinredning från IKEA?",
    "keywords": [
      "FAQ_Pax_ThirdCategory_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8d292ge3-50f1-49e6-8111-f5877894g8dg",
    "id": "21648",
    "title": "Vad är det för skillnad på ALGOT och BOAXEL?",
    "keywords": [
      "ALGOT",
      "Boaxel",
      "algot",
      "algot boaxel kompatibla",
      "skillnad algot och boaxel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5eb0g1g2-g67d-47eg-gg9c-770155e14dg3",
    "id": "27279",
    "title": "Kan jag få personlig inredningshjälp på IKEA? ",
    "keywords": [
      "Inreda",
      "företagsinredning",
      "heminredning",
      "heminredningshjälp",
      "heminredningsservice",
      "hjälp att inreda",
      "inredningskonsultation",
      "inredningsservice",
      "styla",
      "styling"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bg237b2g-3c25-481f-bd3g-ed47d88df11g",
    "id": "117876",
    "title": "Vad är ett ärendenummer?",
    "keywords": [
      "KSC",
      "Sac",
      "ärendenummer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fde7dg5b-e463-452f-8310-c5672b1930cg",
    "id": "32131",
    "title": "Vad ingår i de olika monteringspaketen för företag?",
    "keywords": [
      "business",
      "företag",
      "montering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "be38737g-cg4e-4069-8047-46d71gedf62c",
    "id": "464274",
    "title": "Hur gör jag en skräddarsydd walk in closet med IKEA?",
    "keywords": [
      "FAQ_Pax_FirstCategory_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1c9ggf36-6ff9-4d65-g619-d8bd8f8c1149",
    "id": "160609",
    "title": "Hur beställer jag en måttbeställd bänkskiva? ",
    "keywords": [
      "FAQ_Custom_Made_Worktop",
      "FAQ_Kitchen_PlanAndDesign_C_GC_Five",
      "beställa bänkskiva",
      "måttbeställning",
      "rita bänkskiva"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bgd1dd31-8903-49gf-g9fe-087e5f983d4b",
    "id": "395403",
    "title": "Vem kan ta emot en företagsleverans?",
    "keywords": [
      "FAQ_Business_SixthCategory_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "edfe2641-1c3e-491e-g110-29190c5f5290",
    "id": "54091",
    "title": "Kan jag köpa täcksidor till min garderob eller bokhylla?",
    "keywords": [
      "bestå täcksida",
      "billy täcksida",
      "pax täcksida",
      "täcksida till IKEA möbel",
      "täcksida till billy",
      "täcksida till garderob",
      "täcksida till pax",
      "täcksida vit",
      "täcksidor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "74691e41-d908-4647-8c1g-01280332f5ec",
    "id": "105997",
    "title": "Vilka kampanjer och rabatter har IKEA just nu?",
    "keywords": [
      "Aktuella erbjudanden",
      "FAQ_Family_SecondCategory_C_GC_One",
      "FAQ_Payment_FourthCategory_C_GC_One",
      "erbjudande",
      "kampanj",
      "rea"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "23b17316-e703-4422-8ff8-g6f7696e3294",
    "id": "41463",
    "title": "Kan IKEAs matbord och stolar som är testade för miljö inomhus användas utomhus?",
    "keywords": [
      "testade inomhus möbler",
      "utomhus möbler"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g4fbb073-b3g6-4334-9bbd-2g86297bdge0",
    "id": "122443",
    "title": "Vilka produkter från IKEAs övriga sortiment är godkända för barn?",
    "keywords": [
      "Barn",
      "Barnens IKEA",
      "Godkänd",
      "Godkända",
      "IKEAs",
      "Sortiment",
      "Säkerhet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1fg7gc99-5b75-4578-80e1-387gccbe3eb4",
    "id": "22130",
    "title": "Kan jag köpa en ny klädsel till min gamla EKTORP soffa?",
    "keywords": [
      "EKTORP",
      "Ektorp klädsel",
      "passar nya ektorp klädslar",
      "passar nya klädslar till ektorp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b8566gd1-3gb1-4c2c-g6g3-c6160e173g90",
    "id": "119770",
    "title": "Kan jag förankra PAX skjutdörrar direkt i golv och tak?",
    "keywords": [
      "PAX",
      "SKYTTA",
      "fästa i golv",
      "fästa i tak",
      "golv och takförankra",
      "skjutdörrar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0b1f997g-543g-410b-bf1b-8e86835c4981",
    "id": "395394",
    "title": "Varför kan jag inte handla med mitt företagskort?",
    "keywords": [
      "FAQ_Business_ThirdCategory_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "249db6bb-232b-4cc9-gb3b-0c6gbd4dd1b5",
    "id": "13643",
    "title": "Varför säljer IKEA regnbågskassar?",
    "keywords": [
      "Regnbågskasse",
      "STORSTOMMA"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "380ec08e-3b54-4f63-g1be-33f758f93e3g",
    "id": "120600",
    "title": "Säljer IKEA madrasser med memoryskum?",
    "keywords": [
      "memory foam",
      "memory skum",
      "memoryfoam"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6db622f2-7254-446b-9329-29f58729eb6b",
    "id": "116832",
    "title": "Vilka färger och färgtemperaturer kan jag växla mellan med TRÅDFRI LED-lampa?",
    "keywords": [
      "Smart belysning färg",
      "TRÅDFRI färg",
      "TRÅDFRI färger",
      "TRÅDFRI färgtemperatur"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "68e95d28-bc05-4527-9dc7-cg7ec4b64bgg",
    "id": "142594",
    "title": "Vad betyder felkoden som visas i displayen på min diskmaskin? ",
    "keywords": [
      "5E",
      "702.834.87",
      "911434342/01",
      "911434342/02",
      "911434342/03",
      "911434342/04",
      "911434342/05",
      "911434342/06",
      "E 01",
      "E 02",
      "E01",
      "E02",
      "E: 07",
      "E:01",
      "E:12",
      "E:14",
      "E:16",
      "E:18",
      "E:22",
      "E:24",
      "E:25",
      "E:27",
      "E:30",
      "Enastående",
      "VÄLGJORD",
      "aktivera",
      "alarmljud",
      "avlagringar",
      "avloppspump",
      "blinkande felkod",
      "d:00",
      "d:01",
      "d:0n",
      "d:oo",
      "diskad",
      "diskmaskin hängt sig",
      "diskmaskin kan inte startas",
      "diskmaskin larmar kod 50??",
      "diskmaskin piperpiper",
      "diskmaskin startas ej",
      "diskmaskin sönder",
      "diskmaskin trasig",
      "diskmaskinen börjar pipa",
      "diskmaskinen larmar",
      "diskmaskinen skramlar",
      "diskmaskinsfront",
      "diskmaskinstartar inte",
      "display funkar inte",
      "display hygienisk",
      "display ut funktion",
      "dwhb00",
      "e1",
      "e19",
      "e2",
      "e3",
      "enastående",
      "error i diskmaskinen",
      "f105",
      "felkod 11",
      "felkod 40 på diskmaskin",
      "felkod 40 välgjord",
      "felkod 50 på skinande",
      "felkod 5e",
      "felkod diskmaskin 11",
      "felkod i diskmaskiner",
      "felkod i11",
      "felkod vitvara",
      "felkod40",
      "fellarm",
      "filtersystem",
      "hjälpsam",
      "hygienisk",
      "iSE",
      "kallboda",
      "lagan",
      "larm diskmaskinen",
      "larmar pumpen går hela tiden",
      "läcker",
      "medelstor",
      "pumpar",
      "rengöra",
      "renlig",
      "renodlad",
      "slangfilter",
      "stänga av pipet",
      "torsboda",
      "villboda",
      "välgjord"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7e0f579b-8073-44ce-9cf1-c0g07edb0cbb",
    "id": "121274",
    "title": "Kan jag beställa ett tippskydd för att förankra min möbel i väggen?",
    "keywords": [
      "FAQ_Product_Safety",
      "fästa i väggen",
      "förankra möbeln",
      "säkerhet",
      "säkra möbeln",
      "väggförankra",
      "väggförankring"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b065e912-c89f-45ba-8738-39d723b7c5ec",
    "id": "1001512",
    "title": "Kan jag boka bortforsling som företagskund?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "be9c1f0d-30e4-446e-g87f-9540377b9fcg",
    "id": "470899",
    "title": "Hur vet jag som företagare om vi är fakturakund hos IKEA? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "f55d1f26-8b53-4g43-978b-0c9gb1d7055f",
    "id": "395367",
    "title": "Kan jag koppla ihop mitt Företagsfaktura konto med IKEA Business Network medlemskap?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "4fg0930c-f12e-4b09-8c60-385fd5687gd5",
    "id": "30861",
    "title": "Kan jag ha en resårbotten i en sängstomme? ",
    "keywords": [
      "FAQ_Box_Mattress_Bed_Frame",
      "botten",
      "resår",
      "resårbotten",
      "sängstomme"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "17886d47-de03-4eg2-8g2g-db4103e7f610",
    "id": "100208",
    "title": "Varför levereras era vitvaror inte med en färdig kontakt?",
    "keywords": [
      "1 fas",
      "1-fas",
      "2 fas",
      "2-fas",
      "3 fas",
      "3-fas",
      "Fast installation",
      "Perilex",
      "anslutningskabel",
      "en fas",
      "kontakt",
      "kundsvar",
      "trefas",
      "två fas",
      "vitvara"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b370f308-8b9b-43dd-9305-c61f06b7ee40",
    "id": "15038",
    "title": "Kan jag handla på faktura? ",
    "keywords": [
      "hur beställer jag en faktura",
      "hur gör jag för att handla mot faktura som företagskund",
      "jag vill handla på faktura",
      "kan jag beställa med faktura",
      "kan jag betala med faktura",
      "kan jag betala via faktura"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c6022239-4bgb-4d49-b4ge-8g517fb0b9c1",
    "id": "413487",
    "title": "Hur fungerar personliga förmåner med IKEA Family? ",
    "keywords": [
      "FAQ_Rewards_Explore_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7d2e23d1-f79g-44d3-b3e1-89f88c7eg00g",
    "id": "289638",
    "title": "Hur fungerar köksinstallation från IKEA?",
    "keywords": [
      "FAQ_Kitchen_Install_C_GC_One",
      "Köksinstallation"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0627ecef-52d0-4fcd-bfd1-97b337c7cg6c",
    "id": "36126",
    "title": "Var hittar jag tidsinställningen på TRÅDFRI rörelsesensor?",
    "keywords": [
      "Trådfri",
      "rörelsesensor",
      "tidsinställning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "35c9c458-1e05-4245-gg6c-5gg187205182",
    "id": "38327",
    "title": "Kan jag röststyra mina SYMFONISK högtalare?",
    "keywords": [
      "Röststyra",
      "Symfonisk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2bcc0655-59cd-4d4c-8409-8119b9ge644f",
    "id": "291058",
    "title": "Vad gör jag om jag vill göra ändringar i mitt kök efter installation?",
    "keywords": [
      "FAQ_Kitchen_AfterPurchaseAndGuarantee_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0d3154g2-05g9-4034-9db9-0244ge05b191",
    "id": "6782",
    "title": "Kan jag betala med ett tillgodokort på IKEA.se?",
    "keywords": [
      "ankarlänk",
      "tillgodokvitto"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3b6d5615-c41d-43fb-aa77-7acdf084184c",
    "id": "1001217",
    "title": "När börjar IKEA sälja sin Halloweenkollektion?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "4951c60f-3728-43e1-9c5d-fdb5e93295b8",
    "id": "1000744",
    "title": "Är IKEAs textilier GOTs certifierade?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "5c80e9bf-eb02-4d97-86g7-64fg807d4f8e",
    "id": "24943",
    "title": "Hålet för diskhon/hällen i min måttbeställda bänkskiva är inte helt utsågad, ska det vara så?",
    "keywords": [
      "bänkskiva",
      "måttbeställd bänkskiva",
      "perso",
      "utsågning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cf7f35c9-5c3e-4814-b9e6-d5d2616b6096",
    "id": "398279",
    "title": "Varför finns det vatten i min nya tvättmaskin?",
    "keywords": [
      "blöt",
      "blött",
      "rinner",
      "slangar",
      "vattenrester"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1dg0861b-9963-4115-8dce-bc08dg2050d2",
    "id": "40800",
    "title": "Kan jag kombinera KVARTAL gardinupphängningssystem med VIDGA?",
    "keywords": [
      "gardinskena",
      "glidkrok",
      "vidga serie"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6d3026d4-204d-4ee8-8c77-17d9b80c9ddb",
    "id": "1001258",
    "title": "Vilka material består HÖSTAGILLE kollektion av?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "70585bdb-cf88-4gg5-b064-32eb1g35f330",
    "id": "76002",
    "title": "Vad är EXHULT? ",
    "keywords": [
      "EXHULT",
      "KASKER",
      "SKARARP",
      "beredning",
      "ingrepp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c656d216-1913-467c-8g6c-c9834fed13db",
    "id": "310007",
    "title": "Kan jag köpa ett av visningsexemplaren?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "9d8c93da-8e28-42de-b119-23894c2ac67c",
    "id": "1001309",
    "title": "Kommer IKEA att sälja Halloweenkollektionen KUSTFYR?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "cg077ecd-4969-45de-81ce-b4093976285f",
    "id": "29161",
    "title": "Är IKEAs blandare Säker Vatten-certifierade?",
    "keywords": [
      "badrumsblandare",
      "blandare",
      "certifiering",
      "kranar",
      "köksblandare",
      "säker vatten",
      "säkert",
      "vatten"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ecc6689c-d7b9-46d4-844a-162f7844c915",
    "id": "1001198",
    "title": "Vad heter IKEAs Halloweenkollektion? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "de66gg5c-9bbd-41c1-bd68-73e6e4850e52",
    "id": "6805",
    "title": "Kan jag ladda min elbil på IKEA?",
    "keywords": [
      "e-bil",
      "el bil",
      "elbilar",
      "elektriskbil",
      "ladda bil",
      "ladda bilen",
      "laddstolpar",
      "laddstolpe"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c100f71b-3bg1-46dc-g82f-0gf3659e13bf",
    "id": "46502",
    "title": "Hur avbokar jag min tid för personlig planering? ",
    "keywords": [
      "avboka köksplanering",
      "avboka möte",
      "avboka personlig planering",
      "avboka planering",
      "avboka planeringsmöte",
      "avboka planeringstjänst",
      "badrumsplanering",
      "boka om",
      "boka om planering",
      "garderobsplanering",
      "köksplanering",
      "omboka",
      "sovrumsplanering",
      "vardagsrumsplanering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "002247f6-5591-4196-g00c-21b3044fb768",
    "id": "148117",
    "title": "Vilka regler gäller i SMÅLAND? ",
    "keywords": [
      "FAQ_Smaland",
      "barnpassning",
      "har IKEA barnpassning",
      "hur funkar barnpassningen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c59cce12-2ge4-4179-b129-f134g5f0f00d",
    "id": "190908",
    "title": "Kan jag behålla min TRÅDFRI-gateway eller måste jag byta till DIRIGERA-hubben?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "1900e824-3e2g-4f5f-g582-e48gc248ge2b",
    "id": "121335",
    "title": "Behöver jag ha en diskho i min köksö bredvid hällen?",
    "keywords": [
      "diskho",
      "häll",
      "installation",
      "köksö"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bfcdgfg4-3330-4437-b2gf-6cd8g35549c6",
    "id": "392510",
    "title": "Kan jag betala med kontanter på IKEA? ",
    "keywords": [
      "FAQ_Payment_FirstCategory_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c6d21cb9-73dc-44bg-b72b-07befg85d534",
    "id": "6777",
    "title": "Kan jag beställa en produkt som inte säljs i Sverige?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "921c92d7-67g3-4g8c-gg0e-05e3528c5c63",
    "id": "197071",
    "title": "Indikatorn på min fläkt blinkar (A) konstant, vad gör jag? ",
    "keywords": [
      "E023b",
      "E3",
      "alarm",
      "bemota",
      "bemöta",
      "bemöta fläkt blinkar",
      "blinkar",
      "droppar fett",
      "felkod",
      "filterlarm",
      "filtrering",
      "rengöringsprocess",
      "återställ blinkande lampa fläkt",
      "återställl fläkt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4ee7g4g8-9g7d-4f9d-8b3b-g60gb5922g80",
    "id": "192667",
    "title": "Kan jag se hur gammal min vitvara är?",
    "keywords": [
      "gammal",
      "garanti",
      "garanti vitvara",
      "serienummer",
      "tillverkad",
      "typkod",
      "vitvara",
      "vitvaror",
      "ålder på min maskin",
      "ålder på min vitvara",
      "årtal"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "45fc9d46-bg1b-488b-g9fd-80823602e5ce",
    "id": "37795",
    "title": "Hur förhindrar jag att mat bränner fast i min rostfria stekpanna?",
    "keywords": [
      "SENSUELL",
      "bränna fast",
      "bränna vid",
      "gjutjärn",
      "kolstol",
      "rostfri",
      "stekpanna"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "921fg73b-7258-4489-g750-69d55c333fg2",
    "id": "29136",
    "title": "Har jag garanti på begagnade IKEA produkter? ",
    "keywords": [
      "begagnade varor",
      "begagnat",
      "följer garantin produkten eller köparen",
      "garanti",
      "second hand"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "875e51gf-c5c0-4g81-b37e-8057574c87d1",
    "id": "37367",
    "title": "Är IKEAs blandare godkända att använda av försäkringsbolagen?",
    "keywords": [
      "blandare",
      "försäkring",
      "försäkringsbolag",
      "kran",
      "vattenkran"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "84376e4d-338b-442e-88b3-5796g12cc7ed",
    "id": "105674",
    "title": "Kan jag läsa gamla IKEA kataloger online?",
    "keywords": [
      "beställa",
      "ikea katalog",
      "ikea katalogen",
      "ikeakatalog",
      "ikeakatalogen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "434024d1-cc27-4db9-986e-e12e36b72e0b",
    "id": "1001083",
    "title": "Kan jag boka leverans på en röd dag?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c36egbe5-1g74-421g-891e-f71d758e8g71",
    "id": "8497",
    "title": "Kan jag få mätservice för måttbeställd bänkskiva?",
    "keywords": [
      "boka mätarservice",
      "boka mätservice"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "51839f35-2f11-4337-b1d2-g955c9580fce",
    "id": "179522",
    "title": "Var hittar jag information om en produkt?",
    "keywords": [
      "FAQ_General_Product_Information",
      "Jag har en fråga om en IKEA produkt",
      "Produktinfo",
      "fråga om produkt",
      "information om en produkt",
      "information om produkter",
      "produktfoto",
      "produktfråga",
      "produktfrågor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gg8dfc17-e680-48gc-gf0f-fgb8b0c232g6",
    "id": "126549",
    "title": "Kan jag reservera en produkt på ett IKEA varuhus?",
    "keywords": [
      "FAQ_Reserve_Item",
      "hålla en produkt",
      "lägga undan",
      "paxa",
      "reservation"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "53c8fg54-4b15-4bcc-8550-8e5458636433",
    "id": "400061",
    "title": "Säljer IKEA el? ",
    "keywords": [
      "FAQ_Sell_Electricity"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "50d8d784-5ec5-4b84-gd10-80ee48e4f18e",
    "id": "69805",
    "title": "Vad är Elavtal för IKEA? ",
    "keywords": [
      "elavtal"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2bb11533-eg4g-4gc8-9013-c4gf6fc3e641",
    "id": "190911",
    "title": "Vilka produkter fungerar med DIRIGERA hubb och IKEA Home smart appen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6861gbfb-537c-4b1b-81d5-7eb6gfecb8f0",
    "id": "42432",
    "title": "Vad är en diffusionsspärr?",
    "keywords": [
      "FIXA diffusionsspärr",
      "diffusion",
      "diffusionsspärr",
      "montering diffusionsspärr"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e2bd8c0e-28cf-4f43-8c1d-b0d1416e9d3g",
    "id": "122368",
    "title": "Vad innebär märkningen \"Utgår inom kort\"?",
    "keywords": [
      "FAQ_Last_Chance_Products",
      "last chance",
      "sortimentsförändringar",
      "utgående",
      "utgående produkt",
      "utgår",
      "utgår inom kort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "37e7fcef-6625-4269-b77f-5f2g36d61337",
    "id": "105611",
    "title": "Hur många jobbar på IKEA i Sverige?",
    "keywords": [
      "Corporate_Coworkers",
      "antal anställda"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6b804c0b-e480-4018-8718-fg1g199g93d2",
    "id": "297661",
    "title": "Vårt företag har en avtalskoppling till ett ramavtal eller en branschorganisation. Hur kopplar jag min ansökan mot ett specifikt avtal?",
    "keywords": [
      "Branschorganisation",
      "Faktura",
      "Företagsfaktura",
      "Företagskonto",
      "Kort",
      "Kredit",
      "Kundnummer",
      "Ramavtal"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "82c85879-c888-4462-b32d-542d82ed358b",
    "id": "200721",
    "title": "Behöver jag ha ett golvskydd under kyl och frys?",
    "keywords": [
      "balja",
      "golvunderlägg",
      "läckageskydd",
      "plastbalja",
      "uppsamlare",
      "vattenskydd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dbde86g1-1241-4c90-b419-8g51eb378324",
    "id": "21597",
    "title": "Finns det plats för en golvsockel bakom BILLY bokhylla?",
    "keywords": [
      "BILLY",
      "golvsockel",
      "sockel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6223dgc4-6bc0-4g18-825b-641f5c945b05",
    "id": "288759",
    "title": "Vilka är de bästa egenskaperna med ett ENHET kök?",
    "keywords": [
      "FAQ_Kitchen_ChoosingAKitchen_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e8d6e3d5-9eb2-40g4-8283-6159g9geg527",
    "id": "289735",
    "title": "Hur lång garanti har jag på mitt METOD kök?",
    "keywords": [
      "FAQ_Kitchen_AfterPurchaseAndGuarantee_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4319461f-8309-41df-g203-62c8f0g85b69",
    "id": "6648",
    "title": "Hur fungerar garantin på min IKEA produkt?",
    "keywords": [
      "garantiärende"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "53c2gf44-616c-4789-g38d-bb80g9d72c89",
    "id": "105678",
    "title": "Hur lång garanti har jag på min IKEA produkt?",
    "keywords": [
      "FAQ_Warranty",
      "garanti",
      "garanti badrum",
      "garanti garderob",
      "garanti kök",
      "garanti soffa",
      "garanti sovrum",
      "garanti vitvaror",
      "hur lång garanti har jag",
      "hur lång är garantin",
      "hur lång är garantin?",
      "min diskmaskin är trasig efter endast 1 år",
      "min produkt gick sönder",
      "produkt trasig",
      "vara sönder",
      "vara trasig",
      "vilken garanti har min produkt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0cg039gb-19eb-4834-gg07-2fb8c906bffg",
    "id": "132587",
    "title": "Hur monterar jag en IKEA front på min diskmaskin som jag inte köpt på IKEA?",
    "keywords": [
      "Diskmaskinsfront",
      "behjälplig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "53f6g1gf-31bg-48e0-be07-g41ed33b05b1",
    "id": "32398",
    "title": "Kan jag ändra det förinställda språket i IKEA Home Smart appen?",
    "keywords": [
      "IKEA Home Smart app",
      "Ändra språk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b8856693-3884-4218-9129-2g3c6b5801f2",
    "id": "463471",
    "title": "Varför har inte mina poäng registrerats än?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "cc461gg4-ge85-4gfg-gb7g-2f44g32b933g",
    "id": "349536",
    "title": "Varför måste jag i vissa fall göra en manuell avfrostning på mitt frysskåp med No Frost-funktion?",
    "keywords": [
      "automatisk avfrostning",
      "avfrostar inte",
      "avfrostar inte sig själv nedisad",
      "avfrostning",
      "avfrostning fungerar ej",
      "no frost"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3c892048-b158-4770-bdg8-bd08dd3g0b33",
    "id": "60153",
    "title": "Mina dörrar/skåpsluckor är sneda, hur får jag dem att bli raka?",
    "keywords": [
      "BESTÅ",
      "HJÄLPA",
      "KOMPLEMENT",
      "METOD",
      "PAX",
      "PLATSA",
      "UTRUSTA",
      "billy",
      "ej raka",
      "fronter",
      "för höga",
      "för låga",
      "för långt in",
      "för långt ut",
      "garderobsdörrar",
      "glapp",
      "glipa",
      "glipa mellan luckorna",
      "inte raka",
      "justera",
      "justera gångjärn",
      "köksluckor",
      "pax",
      "snea",
      "sneda",
      "sneda luckor",
      "snett"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ed91539f-6ed0-4907-9ed9-8d5ge298404e",
    "id": "389205",
    "title": "Vad gör jag om en produkt jag köpt blir återkallad?",
    "keywords": [
      "FAQ_Product_Recall"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b9559gfg-650e-4ccf-8f3e-g0f4c47gb9c4",
    "id": "200763",
    "title": "Hur gör jag för att spara förinställda höjder på gamingskrivbordet UPPSPEL?",
    "keywords": [
      "memorera höjder på skrivbord",
      "uppspel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "67989g6d-f5df-43ce-b9f4-bcb57473bc9f",
    "id": "211509",
    "title": "Vad innebär märkningen Unified Water Label (UWL) på IKEAs blandare?",
    "keywords": [
      "UWF",
      "certifiering blandare",
      "energiförbrukning blandare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "102563e2-0c46-42ef-93cb-fe1b91c4cf90",
    "id": "162056",
    "title": "Var kan jag hitta information om parkering på IKEA?",
    "keywords": [
      "FAQ_Parking_Information",
      "bil",
      "köra",
      "parkera",
      "parkering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bgg6bggf-2b80-44g4-g407-c0fg2fgb7eg9",
    "id": "297657",
    "title": "Hur handlar jag med Företagsfaktura?",
    "keywords": [
      "FAQ_Business_ThirdCategory_C_GC_Three",
      "Faktura",
      "Fullmakt",
      "Företagsfaktura",
      "Företagskonto",
      "Kort",
      "Kredit",
      "Kundnummer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5d7f04c6-232g-4b20-812e-e6266ee7922b",
    "id": "425337",
    "title": "Hur kan jag se hur många IKEA Family poäng jag har samlat ihop?",
    "keywords": [
      "FAQ_Rewards_Accumulate_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "52846623-9e89-4d1e-b2bf-g2b0111gc61b",
    "id": "37796",
    "title": "Hur tar jag bort fläckar från rostfria kokkärl?",
    "keywords": [
      "Fläckar gryta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g64185bd-c21e-4141-8be3-734143cdd3d1",
    "id": "25919",
    "title": "Varför blev min order annullerad?",
    "keywords": [
      "avbruten",
      "avbruten beställning",
      "avbruten leverans",
      "avbruten order",
      "blockerad"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5c9152gb-bec2-4625-96f2-52b29g1c4fe9",
    "id": "8564",
    "title": "Hur lång garanti har vitvaror från IKEA?",
    "keywords": [
      "Vitvarugaranti",
      "anrätta",
      "bejublad",
      "blixtsnabb",
      "diskmaskin",
      "frys",
      "frysskåp",
      "fördelaktig",
      "gashäll",
      "häll",
      "högklassig",
      "kylskåp",
      "köksfläkt",
      "micro",
      "microvågsugn",
      "mikro",
      "mikrovågsugn",
      "rengöra",
      "renodlad",
      "reparation",
      "reparatör",
      "servicepartner",
      "serviceverkstad",
      "smaklig",
      "spis",
      "vinterkall",
      "välgjord"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bb21cg31-21cc-4445-9c9g-g244e26g5623",
    "id": "21587",
    "title": "Kan jag ha gångjärnsdörr till min BILLY hörnhylla?",
    "keywords": [
      "BILLY",
      "BILLY dörr",
      "BILLY gångjärn",
      "BILLY hörnhylla",
      "dörr hörnhylla"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b9f7bc16-85b3-402c-9447-2110deedd2c4",
    "id": "289721",
    "title": "Hur avbokar eller ändrar jag min köksbeställning?",
    "keywords": [
      "FAQ_Kitchen_Install_C_GC_Five",
      "annulera bokning",
      "annulera order",
      "annullering av beställning",
      "avbeställa",
      "avbeställning",
      "avboka",
      "avbokning",
      "makulera order",
      "ångra order"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fd391751-dbdd-4ce7-9334-bc38f17664g5",
    "id": "315708",
    "title": "Kan jag få take away i restaurangen?",
    "keywords": [
      "bistro",
      "resturang",
      "take away"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "56cdb0f4-44fc-4c56-8f6g-262c3134b9g6",
    "id": "29485",
    "title": "Vad har HJÄLPA trådback för maxbelastning?",
    "keywords": [
      "hjälpa",
      "maxbelastning",
      "maxvikt",
      "platsa",
      "trådback"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0g6cc718-44cf-4062-8d0c-00046541b123",
    "id": "321556",
    "title": "Kan IKEA hjälpa mig med att demontera och forsla bort mitt befintliga kök? ",
    "keywords": [
      "FAQ_Kitchen_Install_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b31f7e78-79g0-4cc0-bfg3-5e7f6b34b25b",
    "id": "383348",
    "title": "Jag har två IKEA Family-konton, kan jag slå samman dem?",
    "keywords": [
      "FAQ_Family_FifthCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ce450df6-5g72-4d65-8048-6g1712b2d666",
    "id": "369471",
    "title": "Kan jag få ersättning från IKEA för ett borttappat eller stulet presentkort?",
    "keywords": [
      "FAQ_IKEA_Gift_Card_Lost"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bb8b1689-63b1-44ce-8553-74cd93d9cbbe",
    "id": "29490",
    "title": "Är PLATSA möbler godkända för användning i barnrum? ",
    "keywords": [
      "PLATSA",
      "SMÅSTAD",
      "barnrum"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b512g6f0-ffc5-4069-g17g-ed9821cb02f1",
    "id": "78986",
    "title": "Vilka kontaktuppgifter är det till Nerostein?",
    "keywords": [
      "Nerostein",
      "kontaktuppgifter",
      "mail"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b0g01438-f576-4801-b285-8039c84f7f07",
    "id": "324990",
    "title": "Jag har betalat för fler produkter än jag handlat, vad gör jag?",
    "keywords": [
      "FAQ_Payment_Error",
      "FAQ_Payment_FifthCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fb6e5128-e814-46e0-g75g-ee5d71186db9",
    "id": "245147",
    "title": "Gäller måtten på era gardiner för båda gardinerna eller bara för en?",
    "keywords": [
      "FAQ_Curtains"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1fe1cd38-c786-457g-9bf6-g71212481378",
    "id": "200938",
    "title": "Jag är intresserad av att samarbeta med IKEA på sociala medier, vem kan jag kontakta?",
    "keywords": [
      "FAQ_Commercial_Collaboration"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "31136310-15e8-4494-b3cb-b6d12d829984",
    "id": "187493",
    "title": "Hur skannar jag mina varor med mobilen i ett varuhus?",
    "keywords": [
      "FAQ_HowToShop_AppInStore",
      "Shop & Go",
      "Självskanning",
      "scanna varor",
      "scanning",
      "själv scanning",
      "själv skanning",
      "självscanning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "04865g92-cb94-4433-8g46-5ebbc596f06d",
    "id": "305935",
    "title": "Hur ändrar jag uppgifter på eller avslutar mitt IKEA Business Network-konto?",
    "keywords": [
      "FAQ_B2B_Change_Account_Details",
      "FAQ_Business_FifthCategory_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gg598c88-36e0-47e7-829f-5b5df20d2146",
    "id": "254278",
    "title": "Erbjuder IKEA presentinslagning?",
    "keywords": [
      "FAQ_Gift_Registry_ReceiptsAndWrappings_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "26gg5d5c-16gd-4f6f-b9dd-3733f4c354c2",
    "id": "254252",
    "title": "Kan jag skriva ut en IKEA Önskelista i era varuhus?",
    "keywords": [
      "FAQ_Gift_Registry_Buy_C_GC_Two",
      "Önskelista",
      "Önskelista IKEA"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cb550gbg-ggc5-49e3-g73d-3258ce237f26",
    "id": "40797",
    "title": "Kan jag köpa tyg på metervara?",
    "keywords": [
      "metervara",
      "metervaror",
      "tyg på rulle"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3g4bb9de-6ggg-40d6-898f-42b984250489",
    "id": "253953",
    "title": "Kan jag komma åt IKEA Önskelista i IKEA appen?",
    "keywords": [
      "FAQ_Gift_Registry_Create_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2cfdd9gd-89c6-435d-gf35-57d2e1cf9404",
    "id": "254258",
    "title": "Kan produkterna jag handlar från en IKEA Önskelista levereras direkt till personen som skapat önskelistan?",
    "keywords": [
      "FAQ_Gift_Registry_Buy_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "63f66635-e513-4b06-80c9-98b4116b9c9g",
    "id": "6509",
    "title": "Hur och när får jag tillbaka pengar vid retur av produkter som jag handlat med kreditkort?",
    "keywords": [
      "hur fungerar returer",
      "när får jag tillbaka mina pengar",
      "returer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3b8ed666-e870-4326-g600-c358b682064e",
    "id": "484956",
    "title": "Säljer ni fortfarande GODMORGON?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "9249e9c0-0717-4158-9046-1gfdccd50d22",
    "id": "37633",
    "title": "Jag glömde spara min kod från planeringsverktyget, kan jag ändå komma åt ritningen på något sätt?",
    "keywords": [
      "badrumsplanering",
      "bestå",
      "boaxel",
      "bror",
      "eket",
      "elvarli",
      "grönlid",
      "ivar",
      "jonaxel",
      "kallax",
      "kontorsplanering",
      "lidhult",
      "nordli",
      "pax planering",
      "planering",
      "planeringsverktyg",
      "platsa",
      "småstad",
      "söderhamn",
      "vallentuna",
      "vimle"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ff210c8c-6836-49b3-83c2-c089g21b118d",
    "id": "456939",
    "title": "Hur bränner jag in en gryta eller stekpanna av kolstål i ugn?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "dbc283b5-g3eg-493c-8662-ed162cdcbd36",
    "id": "145634",
    "title": "Jag har fått ett mejl från IKEA om en inbetalning. Kan jag lita på mejlet?",
    "keywords": [
      "FAQ_Phishing",
      "Nätfiske",
      "Phising",
      "Spammmejl",
      "spam"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1d74c00d-33d4-4bd4-97bd-674feb4d7555",
    "id": "91832",
    "title": "Kan jag kombinera det nya och det gamla takbeslaget för VIDGA gardinskenesystem?",
    "keywords": [
      "takbeslag",
      "takbeslag reservdel",
      "takfäste",
      "takfäste reservdelar",
      "vidga reservdelar",
      "vidga takbeslag",
      "vidga takfäste"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g8d11093-fbd5-49f5-9d68-0b35b58213b7",
    "id": "39422",
    "title": "Kan jag montera andra ben på min SÄBÖVIK säng än de som medföljer vid köp?",
    "keywords": [
      "Säbövik",
      "ben"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7becfe25-6451-4f81-g77e-062bg59edd21",
    "id": "38695",
    "title": "Varför har IKEAs påslakan inga hål?",
    "keywords": [
      "hål i påslakan",
      "påslakan"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "eb508dcf-e83g-45ec-94ef-473b3b37g474",
    "id": "105946",
    "title": "Hur blir jag IKEA Family medlem?",
    "keywords": [
      "FAQ_Family_FirstCategory_C_GC_One",
      "FAQ_IKEA_Family_Join",
      "aktivering av medlemsskap",
      "ikea familj",
      "medlemskort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "415gf9d2-5b8g-49g4-996g-b011e5be7564",
    "id": "416645",
    "title": "Kan jag överföra eller byta IKEA Family poäng?",
    "keywords": [
      "FAQ_Rewards_Accumulate_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8bd7dbbd-4d6e-4fbc-bce8-5b122133c0e2",
    "id": "412736",
    "title": "Om jag returnerar produkter, vad kommer hända med IKEA Family poängen jag har samlat ihop?",
    "keywords": [
      "FAQ_Rewards_AfterUse_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gd180egf-c825-44b0-923d-49c27fd77b5g",
    "id": "359826",
    "title": "Var hittar jag mitt ordernummer?",
    "keywords": [
      "FAQ_Find_OrderNumber"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "49bb4c1b-be31-42c1-8c33-cd77cd6d2eb5",
    "id": "293344",
    "title": "Jag har en vanlig IKEA profil. Kan jag bli IKEA Family medlem ändå?",
    "keywords": [
      "FAQ_Family_FirstCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "976e0157-fe66-430c-82c9-6d80d5fgbg50",
    "id": "37667",
    "title": "Kan jag köpa lösa paviljongtak på IKEA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "41122571-41f9-4ec9-b0f0-216f3df1e067",
    "id": "72678",
    "title": "Måste jag verifiera mig med Bank-ID när jag lägger en beställning och betalar på IKEA.se?",
    "keywords": [
      "IKEA.se",
      "bank-id",
      "betalsätt",
      "mobilt bank-id",
      "verifiera"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "52f2f286-7c33-41d6-8853-318f7419bf37",
    "id": "407624",
    "title": "Personen på vårt företag som skötte våra IKEA konton har slutat, hur får jag tillgång till våra konton? ",
    "keywords": [
      "FAQ_Business_FifthCategory_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2e8c8819-5142-4794-8c3d-1084g5050779",
    "id": "481031",
    "title": "Kan jag beställa ett nytt säkerhetsbälte till min LANGUR barnstol?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "092461e8-g3cd-4387-b59g-5d385762g1b3",
    "id": "33167",
    "title": "Kan jag installera ett ENHET högskåp bredvid ett tvättställ?",
    "keywords": [
      "badrum",
      "enhet",
      "högskåp",
      "tvällen",
      "tvättställ"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "91f85947-3dcc-4291-g7ec-79662d7c4bc5",
    "id": "370674",
    "title": "Vad är avståndet mellan låda och vägg på IKEAs badrumskommoder?",
    "keywords": [
      "GODMORGON",
      "HAVBÄCK",
      "TÄNNFORSEN",
      "badrum",
      "badrumskommod",
      "kommod",
      "ÄNGSJÖN"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ddb1220f-4bd8-49f1-b385-7d58c7eegb03",
    "id": "28252",
    "title": "Kan jag köpa färdigkapade passbitar?",
    "keywords": [
      "metod",
      "passbit",
      "passbitar",
      "täcka hål i kök",
      "täcka i köket",
      "täcksida",
      "täcksidor",
      "täckskiva"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c87e8f57-df6b-4869-8dg0-7e84e6be15c8",
    "id": "418402",
    "title": "Vad händer om jag returnerar en produkt som jag köpt med en eller flera personliga förmåner med IKEA Family?",
    "keywords": [
      "FAQ_Rewards_AfterUse_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f7gf2bd2-g1f7-4547-g4c7-f92115c8b39f",
    "id": "425350",
    "title": "När blir mina intjänade poäng synliga i min IKEA Family profil?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "f356d1c1-fe87-4bc8-9540-7bbg986gg970",
    "id": "427996",
    "title": "Vad innebär personliga förmåner med IKEA Family?",
    "keywords": [
      "FAQ_Rewards_Explore_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "11100333-65g6-4b16-g8gc-d5d2gd1cdd4f",
    "id": "422811",
    "title": "Hur väljer jag en förmån från personliga förmåner med IKEA Family?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "0774cb97-78f6-42e1-889d-g7d7648623e8",
    "id": "416638",
    "title": "Var kan jag samla poäng till mina personliga förmåner med IKEA Family?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "847371c6-b7cf-495d-g2e8-e0054ceb8d8c",
    "id": "425287",
    "title": "Hur låser jag upp min förmån på IKEA.se eller i IKEA appen?",
    "keywords": [
      "FAQ_Rewards_Redeem_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f6491d73-8cbg-4c8f-9b74-b036db34420g",
    "id": "37810",
    "title": "Varför blir det svarta märken efter besticken på tallrikarna?",
    "keywords": [
      "märken",
      "mörka streck",
      "svarta streck",
      "tallrik"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "211b2b87-f416-45ed-g5bf-5gd38g409d62",
    "id": "29651",
    "title": "Kan jag begära ut ett säkerhetsdatablad eller en testrapport?",
    "keywords": [
      "ikea",
      "kemikalier",
      "säkerhetsdatablad",
      "testrapport"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0eg3935b-10c1-4d3c-b01g-045g0618g141",
    "id": "6501",
    "title": "Hur sparar och öppnar jag min ritning i köksplaneraren?",
    "keywords": [
      "ankarlänk",
      "hur loggar jag in i planeringsverktyget",
      "kundsvar",
      "login",
      "planeringsverktyg",
      "planeringsverktyg kök"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "269f5007-0df4-4g6d-b400-24d3e89996e0",
    "id": "425306",
    "title": "Kan jag som IKEA Business Network kund använda mig av personliga förmåner med IKEA Family?   ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "bd634bg0-534c-4742-94c0-g7feb6ec1120",
    "id": "33305",
    "title": "Vilka diskhoar för kök kan användas tillsammans med ENHET?",
    "keywords": [
      "diskho",
      "enhet",
      "enhet diskho",
      "enhet handfat",
      "vilka diskhoar är kompatibla med enhet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "864d4301-04c4-4bbf-8504-g1c5de1d5g36",
    "id": "117903",
    "title": "Varför är mitt ordernummer för kort?",
    "keywords": [
      "fraktsedel",
      "försändelse ID",
      "ordernummer",
      "workordernummer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f0f27cd1-6e73-4g9c-8c6f-87d81829g7gb",
    "id": "37502",
    "title": "Kan ni hjälpa mig med installation av mitt badrum?",
    "keywords": [
      "badrumsblandare",
      "badrumsinstallation",
      "badrumskran",
      "installation av badrum",
      "installera",
      "kommod"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3b8ge2bf-ff36-4315-g9c5-6dbe0bfc2g38",
    "id": "425314",
    "title": "Hur använder jag mina personliga förmåner med IKEA Family i varuhuset?",
    "keywords": [
      "FAQ_Rewards_Redeem_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "412ffb13-f171-4fd0-bb03-043f3ef35b12",
    "id": "481906",
    "title": "Kan jag styra två DIRIGERA hubbar från samma app?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "1284gb7d-31g6-4b5d-g20f-f8fd1cded4gc",
    "id": "39459",
    "title": "Är det normalt att skummadrasser gulnar med tiden? ",
    "keywords": [
      "bäddmadrass",
      "gula",
      "gulnar",
      "madrass",
      "reklamation",
      "sittdynor",
      "sittkuddar",
      "skummadrass",
      "skummkärna"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d94022eb-6509-4226-g4eg-2ec74dc1c45b",
    "id": "298028",
    "title": "Var kan jag se användarvillkoren för Företagsfaktura?",
    "keywords": [
      "FAQ_Business_FourthCategory_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1237bf3d-0725-4eb9-g100-2d5605319466",
    "id": "106058",
    "title": "Kan jag begära momsåterbetalning på mina varor?",
    "keywords": [
      "FAQ_Payment_FourthCategory_C_GC_Four",
      "FAQ_VAT_Refund",
      "betala tillbaka moms",
      "få momsen tillbaka",
      "få tillbaka moms",
      "moms",
      "momsen",
      "momsen tillbaka",
      "återbetalning av moms"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "918g02b6-5d3g-4631-ge32-6e483981e6g5",
    "id": "476455",
    "title": "Varför har mina GLIMMA värmeljus olika färger?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "ge26331b-e365-4538-b4f8-d683f514f5d4",
    "id": "482073",
    "title": "Kommer IKEA sluta sälja SYMFONISK?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "93bd88e0-c164-4026-8789-18715501f6e6",
    "id": "190533",
    "title": "Frågar IKEA någonsin efter mina kontouppgifter?",
    "keywords": [
      "bedrägeri",
      "clearingnummer",
      "kontonummer",
      "kontouppgifter"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "37cc2dgg-0487-4444-b064-1d4c9bb960f0",
    "id": "8498",
    "title": "Kan jag få hjälp med montering även om jag själv börjat montera varan?",
    "keywords": [
      "montera",
      "montering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3181197d-697e-47g1-gb9g-9d43298c7463",
    "id": "122060",
    "title": "Varför får man inte med toppskiva och sockel till NORDLI modulbyrå?",
    "keywords": [
      "Sockelskiva NORDLI",
      "Toppskiva NORDLI"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2de0217e-01c3-46bb-b564-170fd90654c4",
    "id": "116275",
    "title": "Kan jag koppla ÖVERSIDAN ljuslist till min IKEA Home Smart app?",
    "keywords": [
      "BELYSNING",
      "TRÅDFRI",
      "ÖVERSIDAN"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g25g919c-d80b-4ggc-88e3-2c3c342fc971",
    "id": "29117",
    "title": "Kan jag beställa ett nytt säkerhetsbälte till min ANTILOP eller BLÅMES barnstol?",
    "keywords": [
      "antilop",
      "blåmes",
      "bälte",
      "reservdel",
      "säkerhetsbälte"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "932c672b-bd22-47bc-bb09-b8eg0138c1fg",
    "id": "118298",
    "title": "I vilka höjder kan jag montera sängbottnen för MYLLRA spjälsäng?",
    "keywords": [
      "MYLLRA",
      "spjälsäng"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0e5861f4-70c4-45c0-bf42-652g940415ff",
    "id": "426918",
    "title": "Hur många smarta produkter kan jag koppla till DIRIGERA-hubben samtidigt?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "637b34f4-c532-49bb-b4d4-379c7bd6b9b8",
    "id": "392505",
    "title": "Vilka betalningsalternativ kan jag välja i IKEA appen?",
    "keywords": [
      "FAQ_Payment_FirstCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7dcdb1d8-3936-489c-8bd6-5b19f0ee410f",
    "id": "105965",
    "title": "Kan jag få en kopia på min faktura eller få den utskickad på nytt?",
    "keywords": [
      "FAQ_Business_FourthCategory_C_GC_Three",
      "FAQ_Payment_SixthCategory_C_GC_Three",
      "andra kopia av faktura",
      "behöver en ny faktura",
      "fakturakopia",
      "få en ny faktura",
      "kan ikea skicka min faktura igen",
      "kan ni skicka min faktura igen",
      "kopia av faktura",
      "tappat bort faktura",
      "ändra faktura",
      "ändra fakturainformation",
      "ändra information på faktura"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7dd7298d-633b-49bc-8eg7-4280d6446922",
    "id": "8560",
    "title": "Jag saknar skötselråden för min produkt, vad gör jag?",
    "keywords": [
      "ankarlänk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "57273220-gce6-40g2-bg8b-ge413883d582",
    "id": "114085",
    "title": "Varför kan jag inte ladda ner appen IKEA Home smart?",
    "keywords": [
      "Home smart",
      "Home smart-app",
      "app",
      "ladda ner app"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9eg1f434-cggf-4c37-g43c-513fd9d22c42",
    "id": "425355",
    "title": "Kan mina IKEA Family poäng och förmåner förfalla?",
    "keywords": [
      "FAQ_Rewards_Accumulate_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cccd13g0-1ef8-42cg-9dcg-e2488d4b3gc5",
    "id": "32322",
    "title": "Fungerar TRÅDFRI ljuskällor med Google Homes rutiner?",
    "keywords": [
      "GOOGLE HOME",
      "TRÅDFRI",
      "glödlampor",
      "lampor",
      "ljuskälla",
      "rutiner"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "21817848-737f-4gdb-gbg3-98ec56ef4g6e",
    "id": "422818",
    "title": "Varför knakar eller gnisslar min säng?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "g17051cf-63c7-451d-be9g-f846b744b1g8",
    "id": "8551",
    "title": "Hur snabbt kan vi få varorna levererade till vårt företag?",
    "keywords": [
      "FAQ_Business_SixthCategory_C_GC_Two",
      "leveranstid företag"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "42212bc8-ccfd-4751-9b85-5d6ee4f38dgc",
    "id": "407478",
    "title": "Hur kan jag se vem som handlade på vårt företagskort? ",
    "keywords": [
      "FAQ_Business_FourthCategory_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "406bcb26-853g-4b78-b5b2-3gb821ec5d74",
    "id": "382802",
    "title": "Hur anger jag en rabattkod eller kupong i kassan?",
    "keywords": [
      "FAQ_Family_SecondCategory_C_GC_Two",
      "FAQ_Payment_ThirdCategory_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6ffd4b6g-b658-4b74-be38-f5cf84413e6f",
    "id": "399678",
    "title": "Varför ska vi bli medlemmar i IKEA Business Network?",
    "keywords": [
      "FAQ_Business_FirstCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "43d72279-3dc1-4c23-b318-e701b0g2e1c7",
    "id": "107115",
    "title": "Hur hög paraffinhalt är det i era värmeljus?",
    "keywords": [
      "kundsvar",
      "parrafin",
      "värmeljus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "610gb47f-fec3-4691-bdbf-1e2e96d00f1c",
    "id": "120346",
    "title": "Varför är min blandare trög att vrida?",
    "keywords": [
      "Blandare",
      "Blandarhus",
      "Blandarhuset",
      "Diskmaskinsavstängning",
      "Diskmaskinsavstängningen",
      "Installation",
      "Inställning",
      "Reklamation",
      "Reklamera",
      "Seg",
      "Spola",
      "Spolar",
      "Trög",
      "VVS",
      "VVS:are",
      "Vattenflöde",
      "Vattenflödet",
      "Vred",
      "Vredet",
      "Vrida",
      "Vrider"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fb598606-b585-4dcg-gbe7-0gf76dcbgf75",
    "id": "25910",
    "title": "Hur ändrar jag min fakturaadress?",
    "keywords": [
      "ändra adress",
      "ändra faktura"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c4760795-53d0-4bg4-9279-f1b337c3bf64",
    "id": "42547",
    "title": "När behöver jag tillsätta diskmaskinssalt?",
    "keywords": [
      "Stjärna",
      "diskmaskin",
      "diskmaskinssalt",
      "salt",
      "varning saltnivå"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e2c80030-8229-4507-8c51-573db76g3318",
    "id": "13477",
    "title": "Vilka kollektioner är aktuella hos IKEA just nu? ",
    "keywords": [
      "kollektion"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d832875e-4018-4316-9749-1deg504f4f50",
    "id": "8571",
    "title": "Hur rengör jag fläktfiltret i min fläkt?",
    "keywords": [
      "fettfilter",
      "fettfiltret",
      "filtret",
      "fläktfilter",
      "metallfilter",
      "rengöring kökfsfläkt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "84653b97-7bf4-4239-859g-5e38e1222b00",
    "id": "90669",
    "title": "Vart plockar jag varan på varuhuset? ",
    "keywords": [
      "lagerplats",
      "tag själv lager",
      "tag själv lagret"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6g7eg824-f2e2-49cd-8541-60bf3200353e",
    "id": "99218",
    "title": "Jag har plockat fel på tag-själv-lagret, vad gör jag? ",
    "keywords": [
      "fattas kolli",
      "fattas paket",
      "fel paket",
      "fel vara",
      "saknas kolli",
      "saknas paket"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "18d1733d-b58b-4e55-g9f4-521bdd9d5948",
    "id": "58237",
    "title": "Kan jag få kostnadsfri planeringshjälp på IKEA?",
    "keywords": [
      "arbetsrumsplanering",
      "badrumsplanering",
      "garderobsplanering",
      "personlig planering",
      "soffplanering",
      "sängplanering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8e719f11-e8f6-44dg-87f2-41f0g1252125",
    "id": "5152",
    "title": "Hur blir jag IKEA Family medlem om jag har skyddad identitet?",
    "keywords": [
      "FAQ_Family_FirstCategory_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d84426c4-92eb-4bcc-g260-c13eeed3e007",
    "id": "33134",
    "title": "Kan jag köpa täcksidor till ENHET?",
    "keywords": [
      "enhet",
      "monter enhet",
      "montering ENHET",
      "täcksida",
      "täcksidor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1db85568-8015-40gb-8999-c12ggdd9f64b",
    "id": "478467",
    "title": "Varför rostar mina utemöbler?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "0e12f738-bb65-4c5g-8834-9fedd2269fb7",
    "id": "478795",
    "title": "Säljer ni fortfarande SPORUP matta med kort lugg?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "f9428137-9c1c-4372-gf25-53534466g4g3",
    "id": "105940",
    "title": "Vad får jag för förmåner som IKEA Family medlem?",
    "keywords": [
      "FAQ_Family_ThirdCategory_C_GC_Two",
      "FAQ_IKEA_Family_Events",
      "FAQ_Payment_FourthCategory_C_GC_Two",
      "ikea familj",
      "medlemskort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "48c602b8-1gdd-479b-9578-09f9d3e2132e",
    "id": "37745",
    "title": "Hur lång hållbarhet har SKYDD träolja?",
    "keywords": [
      "mineralolja",
      "skydd",
      "träolja"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9916e662-27gd-40gb-9g26-2db9045eff6d",
    "id": "467961",
    "title": "Vilka dörrar finns till PAX garderobssystem?",
    "keywords": [
      "FAQ_Pax_SecondCategory_C_GC_Five",
      "garderob",
      "gångjärnsdörrar",
      "pax",
      "pax dörrar",
      "skjutdörrar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "39717971-e928-40c8-gf64-197360f593ed",
    "id": "141683",
    "title": "Vad betyder felmeddelandet eller alarmet på min kyl och frys?",
    "keywords": [
      "001.668.49",
      "00166849",
      "202.227.74",
      "302.218.68",
      "502.227.77",
      "702.218.71",
      "801.668.50",
      "BITANDE",
      "FRAMTID",
      "KYLD",
      "KYLIG",
      "NUTID",
      "SUPERBT",
      "alingsås",
      "dynamisk",
      "effektfull",
      "fel kod",
      "felkod",
      "felkod kyl",
      "felkod vitvara",
      "frostfri",
      "frostig",
      "frostkall",
      "frysa",
      "frysen låter",
      "fryser",
      "grönsakerna",
      "kylen låter",
      "kylskåp",
      "larm",
      "medgång",
      "minus",
      "piper",
      "svalkas",
      "svalna",
      "tynnerås"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e99ccc42-36d0-4688-89f1-98962ee8c07c",
    "id": "119392",
    "title": "Kan jag handla med studentrabatt på IKEA?",
    "keywords": [
      "erbjuder vi studentrabatt",
      "mecenat",
      "rabatt",
      "student",
      "studentkortet",
      "studentrabatt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ggc7dce5-fcff-4eg5-g506-823121b84f78",
    "id": "104219",
    "title": "Behöver jag ha en täcksida i slutet av en diskmaskin?",
    "keywords": [
      "diskmaskin",
      "montering täcksida avslut",
      "täcksida",
      "täcksida diskmaskin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "98e6134f-0c5g-46cb-96cd-026259f943db",
    "id": "38906",
    "title": "Kan jag använda en matta med latexbaksida på golv med golvvärme?",
    "keywords": [
      "anti glid",
      "golvvärme",
      "latex",
      "matta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ggge39c7-709d-4fee-80bf-0c476f4947f3",
    "id": "422820",
    "title": "Varför knakar eller gnisslar min soffa?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "7655b18d-36c2-4953-gg21-11b4fc40g8ee",
    "id": "471648",
    "title": "Säljs TRUMFISK i Sverige?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "0edc2807-c96d-4fe4-921g-e8391831gb32",
    "id": "39452",
    "title": "Vilka sängben kan jag ha till min IKEA säng?",
    "keywords": [
      "ben",
      "säng",
      "sängben"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "efb68bf3-1gbb-47e0-9531-67750d1c71be",
    "id": "365336",
    "title": "Säljer ni fortfarande produkter från serien BJURSTA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "fbb31e83-7eb5-43c1-986g-2c2dg2681035",
    "id": "54103",
    "title": "Varför hamnar min kökslåda för högt upp eller ner?",
    "keywords": [
      "METOD",
      "lådfront",
      "lådfront högt upp eller ner",
      "maximera"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "897g1fg4-45d3-4b55-9g53-6g42265d9be2",
    "id": "470252",
    "title": "Kan jag se IKEAs liveshoppingstillfällen i efterhand?",
    "keywords": [
      "live shopping",
      "liveshopping"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "67gb39eg-92dd-4040-g31f-95482683f58c",
    "id": "471660",
    "title": "Säljs DVÄRGGRÄS i Sverige?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "71fdb7g7-29bg-4f03-g560-1g940b8fg61f",
    "id": "39182",
    "title": "Vilket system passar KOMPLEMENT klädstång till? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "geeg1324-93d4-491f-9969-54d035247d42",
    "id": "467520",
    "title": "Hur handlar jag som företagskund på IKEA.se?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "38fg533f-cgd0-4353-bb0e-78ffe08d0817",
    "id": "38720",
    "title": "Kan jag använda LUDDE fårskinn i barnvagnen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "04g9e469-0970-4df4-85b3-2bc2e23b4ef4",
    "id": "475635",
    "title": "Kan jag använda ULLERSLEV fårskinn i barnvagnen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "9cfb8ggc-88d6-47ee-99cf-5586eg776109",
    "id": "57924",
    "title": "Kan jag byta min vara till en annan?",
    "keywords": [
      "Lämna tillbaka",
      "byta",
      "lämna tbx",
      "ångra mig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g4248445-b7g3-4e8g-99g6-09fe1411f75b",
    "id": "105612",
    "title": "Hur kan IKEA hålla hög kvalitet och samtidigt ha låga priser?",
    "keywords": [
      "Corporate_Design"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1c7621d7-0bd7-4fff-b632-5c1009ff3eg3",
    "id": "132603",
    "title": "Vilka uppdateringar gjordes i BILLY serien 2014?",
    "keywords": [
      "BILLY",
      "Bokhylla",
      "Förvaring",
      "Sortimentsförändring"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "44g40b19-d092-4552-82dd-b6de47b61220",
    "id": "43750",
    "title": " Varför fortsätter ugnsfläkten att gå efter att ugnen är avstängd?",
    "keywords": [
      "brummar",
      "ugnsfläkt",
      "varmluftsfläkt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "508cfc22-116d-46c3-9dcc-82g76f7c3423",
    "id": "104224",
    "title": "Varför är täcksidan bredare än stommen?",
    "keywords": [
      "Täcksida",
      "Täcksida bredare en stommen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9bb0cd37-232d-40b2-8073-162db2d6d2gf",
    "id": "96925",
    "title": "Jag har fått en spricka i min häll, täcks detta av garantin? ",
    "keywords": [
      "skadad häll",
      "spricka i häll",
      "sprucken",
      "trasig häll"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7469cf4f-b44b-44c4-8bf2-bg78g66b1c1b",
    "id": "121151",
    "title": "Varför är det olika nyanser i träet på min produkt?",
    "keywords": [
      "färgskillnad",
      "olika nyanser",
      "träslag"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "76gg97e6-b849-4c0g-bgd2-d64g46506810",
    "id": "474529",
    "title": "Kan jag montera en PAX garderob ensam? ",
    "keywords": [
      "FAQ_Pax_FifthCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7548275f-95b5-44g9-bf04-1f7dc8c5b8f0",
    "id": "26699",
    "title": "Vad är måttet från vägg till METOD sockel eller ben?",
    "keywords": [
      "ben",
      "metod",
      "mått",
      "sockel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "39c44d08-30b9-4g5g-gf81-e90eeg40c3d7",
    "id": "472207",
    "title": "Varför går mina PAX dörrar i varandra?",
    "keywords": [
      "FAQ_Pax_SecondCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "653e7f2g-3d4c-4b5f-8159-gbe7465b4702",
    "id": "246677",
    "title": "Kan jag använda ett annat vattenlås än IKEAs till min diskho eller tvättställ från IKEA?",
    "keywords": [
      "använda eget vattenlås"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "66c837c9-e49d-49c0-g329-67g4e4ege706",
    "id": "5129",
    "title": "När förfaller min faktura från Klarna för mitt köp på IKEA? ",
    "keywords": [
      "förfallodatum",
      "klarna",
      "klarna faktura",
      "pausa faktura"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "51b630e5-5d79-45e3-83gf-70fd4f26fb86",
    "id": "474613",
    "title": "Hur får jag tag på min företagsfaktura?  ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "08g40435-5cg9-4103-befd-gb71g6cgd485",
    "id": "105936",
    "title": "Hur gör jag för att få IKEA Family erbjudanden via mejl?",
    "keywords": [
      "FAQ_Family_SecondCategory_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3gd1159e-ee54-47f6-849d-g213d453dcf9",
    "id": "474214",
    "title": "Var sätter jag de små dämparna som medföljer UTRUSTA gångjärn?",
    "keywords": [
      "Utrusta",
      "dämpare",
      "gummipluppar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "222365g1-g2fg-4d57-bc4f-4cb588fgg0d6",
    "id": "29828",
    "title": "Kan jag ändra leveranssätt på min order?",
    "keywords": [
      "byta leveransalternativ",
      "byta leveranssätt",
      "ändra leveransalternativ"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8382384d-d75c-4275-9f1b-5gcd632e35g2",
    "id": "8485",
    "title": "Min ugn ger ifrån sig ett brummande ljud, är det normalt?",
    "keywords": [
      "brummande ljud i ugn",
      "brummar",
      "missljud från ugnen",
      "oljud från ugnen",
      "spisen brummar",
      "ugnen brummar",
      "ugnen låter",
      "ugnen väsnas",
      "varmluftsfläkt",
      "viner från fläkten"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8dfeedcb-8b8d-4326-82cc-1b1bd12505b6",
    "id": "120023",
    "title": "Vad betyder det när det står \"Beställ via Självservice\" under lagersaldot på produktsidan?",
    "keywords": [
      "Självservicestation"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gg8020be-287e-4b37-b1g2-091d73b76fd9",
    "id": "315801",
    "title": "Kan jag synkronisera KNYCKLAN fjärrkontroll till flera enheter?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "93637910-4f26-4c5e-82f0-69gg6fb39b69",
    "id": "454469",
    "title": "Varför har mina KOMPLEMENT skenor olika färg på plasten?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c8c54gfc-d0fd-4b4f-800c-55d1eeeg6e4b",
    "id": "249462",
    "title": "Kan man montera GRILLSKÄR dörr/sidor/rygg på GRILLSKÄR kolgrill?",
    "keywords": [
      "grill",
      "montering",
      "monteringsanvisning",
      "säsong",
      "utemöbler",
      "utomhus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "68g85825-590g-43g6-bd59-275e641e8d24",
    "id": "37712",
    "title": "Kan jag justera armstöden på HATTEFJÄLL kontorsstol?",
    "keywords": [
      "HATTEFJÄLL",
      "armstöd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f9bbg1b9-8b52-483f-g5d7-8576e8ccde2b",
    "id": "119877",
    "title": "Behöver jag köpa något extra för att kunna använda LEDBERG LED ljuslist?",
    "keywords": [
      "Ledberg",
      "driver",
      "ljuslist",
      "transformator"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "380cd6b3-g210-4f8f-8109-87g49e7434f9",
    "id": "178600",
    "title": "Passar KOMPLEMENT skenorna i IKEAs nuvarande sortiment med mina gamla KOMPLEMENT trådbackar?",
    "keywords": [
      "KOMPLIMENT",
      "PAX",
      "kompl",
      "skenor",
      "skenor komplement",
      "skenor pax"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d1ccc2dc-39g1-4c5b-964f-3g1c2847f23g",
    "id": "41071",
    "title": "Vad är den bästa brukstemperaturen för kyl- och frysskåp?",
    "keywords": [
      "brukstemperatur",
      "temperatur",
      "temperatur frysskåp",
      "temperatur kylskåp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0f932834-797f-4956-82fe-2fg9g7615g9g",
    "id": "118556",
    "title": "Kan jag installera min diskmaskin själv?",
    "keywords": [
      "diskmaskin",
      "installera",
      "installera diskmaskin",
      "vitvaror",
      "vvs"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "46g11ddb-f295-4dd0-8490-c5266305770b",
    "id": "470925",
    "title": "Jag har frågor om min företagsfaktura, vart vänder jag mig? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c2ge3d2e-0eg8-45fe-be0f-3g8eg5887e72",
    "id": "94652",
    "title": "Kan jag placera PLATSA stommar i olika bredd ovanpå varandra?",
    "keywords": [
      "PLATSA"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cc7877e6-d839-4468-b355-f25094573g0c",
    "id": "141687",
    "title": "Min kyl och frys ger ifrån sig ett ovanligt/konstigt ljud, vad beror det på? ",
    "keywords": [
      "frysskåp",
      "kylskåp",
      "min frys låter",
      "min kyl låter",
      "piper"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6889eged-ec17-43g6-bb3f-4gf73deb740g",
    "id": "474535",
    "title": "Kan jag ändra min PAX garderob efter montering?",
    "keywords": [
      "FAQ_Pax_FifthCategory_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cce79fb1-3066-4838-gb81-1e48g17g214f",
    "id": "6894",
    "title": "Kontaktar Hemfixarna mig innan monteringen?",
    "keywords": [
      "FAQ_Pax_FifthCategory_C_GC_Two",
      "FAQ_Service_Time_Slot"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c365g58d-bg06-4d94-93c8-02e1f7c87bg1",
    "id": "363703",
    "title": "Jag som företagskund har fått en kreditfaktura, hur löser jag in den?",
    "keywords": [
      "hur får jag den utbetald",
      "kreditfaktura",
      "utbetalning",
      "återbetalning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "21818c6d-56cg-41f2-8df4-gege7c2f9b81",
    "id": "474474",
    "title": "Vilken takhöjd behöver jag för att kunna montera en PAX garderob?",
    "keywords": [
      "FAQ_Pax_FourthCategory_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9c3d65e9-18fb-4b80-gc89-2b02551795ge",
    "id": "337740",
    "title": "Kan någon annan hämta min beställning från en Pick-Up Box?",
    "keywords": [
      "Pick up box",
      "hämta på varuhus",
      "pickup box",
      "pin kod",
      "pinkod"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "591c6e97-90eg-4deg-9329-755bd4999610",
    "id": "472756",
    "title": "Vad är självservice? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "97d8864d-e68e-4820-87c2-504b392e1gde",
    "id": "418290",
    "title": "Säljer IKEA värmepumpar?",
    "keywords": [
      "FAQ_Heat_Pumps"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "57c7994f-8be3-4f59-9970-b388c83c69gg",
    "id": "118887",
    "title": "Varför får min stekpanna repor och flagor?",
    "keywords": [
      "non-stick beläggning",
      "repor",
      "stekpanna",
      "teflon"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "74e995e7-d8dd-4e6g-8085-c88c05b3d992",
    "id": "35471",
    "title": "Vad är skillnaden mellan nya och gamla HEMNES dagbädd?",
    "keywords": [
      "hemnes",
      "hemnes dagbädd",
      "ändring HEMNES"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f01c37b6-9f3d-412d-g72f-04g500d34ed3",
    "id": "6783",
    "title": "Kan jag beställa Click & collect om jag har ett utländskt telefon- eller postnummer?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c64cc4e0-9278-442g-g2f9-143b3bf4e692",
    "id": "466294",
    "title": "Vad är maxbelastningen och utdragsdjupet för KOMPLEMENT trådbackar?",
    "keywords": [
      "komplement",
      "komplement maxbelastning",
      "maxvikt",
      "meshback",
      "pax lådor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "481c38c8-b3e1-4cbg-be8c-1gdf6db409g7",
    "id": "472375",
    "title": "Varför har mina dynor ändrat färg?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "12f64044-c7d6-4535-g1cb-74824bd7433e",
    "id": "179575",
    "title": "Kan jag köpa extra hyllplan till mitt IVAR skåp?",
    "keywords": [
      "IVAR",
      "IVAR hyllplan",
      "IVAR skåp",
      "extra hyllplan"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "93b493b3-4827-413e-g01f-553db2800014",
    "id": "472483",
    "title": "Vilka storlekar finns det på PAX garderob?",
    "keywords": [
      "FAQ_Pax_FourthCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3c52769f-eedd-434f-g9g9-354479056cc2",
    "id": "472381",
    "title": "Hur designar jag min PAX garderob?",
    "keywords": [
      "FAQ_Pax_FourthCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "046gcg27-1dfb-4291-99dc-229gd57c142g",
    "id": "141797",
    "title": "Vad betyder felkoden som visas i displayen på min mikro?",
    "keywords": [
      "alarm",
      "bara piper och går ej att starta",
      "e3",
      "e4",
      "er03",
      "er04",
      "er3",
      "er4",
      "ero3",
      "ero4",
      "err1",
      "err2",
      "err3",
      "error3",
      "felkod vitvara",
      "fie1",
      "fie4",
      "larmar",
      "ljud finsmakare",
      "ljud mikro",
      "ljudsignal"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c8e73f89-db55-42b5-95f0-ec90b1g0152f",
    "id": "472317",
    "title": "Säljs KOMPLEMENT skenor och trådbackar separat?",
    "keywords": [
      "FAQ_Pax_ThirdCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "20781bd3-8328-4345-9c0b-7e44b87g1e83",
    "id": "124768",
    "title": "Varför är det en glipa mellan dörrarna i PAX hörnlösning?",
    "keywords": [
      "Dörrarna",
      "FAQ_Pax_SecondCategory_C_GC_Four",
      "Garderobsstomme",
      "Garderobsstommen",
      "Glipa",
      "Glipan",
      "Hörnlösning",
      "Hörnlösningen",
      "Mellan",
      "Mellanrum",
      "Minimera",
      "Minimerar",
      "PAX",
      "Påbyggnadsdelen",
      "Stötdämparna",
      "Varför"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "72c33d47-18b6-43c2-801e-955d1377e068",
    "id": "472200",
    "title": "Vad behöver jag tänka på när jag monterar dörrar till PAX?",
    "keywords": [
      "FAQ_Pax_SecondCategory_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f40f30e9-3bg5-4c87-g754-5504d02c2991",
    "id": "59517",
    "title": "Jag missade att betala min order, vad händer nu?",
    "keywords": [
      "Glömde betala",
      "betalning",
      "hann inte",
      "pengar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c1g3eb77-eb0b-472b-b0b5-652d53b517g5",
    "id": "60471",
    "title": "Vad gör jag om jag inte får in alla mina varor i bilen? ",
    "keywords": [
      "får inte plats",
      "kan inte frakta hem varorna själv",
      "kan inte köra hem själv",
      "kan inte leverera själv",
      "kan inte transportera själv",
      "min bil är för liten",
      "möblerna får inte plats i bilen",
      "produkter får inte plats i bilen",
      "vad gör jag om jag inte får plats",
      "vad gör jag om min bil är för liten",
      "varorna får inte plats i bilen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dbg76518-f1b9-42gc-819f-b1cb094b426c",
    "id": "469042",
    "title": "LED-ljuskällorna som är i kittet passar inte i socklarna på de lampor jag har hemma. Finns det andra kit/ljuskällor?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "23c91ged-5f7d-4ef9-8d43-2e6264186e1d",
    "id": "469044",
    "title": "Vad gör jag om mina ljuskällor inte svarar på mina styrenheter? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "402863g7-1g62-47b9-88e0-3cf9dffe61f1",
    "id": "114052",
    "title": "Jag kan inte ansluta min app/telefon till min TRÅDFRI gateway, vad gör jag för fel?",
    "keywords": [
      "ansluta gateway/app",
      "home smart support"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8c8d4d9c-d179-4g9d-96e5-88b8gc4bee83",
    "id": "114137",
    "title": "Kostar IKEA Home smart-appen något?",
    "keywords": [
      "App",
      "Home smart",
      "är ikea home smart appen gratis"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c2377dff-3812-45bf-be13-4gg21f7ff2de",
    "id": "191475",
    "title": "På vilka sätt kan jag styra mitt smarta hem?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "g43cd9g7-b6d6-4760-95eg-c77g47fff6eb",
    "id": "190896",
    "title": "Kan jag ladda ner IKEA Home smart-appen till mer än en mobil enhet i mitt hem så att flera användare kan använda den?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "1448g067-d3e3-4b06-8828-313g0d1e335b",
    "id": "111795",
    "title": "Vad är skillnaden mellan SYMFONISK högtalarlampa generation 1 och SYMFONISK högtalarlampa generation 2?",
    "keywords": [
      "Symfonisk",
      "lampa",
      "skillnader"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "51c61bfb-002b-4c68-9g17-685df8078585",
    "id": "127545",
    "title": "Till vilka produkter kan jag använda BRAUNIT batteripaket?",
    "keywords": [
      "batteri",
      "braunit",
      "fyrtur",
      "kadrilj",
      "praktlysing",
      "tredansen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "005cc8g2-6496-4997-9e46-e7bb11e2dg2b",
    "id": "200643",
    "title": "Säljer IKEA barngrindar?",
    "keywords": [
      "PATRULL",
      "barngrind",
      "barngrindar",
      "patrull",
      "säkerhetsgrind",
      "trappgrind"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g608c869-4646-40bf-gcb7-c060c42c10c0",
    "id": "389679",
    "title": "När är det lättast att komma i kontakt med IKEA Kundservice?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "2cc6c29b-88b8-44bc-g65e-1f7045e5f3f0",
    "id": "124762",
    "title": "Varför krymper mina gardiner?",
    "keywords": [
      "gardin krymper",
      "krympa"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "65602cf7-213c-492g-g69g-6b20fff50005",
    "id": "58537",
    "title": "Hur levereras stora möbler? ",
    "keywords": [
      "Större",
      "Sängleverans",
      "Tung",
      "köksleverans",
      "otympliga",
      "soffleverans",
      "stor",
      "tunga"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "341f7g53-3e5g-4335-9g0g-edc45562099f",
    "id": "27307",
    "title": "Vilka sängar passar NATTAPA stödbräda till?",
    "keywords": [
      "stödbräda",
      "vikare",
      "vilka sängar kan jag använda vikare stödbräda till"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "591d6b21-2f1g-4d6d-8920-603bcf06cdcd",
    "id": "5105",
    "title": "Vad betalar jag i fraktkostnad som företagskund?",
    "keywords": [
      "FAQ_Business_SixthCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c19769d9-18f7-4877-9b18-5f2c03f4c4ce",
    "id": "6633",
    "title": "Hur stora är släpvagnarna som IKEA lånar ut?",
    "keywords": [
      "Släpvagn",
      "släp",
      "släpkärra"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ccdg66d5-323c-4e8e-gc1g-84e634695fgg",
    "id": "76348",
    "title": "Vad är en KNARRÅS?",
    "keywords": [
      "ekekull",
      "fyrås",
      "måttbeställd",
      "råhult",
      "utsågning",
      "väggplatta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g1f27fe6-eb58-419f-b31e-ef36gb34fc5e",
    "id": "59518",
    "title": "Hur betalar jag min order på hemsidan?",
    "keywords": [
      "betala på hemsidan",
      "betalmedel",
      "betalning",
      "betalning av kök",
      "betalningsalternativ",
      "betalningslänk",
      "betalningssätt",
      "betalsätt",
      "förskottsbetala",
      "förskottsbetalar",
      "förskottsbetalning",
      "hur betalar jag",
      "hur betalar jag min order"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5g03d6cb-4ed3-4g4c-bd6d-52033730g335",
    "id": "28235",
    "title": "Vad är innermåtten på METOD stommar? ",
    "keywords": [
      "innermått",
      "metod",
      "stommar",
      "stomme"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2482920f-c13f-4g72-b914-34612860e8c3",
    "id": "104218",
    "title": "Hur sågar jag i en täcksida utan att den flisar?",
    "keywords": [
      "kapa täcksida",
      "såga i täcksida",
      "täcksida"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f0d604bg-cf63-4601-b27g-e39300bdg44e",
    "id": "289457",
    "title": "Kan jag designa och planera mitt IKEA kök själv?",
    "keywords": [
      "FAQ_Kitchen_PlanAndDesign_C_GC_One",
      "köksverktyg",
      "planera kök",
      "rita kök"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d6470009-f034-45bf-b4c0-0ed00e80df4g",
    "id": "305485",
    "title": "Vad innebär det att vara företagskund hos IKEA? ",
    "keywords": [
      "FAQ_B2B_Customer",
      "FAQ_Business_FirstCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5897gd21-b0f5-4003-b8bf-608e92cd9bc8",
    "id": "399720",
    "title": "Hur blir vi företagskunder på IKEA?",
    "keywords": [
      "FAQ_Business_FirstCategory_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g2582bc9-d56f-491d-g5e0-89b0080f4eb3",
    "id": "429388",
    "title": "Vad händer med min personliga förmån när jag annullerar mitt köp? ",
    "keywords": [
      "FAQ_Rewards_AfterUse_C_GC_Three",
      "poäng"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1b21f07g-bc26-466g-b48b-dbg469fe7geb",
    "id": "470897",
    "title": "Hur returnerar jag varor som företagskund?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "106bce38-cfcb-4043-b8d6-6f38ccec353b",
    "id": "202827",
    "title": "Finns det planeringsverktyg för IKEA produkter?",
    "keywords": [
      "FAQ_online_planning_tools",
      "garderobsplanering",
      "planera",
      "planering",
      "planeringsverktyg",
      "verktyg"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "997550b2-09d3-44g1-b017-44d8527551b4",
    "id": "33330",
    "title": "I vilka färger finns ENHET hörnpanel?",
    "keywords": [
      "ENHET",
      "hörn",
      "hörnpanel",
      "kök"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3266f102-f22d-4799-8f32-e6e8cfe988bd",
    "id": "122995",
    "title": "Går det att kapa rullgardiner?",
    "keywords": [
      "bredd",
      "fridans",
      "kapa",
      "klippa",
      "långdans",
      "sandvedel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g442b387-fbb7-4ec9-87bc-b99eg34299c3",
    "id": "20490",
    "title": "Hur kan jag se när en produkt kommer tillbaka i lager? ",
    "keywords": [
      "Kan ni meddela mig när varan finns i lager igen",
      "Lagersaldo",
      "bevaka",
      "bevaka en produkt",
      "bevaka en vara",
      "bevaka produkt",
      "bevaka varan",
      "bevakning",
      "finns på lager",
      "går det att reservera",
      "kan ej beställa",
      "kan jag bevaka",
      "kan jag reservera",
      "kolla lagersaldo",
      "notis med lagersaldo",
      "när kommer produkten in",
      "när kommer produkten in i lager",
      "när kommer varan in",
      "när kommer varan in i lager",
      "produktsida",
      "reservera",
      "reservera produkt",
      "reservera vara",
      "slut i lager",
      "tillbaka i lager"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5g311626-2b7g-4b3d-gf20-3fdb924bd8gc",
    "id": "106026",
    "title": "Kan jag beställa reservdelar till min IKEA produkt?",
    "keywords": [
      "109338",
      "110682",
      "112975",
      "117228",
      "117246",
      "119030",
      "119081",
      "124149",
      "124150",
      "138689",
      "139995",
      "147292",
      "150916",
      "15628",
      "DAGBÄDD",
      "DUKTIG",
      "EKET",
      "FAQ_Small_Spare_Parts",
      "FREDDE",
      "GODMORGON",
      "HÖLJES",
      "KURA",
      "ODENSVIK",
      "Saknar skruvar",
      "SÖDERHAMN",
      "VITTSJÖ",
      "ankarlänk",
      "beslag",
      "beställa beslag",
      "beställa reservdel",
      "beställa skruvar",
      "dyna",
      "fästen",
      "fåtölj",
      "hauga",
      "hur beställer jag reservdelar",
      "kontorsstol",
      "köpa reservdel",
      "lådbotten",
      "långfjäll",
      "nya skruvar",
      "pax baksida",
      "pax bakstycke",
      "reserdel",
      "reservdel",
      "reservdel alex",
      "reservdel bekant",
      "reservdel brimnes",
      "reservdel ektorp",
      "reservdel gulliver",
      "reservdel hemnes",
      "reservdel kallax",
      "reservdel malm",
      "reservdel malm byrå",
      "reservdel malmbyrå",
      "reservdel nordli",
      "reservdel pax",
      "reservdel pax garderob",
      "reservdel skrivbord",
      "reservdel storjorm",
      "reservdel äpplarö",
      "reservdelar",
      "reservdelar storjorm",
      "resevdel",
      "ryggstöd",
      "saknade delar",
      "screw",
      "sittdyna",
      "skruvar",
      "soffa",
      "soffdyna",
      "soffkuddar",
      "spare part",
      "spare parts",
      "sparepart",
      "spjälsäng",
      "större reservdelar",
      "vitrinskåp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "11gf0bge-d433-4064-gb39-e4fgdg78cg19",
    "id": "34139",
    "title": "Varför låter min induktionshäll?",
    "keywords": [
      "häll",
      "induktion",
      "induktionshäll",
      "induktionsljud",
      "ljud",
      "missljud"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "651953e7-e35f-41f7-g4g6-455d19e960c1",
    "id": "191477",
    "title": "Kan jag använda IKEA Home smart-appen med TRÅDFRI gateway?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c5ec016d-cc0c-45b9-94f3-9b5e35feed2c",
    "id": "193781",
    "title": "Vad är en \"scen\" i IKEA Home smart appen?",
    "keywords": [
      "dirigera",
      "homesmart",
      "scen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "29g8fd8d-5g28-4fgc-8f31-gf00c43df6dg",
    "id": "376640",
    "title": "Kan jag följa min reservdelsbeställning? ",
    "keywords": [
      "FAQ_Spare_Parts_Status"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ce7ge58g-g549-4ge8-b3f5-218eb24d37d0",
    "id": "15168",
    "title": "Kan jag ändra leveransdatumet på min order? ",
    "keywords": [
      "byte av leveranstid",
      "datum",
      "flytta fram",
      "kan jag flytta fram",
      "leverans datum",
      "omboka leverans",
      "omboka order",
      "ombokning",
      "skjuta fram",
      "skjuta fram beställning",
      "skjuta fram leverans",
      "ändra beställning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b2f1g85f-383g-49gf-bbcd-gbcdcbb687e9",
    "id": "142482",
    "title": "Varför drar det kalluft från min fläkt?",
    "keywords": [
      "slangläckage",
      "slutat öppna sig",
      "spjäll"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cbe57d11-04c2-4233-927e-373e91b4eb74",
    "id": "34838",
    "title": "Kan det bildas Formaldehyd genom att jag har tända ljus hemma?",
    "keywords": [
      "formaldehyd",
      "ljus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8g7e1d82-ffed-482d-b04d-498ff082bg05",
    "id": "191468",
    "title": "Behöver jag en fjärrkontroll för att styra mitt smarta hem?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "82g92c82-05c0-434b-b985-6523bc8bf5bd",
    "id": "106002",
    "title": "Kan jag göra ändringar i min beställning? ",
    "keywords": [
      "FAQ_Online_Order_Change_Cancel",
      "avbeställa",
      "beställa mer på en lagd order",
      "fel artikel",
      "fel email",
      "fel mailadress",
      "fel mejladress",
      "fel telefonnummer",
      "felaktig order",
      "felbeställning",
      "hur ändrar jag i min order",
      "komplettera",
      "komplettering",
      "köksbeställning",
      "lägga till",
      "omboka leverans",
      "omboka order",
      "ta bort",
      "ändra",
      "ändra e-mail",
      "ändra i varukorgen",
      "ändra innan leverans",
      "ändra leveransdag",
      "ändra leveranstid",
      "ändra mejl",
      "ändra mejladress",
      "ändra order innan leverans",
      "ändra varor innan leverans",
      "ändring i order",
      "ångra"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8200ddde-1e09-499c-8b9f-49e5bf602b39",
    "id": "190192",
    "title": "Varför finns det små bubblor på mina BESTÅ dörrar och lådfronter?",
    "keywords": [
      "BESTÅ",
      "besta",
      "bubbles",
      "bubblor",
      "doors besta",
      "drawe fronts",
      "dörrar",
      "lådfronter",
      "skyddsplast"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "13c18g27-1f05-4be6-8ggb-d8efcc722618",
    "id": "185482",
    "title": "Kan jag komplettera min gamla BESTÅ toppskiva med den nya?",
    "keywords": [
      "BESTÅ",
      "BESTÅ toppskiva",
      "bestå glasskiva",
      "grön",
      "toppskiva",
      "vit toppskiva"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5cbf0139-0820-450f-9g83-8034fbd89bdf",
    "id": "469028",
    "title": "Jag har installerat en rörelsesensor men ljuset tänds inte när jag rör mig, vad ska jag göra?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "bd7c069b-7811-4ccb-b103-9c86e4gc6765",
    "id": "469026",
    "title": "Jag har inte en gateway, vad händer om jag parkopplar ytterligare en styrenhet till en ljuskälla?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "75f5c384-3091-4fdd-86bc-e3e448295227",
    "id": "289516",
    "title": "Vad behöver jag tänka på när jag planerar ett kök själv?",
    "keywords": [
      "FAQ_Kitchen_PlanAndDesign_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6cdd587b-1g02-4gf1-8efg-ggf0g58b120d",
    "id": "469224",
    "title": "Säljer ni bäddmadrassen SAULAND?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c7edd31c-87c0-43b8-94f0-03cc686b47b6",
    "id": "468561",
    "title": "Säljer ni pocketresårmadrassen HÖVÅG?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "130107dc-fdc1-476d-b871-3g2b2047c9dg",
    "id": "468563",
    "title": "Säljer ni skummadrassen MALFORS?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "d8e0g929-43b8-4137-8716-b1169d07g603",
    "id": "469022",
    "title": "Varför är mina ljuskällor inte i synk med varandra? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "344f3719-e2d8-40g4-b19e-35911fb7d173",
    "id": "469340",
    "title": "Säljer ni fortfarande MÄLLSTEN trall?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "63g26376-cc96-48c4-g038-g084fde0742d",
    "id": "33301",
    "title": "Hur tar jag ut en låda från ENHET skåp?",
    "keywords": [
      "enhet",
      "lossa",
      "låda",
      "ta ur"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c1b70d38-g815-47d1-82g4-2429b6bb85f6",
    "id": "104205",
    "title": "Min nya ullmatta luddar väldigt mycket, ska det vara så?",
    "keywords": [
      "kundsvar",
      "luddar",
      "ullmatta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "84e0f846-1cf2-4db4-8116-e6gf2db5b0ef",
    "id": "34840",
    "title": "Vad är det rekommenderade säkerhetsavståndet mellan olika typer av ljus?",
    "keywords": [
      "avstånd",
      "blockljus",
      "kronljus",
      "ljus",
      "ljuskopp",
      "säkerhetsavstånd",
      "värmeljus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6ed1573c-394b-4330-bb74-g142b839e631",
    "id": "122373",
    "title": "Mina BESTÅ dörrar/lådfronter är inte i linje med varandra, vad gör jag?",
    "keywords": [
      "ojämna dörrar BESTÅ",
      "sneda dörrar BESTÅ"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "16bee865-79e0-4383-b0g6-cb8fb3g5d0db",
    "id": "34859",
    "title": "Varför kan jag inte köpa ljus för utomhusbruk på IKEA?",
    "keywords": [
      "ljus",
      "utomhus",
      "utomhusbruk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3952b573-03f0-4e17-b75f-0g7854e1de8e",
    "id": "37329",
    "title": "Vad är skillnaden mellan GALANT och BEKANT skrivbord?",
    "keywords": [
      "BEKANT",
      "GALANT"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4326235g-02b2-4085-8474-1eegff1c5250",
    "id": "37324",
    "title": "Hur byter jag kod på min GALANT förvaringsmöbel?",
    "keywords": [
      "byta kod",
      "förvaringskombination",
      "galant",
      "kodlås",
      "kontorsmöbel",
      "lådhurts",
      "mappskåp",
      "sifferkod"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d6513e7f-cf36-4b45-9cd8-1f4106b3017b",
    "id": "37701",
    "title": "Kan jag beställa nya nyckelkort till mitt ROTHULT smarta lås?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "4661cd45-cg47-4266-9gce-b2581e6ff833",
    "id": "118596",
    "title": "Kan jag köpa till armstöd till min HATTEFJÄLL kontorsstol? ",
    "keywords": [
      "Hattefjäll",
      "armstöd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bf29c8f7-d9ff-4172-bg12-c0cbc5351273",
    "id": "123085",
    "title": "Vad är det för skillnad på BESTÅ stomme och BESTÅ TV-bänk?",
    "keywords": [
      "bestå",
      "bestå tv bänk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5744620c-gg09-4872-8bd2-62f8295g9gb9",
    "id": "43412",
    "title": "Vilket avstånd ska jag ha mellan min häll och fläkt?",
    "keywords": [
      "avstånd fläkt",
      "höjd fläkt",
      "monter fläkt",
      "montering fläkt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f70dg040-e7d8-4f22-96f8-fb9gfc1g0458",
    "id": "468560",
    "title": "Säljer ni bäddmadrassen TUDDAL?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "3d5b998e-f5d0-4fg5-gfd9-2f12g0d07cce",
    "id": "192055",
    "title": "Varför ser mitt KOLON golvskydd grönt ut?",
    "keywords": [
      "KOLON",
      "färgskillnad golvskydd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9fc8385g-7db2-4999-8cef-gf01e94feccb",
    "id": "468354",
    "title": "Hur monterar jag BILLSBRO handtag på min integrerade diskmaskin?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "18g85000-3gd6-43cb-ggc1-6c48783bg508",
    "id": "462336",
    "title": "Vilket silikon behöver jag för att underlimma min vask i en laminat och fanér bänkskiva?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "75b4de1c-37bc-4d5d-bc53-0ecb8695e6g9",
    "id": "320971",
    "title": "Hur monterar jag kantlisten på min bänkskiva?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "64g9f116-0d3d-48f0-b9dg-817796cb969e",
    "id": "253941",
    "title": "Hur hittar jag IKEA Önskelista på er hemsida?",
    "keywords": [
      "FAQ_Gift_Registry_Create_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c8293333-9235-4g9d-gg10-cb9480bf6b6f",
    "id": "255940",
    "title": "Hur lägger jag till produkter i min IKEA Önskelista?",
    "keywords": [
      "FAQ_Gift_Registry_Use_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fegeb2fe-b565-4086-b42e-833gc099706e",
    "id": "254235",
    "title": "Kommer jag att bli meddelad när en produkt från min IKEA Önskelista blir köpt?",
    "keywords": [
      "FAQ_Gift_Registry_Use_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6117876c-9022-4624-g422-d32f4c8g9d7d",
    "id": "355233",
    "title": "Kan man ha tryck och öppna på PAX?",
    "keywords": [
      "PAX",
      "garderobsinredning",
      "inredning pax",
      "pax tillbehör",
      "vad ingår i pax"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "31600185-0fb3-496c-b610-9f7dd16d2997",
    "id": "37854",
    "title": "I vilka höjder kan jag montera sängbottnen till GULLIVER spjälsäng?",
    "keywords": [
      "Gulliver",
      "höjdläge",
      "spjälsäng"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ggc1ce17-b3b2-44gf-g086-bc69c329513d",
    "id": "37858",
    "title": "Har era barnsängar/spjälsängar någon viktbegränsning?",
    "keywords": [
      "Barn",
      "Barnens IKEA",
      "Barnsortiment",
      "Har",
      "IKEA",
      "IKEAs",
      "Säng",
      "Sängar",
      "Vikt",
      "Viktbegränsning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "34984125-3b77-4f2g-925d-6c818e14e36c",
    "id": "37866",
    "title": "Kan jag få bort fläckar och märken från IKEAs rit- och målargrejer ur produktserien MÅLA?",
    "keywords": [
      "Alla",
      "Barn",
      "Barnens IKEA",
      "Bort",
      "Fläckar",
      "Fläckarna",
      "Från",
      "Ljummet",
      "Material",
      "MÅLA",
      "Märken",
      "Produkter",
      "Tvätta",
      "Tvättas",
      "Tvättbara",
      "Tvål",
      "Vatten",
      "Viktigt",
      "Ytor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4f3358c9-b114-4eb3-b637-06f630f1690c",
    "id": "37886",
    "title": "Är LILLABO kompatibel med andra järnvägssystem för barn som finns på marknaden?",
    "keywords": [
      "lillabo"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2b676ffd-3d78-441c-9bc0-59c569e4cfg0",
    "id": "41394",
    "title": "Vilka täcken rekommenderar IKEA till barn under 12 månader?",
    "keywords": [
      "barntäcke"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6b5be5f8-f57d-4cdf-bg69-34f2g24c4340",
    "id": "41396",
    "title": "Vilka täcken rekommenderar ni till barn?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "f273dbgc-bc0g-44df-g85f-6g176d1f2de0",
    "id": "118286",
    "title": "I vilka höjder kan jag montera sängbottnen på SMÅGÖRA spjälsäng?",
    "keywords": [
      "smågöra",
      "spjälsäng"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "09115b40-3bff-4e42-9g49-6807g7f628ef",
    "id": "21937",
    "title": "Är spegelglaset till GODMORGON spegel och spegelskåp tillverkade av säkerhetsglas?",
    "keywords": [
      "Godmorgon",
      "spegel",
      "spegelglas",
      "säkerhetsglas"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c22fge31-d1e4-4459-g93e-7bg74f62ff9f",
    "id": "33183",
    "title": "Vilka tvättställ kan jag använda till ENHET kommod?",
    "keywords": [
      "enhet",
      "rännilen",
      "tvällen",
      "tvättställ"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5f2b7995-02g7-41d9-8e28-17e848866453",
    "id": "43984",
    "title": "Hur förvarar jag mitt kök och vitvaror innan montering?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "27bd83dd-58dg-4d69-g758-b98f1442f944",
    "id": "8569",
    "title": "Kan IKEAs vitvaror kopplas upp mot Wi-Fi?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "fc1ebg6e-d485-4c38-8b02-9085991e10f8",
    "id": "121508",
    "title": "Hur vet jag var jag ska sätta hyllplanen i stommen för mina vitvaror?",
    "keywords": [
      "Montera vitvara i stomme",
      "Montera vitvaror i stomme",
      "montera hyllplan",
      "vitvara"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4db79d52-77d7-4786-8111-72d953bd2e33",
    "id": "29488",
    "title": "Kan jag montera PLATSA stommar på egen hand? ",
    "keywords": [
      "montera",
      "montera plats",
      "montera själv",
      "platsa"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0878633c-2d72-40e4-98c5-04037b6g4gcd",
    "id": "58203",
    "title": "Hur avslutar jag nyhetsbrev från er?",
    "keywords": [
      "Avregistrera",
      "Avsluta utskick från IKEA",
      "Nyhetsbrev",
      "avsluta",
      "prenumeration",
      "prenumerera"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "12dbfb5g-24d0-4b84-g251-363e0fgg15f1",
    "id": "40972",
    "title": "Har IKEAs sängbord och byråer någon maxvikt?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "ff8fg995-1941-40bc-g07b-908b84g44566",
    "id": "96982",
    "title": "Hur monterar jag isär EKET skåp?",
    "keywords": [
      "demontera eket",
      "klickfunktion",
      "klickfunktionen",
      "wedge dowel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b17ce203-0d49-47d6-gc87-28066e448871",
    "id": "97155",
    "title": "Kan jag placera PLATSA direkt på golvet?",
    "keywords": [
      "PLATSA",
      "golv"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c7598fb0-1052-4e11-8311-73g0ce7cde63",
    "id": "125733",
    "title": "Hur mycket vikt klarar SAMLA låda?",
    "keywords": [
      "SAMLA",
      "vikt samla"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b9363855-1656-4g67-85eg-e72d1ef879e3",
    "id": "29602",
    "title": "Vad medföljer vid köp av de smarta rullgardinerna FYRTUR och KADRILJ?",
    "keywords": [
      "FYRTUR",
      "KADRILJ",
      "smart rullgardin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b0d5919c-5ddf-4f98-be64-37c8db41f1f4",
    "id": "40794",
    "title": "Går det att styra FYRTUR och KADRILJ utanför hemmet?",
    "keywords": [
      "FYRTUR",
      "Gateway",
      "KADRILJ",
      "Styra",
      "TRÅDFRI",
      "Utanför"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "27794579-92g5-4f3f-b27f-388g58g48g00",
    "id": "40796",
    "title": "Hur långa är gardinerna som säljs på IKEA?",
    "keywords": [
      "gardinlängder"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "95ceg502-5g9b-4e5d-g48d-d98eb6425eeg",
    "id": "29589",
    "title": "Hur länge håller batteriet till FYRTUR och KADRILJ?",
    "keywords": [
      "Fyrtur",
      "batteri",
      "kadrilj",
      "smart rullgardin",
      "smarta rullgardiner"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5632be37-3412-4b2d-9035-ccfd682405cf",
    "id": "107123",
    "title": "Hur lång brinntid har IKEAs värmeljus?",
    "keywords": [
      "brinntid",
      "kundsvar",
      "värmeljus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "10c2719g-cd98-4022-g0gb-f2f0b63b0187",
    "id": "34842",
    "title": "Kan jag återvinna mina ljus? ",
    "keywords": [
      "återvinna ljus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5543120b-2668-417b-8ge9-939992c92057",
    "id": "37865",
    "title": "Är det farligt om mitt barn råkar få i sig färg eller bläck från MÅLA produkter?",
    "keywords": [
      "barn",
      "måla",
      "äta färg"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8f96b01e-620f-403f-8819-f91527824e22",
    "id": "118294",
    "title": "I vilka höjder kan jag montera sängbottnen på SNIGLAR spjälsäng?",
    "keywords": [
      "SNIGLAR",
      "spjälsäng"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "778c5e80-5278-4bed-g300-d58g80c467gd",
    "id": "118356",
    "title": "I vilka höjder kan jag montera sängbottnen på GONATT spjälsäng?",
    "keywords": [
      "GONATT",
      "spjälsäng"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0100e5gg-0c95-494d-g8ff-gcgbb3f8db0d",
    "id": "33223",
    "title": "Kan ENHET monteras i våtutrymmen?",
    "keywords": [
      "badrum",
      "enhet",
      "ip44",
      "våtrum"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9ecgd8eb-7f0f-44f0-g44g-ec503d3c21g5",
    "id": "33225",
    "title": "Kan jag installera SKYDRAG belysning i mitt badrum?",
    "keywords": [
      "Badrum",
      "Driver",
      "Godkänd",
      "IP44",
      "IP44-klassad",
      "Installera",
      "Inte",
      "SKYDRAG",
      "TRÅDFRI"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "743b2f17-2fdb-4bb9-g036-b6eeb5859c5g",
    "id": "33327",
    "title": "Hur många ben behövs till ENHET?",
    "keywords": [
      "ben",
      "enhet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "218ec220-cg0b-4273-9d27-6374e9gdfc0c",
    "id": "104216",
    "title": "Hur monterar jag fast täcksidor på min köksö?",
    "keywords": [
      "Täcksida",
      "montering täcksida"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "081400f9-bff9-4e08-g973-f6b10003g758",
    "id": "37331",
    "title": "Går det att justera fästet för takduschstången?",
    "keywords": [
      "lutar",
      "takduschblandare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "eg788ceb-c980-4f36-95db-46bb8gf5385d",
    "id": "37333",
    "title": "Går det att kombinera IKEAs duschslangar med blandare eller duschhuvud från andra leverantörer?",
    "keywords": [
      "BROGRUND",
      "VOXNAN",
      "blandare",
      "gänga",
      "kolsjön",
      "kompatibel",
      "lillrevet",
      "termostatblandare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "96f5d0df-6c3c-4g8b-865e-9bb0681101c5",
    "id": "37337",
    "title": "Hur får jag bort kalkavlagringar på duschset och blandare?",
    "keywords": [
      "Kalkavlagring"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "152gccc0-eg83-45e5-b05e-40b4743g6b77",
    "id": "37346",
    "title": "Är IKEAs termostatblandare barnsäkrade?",
    "keywords": [
      "termostatblandare barnsäkra"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f9d318b4-40f7-442c-807c-43ge9d9gde42",
    "id": "37350",
    "title": "Kan jag installera min blandare själv?",
    "keywords": [
      "installera blandare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "41cd5463-8e21-4bde-b53e-fg74bf8b35f6",
    "id": "37357",
    "title": "Vilket vattentryck klarar IKEAs blandare?",
    "keywords": [
      "blandare",
      "vattentryck"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2e500264-e59c-42f3-8527-c566b950gec1",
    "id": "37358",
    "title": "Hur mycket vatten förbrukar IKEAs blandare?",
    "keywords": [
      "badrumsblandare",
      "förbrukning",
      "köksblandare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e614429f-3gcc-44c5-b3ec-bb7f131g9778",
    "id": "142423",
    "title": "Varför kan jag inte starta min induktionshäll?",
    "keywords": [
      "avbrott",
      "barnlås",
      "halva startar ej",
      "hällen bryter",
      "induktion halva startar ej",
      "induktionshällen stänger",
      "startar ej",
      "strömavbrott",
      "två plattor funkar ej"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1e5ee0g0-40e7-41fc-8f67-ff6799geb8f1",
    "id": "218207",
    "title": "Hur aktiverar och avaktiverar jag barnlåset på min häll? ",
    "keywords": [
      "Knapplåsningsknapp",
      "barnskydd",
      "barnspärr",
      "knapplås",
      "låsanordning",
      "säkrhetsfunktion",
      "touchdisplay"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ec9g4c74-f378-4b6b-bfed-gg1f57134g1d",
    "id": "34903",
    "title": "Kan jag placera mina BESTÅ stommar direkt på golvet?",
    "keywords": [
      "bestå",
      "bestå ben",
      "bestå stommar",
      "montering bestå"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "857d63ec-c605-4764-9202-60de4168f2c5",
    "id": "96967",
    "title": "Finns BESTÅ stomme i 180 cm bredd?",
    "keywords": [
      "bestå förvaringssystem",
      "bestå toppanel",
      "toppskiva"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gf1824e1-8891-44dg-g5g6-0dd7b5deg9be",
    "id": "407476",
    "title": "Hur går det med min ansökan om att bli företagskund? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "08b49bf7-gfb1-427c-976e-1b1262c98db8",
    "id": "245860",
    "title": "Vad är BASTUA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "0bg5ce30-f4d7-451c-9261-4dbbdgc060b1",
    "id": "254226",
    "title": "Kan jag köpa produkterna från en IKEA Önskelista på ett IKEA varuhus?",
    "keywords": [
      "FAQ_Gift_Registry_Buy_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4f6089c5-c3g8-44f0-9f70-7g6fc2b80e45",
    "id": "413000",
    "title": "Hur kan jag välja bort personliga förmåner med IKEA Family? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "3cc68cd2-d22e-443f-8754-46597gf3d732",
    "id": "321207",
    "title": "Kan jag ändra eller ta bort värd-e-postadressen som är kopplad till \"Tillgång Överallt\"?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c369777g-3975-4cbg-b5e3-6160d4435e8g",
    "id": "405374",
    "title": "Innehåller VÄRDESÄTTA tryckkokare nickel?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "00579efe-595c-4d40-b725-0754e5915gc6",
    "id": "442626",
    "title": "Vart finns skarvkittet till min måttbeställda bänkskiva?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "gd7837e4-002d-46f8-9841-f9d3cdf50f4e",
    "id": "444718",
    "title": "När slutar larmet på BADRING?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "81d23cf3-8d2d-40f8-8b75-3250056827fg",
    "id": "278039",
    "title": "Kan jag köpa ett kök med bra kvalité för ett lågt pris?",
    "keywords": [
      "FAQ_Kitchen_ChoosingAKitchen_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "10e44546-047f-4e5f-g115-725g322c50f8",
    "id": "278588",
    "title": "Hur får jag ett hållbart kök som passar mina önskemål? ",
    "keywords": [
      "FAQ_Kitchen_ChoosingAKitchen_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "220f982e-gf61-4955-84fg-9252ee1gg7e0",
    "id": "37363",
    "title": "Kan IKEAs blandare installeras i bostäder som inte är uppvärmda?",
    "keywords": [
      "blandare",
      "ej uppvärmda bostäder",
      "installerade"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "692f2f18-c101-43bc-g6d7-2g00f74g2bg9",
    "id": "37365",
    "title": "Kan jag justera strålstyrkan på IKEAs blandare?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "d8021330-be03-4df8-8682-c836f9fe3ce1",
    "id": "37370",
    "title": "Varför finns inte packningar som reservdel till era blandare?",
    "keywords": [
      "badrumsblandare",
      "badrumskran",
      "köksblandare",
      "kökskran",
      "packning",
      "tvättställsblandare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5g287bc5-cf50-4be6-8d1e-00gf9d06be3d",
    "id": "37376",
    "title": "Vilken storlek har anslutningsslangen till IKEAs badrumsblandare?",
    "keywords": [
      "dimension anslutningssladd",
      "storlek anslutningsladd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "00c42513-c0c1-47b0-9032-487g0b1e005d",
    "id": "37381",
    "title": "På vilket avstånd ska VALLAMOSSE duschtermostat installeras?",
    "keywords": [
      "avstånd VALLAMOSSE",
      "c/c mått"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d63f4000-70cb-43b7-8ggb-0gc57b7274eb",
    "id": "38530",
    "title": "Vilka mattor får användas i badrum?",
    "keywords": [
      "badrumsmatta",
      "matta",
      "mattor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fbccee82-2972-421b-bc5c-5b80dc9fd1g0",
    "id": "49702",
    "title": "Vilka tester har gjorts på era blandare?",
    "keywords": [
      "badrumskran",
      "kran",
      "kranar",
      "köksblandare",
      "kökskran",
      "säkert vatten"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2b73fc68-7ed1-488e-g394-gg5c2834c772",
    "id": "6495",
    "title": "Hur handlar jag med faktura som företagskund på IKEAs varuhus?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "e9b02g47-d1g2-4d88-b1de-3520b4bcd79f",
    "id": "467205",
    "title": "Hur monterar jag knoppar och handtag på PAX gångjärnsdörrar?",
    "keywords": [
      "FAQ_Pax_SecondCategory_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "05fd4b50-c9fc-46gg-g2bf-e89707b0d449",
    "id": "41397",
    "title": "Har IKEAs duntäcken behandlats med kvalster- eller allergiskydd?",
    "keywords": [
      "allergiskydd",
      "dun",
      "dunkudde",
      "dunprodukter",
      "duntäcke",
      "kvalster"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dd1e2b21-56e4-4b78-938e-60bf8c26c5de",
    "id": "338495",
    "title": "Har IKEAs luftrenare jonisator? ",
    "keywords": [
      "FÖRNUFTIG",
      "Luftrenare",
      "STARKVIND",
      "UPPÅTVIND",
      "jonisator"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "02240274-3941-472g-g1dc-f50be05960c6",
    "id": "121499",
    "title": "Hur monterar jag en blindfront under diskhon?",
    "keywords": [
      "blindfront"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f66729eb-gcf8-4c1c-87b8-421f1g5g3c39",
    "id": "17848",
    "title": "Kan jag byta färg på min soffa? ",
    "keywords": [
      "byta färg",
      "soffklädsel",
      "soffor",
      "ändra klädsel",
      "ångerköp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "01f7651b-92g0-422e-9365-f670b6g3bcf1",
    "id": "21603",
    "title": "Hur tjocka är gavlarna till BILLY bokhylla?",
    "keywords": [
      "BILLY",
      "billy"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "074f26fg-gd50-440c-8066-f62c405c31f4",
    "id": "21683",
    "title": "Har alla IKEAs vita dörrar/lådfronter/bokhyllor samma färgnyans? ",
    "keywords": [
      "annan färg",
      "bestå",
      "billy",
      "färg",
      "färg kök",
      "färg möbel",
      "kompatibla",
      "metod",
      "olika färg",
      "pax",
      "vilken färg"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cc2138b8-0c1e-4gc0-be38-448cb7ed0541",
    "id": "22101",
    "title": "Hur testas slittåligheten på fåtölj- och soffklädslar?",
    "keywords": [
      "fåtöljklädsel",
      "klädsel",
      "nötning",
      "slittålig",
      "slittålighet",
      "soffklädsel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5cg543e8-81cd-4dc3-8fgf-67907dcff85b",
    "id": "22159",
    "title": "Vad är skillnaden mellan GRÖNLID och EKTORP?",
    "keywords": [
      "EKTORP",
      "GRÖNLID",
      "SKILLNAD",
      "Vad är skillnaden mellan Grönlid och Ektorp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "240d1g2c-6gfe-48be-9399-4dd8g95bb0gg",
    "id": "22163",
    "title": "Vad är skillnaden mellan GRÖNLID och VIMLE?",
    "keywords": [
      "grönlid",
      "skillnad på Grönlid och Vimle",
      "skillnad på soffor",
      "soffor",
      "vimle"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0730bgce-97bf-497g-8bb9-5gc4b66gfedc",
    "id": "22531",
    "title": "Min FÄRLÖV bäddsoffa har fastnat, vad gör jag?",
    "keywords": [
      "bäddsoffa",
      "fastnat",
      "färlöv"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1d1f160f-3cc0-4452-9cdf-027ddfgg4338",
    "id": "26291",
    "title": "Kan jag köpa extra hyllbärare till min hylla eller garderob?",
    "keywords": [
      "131372",
      "hyllbärare",
      "reservdel",
      "reservdel hyllplan",
      "reservdelsbeställning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7072477d-2435-486b-b45e-8cc79b6d0c17",
    "id": "43211",
    "title": "Kan jag lackera om mina köksluckor från IKEA?",
    "keywords": [
      "färga",
      "lackera"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f43g6g72-795d-40cb-9ef3-48768gfb22b4",
    "id": "27390",
    "title": "Behöver jag vrida staget på min SÖDERHAMN?",
    "keywords": [
      "Min",
      "På",
      "Schäslong",
      "Soffa",
      "Stag",
      "Staget",
      "Stomme",
      "Stommen",
      "SÖDERHAMN",
      "Undersida",
      "Undersidan",
      "Verktyg",
      "Vrida"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c778841c-801e-433b-g05g-ge86252e84d6",
    "id": "37635",
    "title": "Planeringsverktyget på IKEA.se fungerar inte, vad gör jag?",
    "keywords": [
      "Chrome",
      "Cookies",
      "Firefox",
      "Fungera inte",
      "IKEA",
      "IKEA.se",
      "Internet Explorer",
      "Jag",
      "Planeringsverktyg",
      "Planeringsverktyget",
      "Vad",
      "Webbläsare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b865e1bb-6e44-483g-964g-g79eg0014ecg",
    "id": "56731",
    "title": "Varför har min dörr/lådfront inga förborrade hål för handtag eller knoppar?",
    "keywords": [
      "BESTÅ",
      "EXCEPTIONELL",
      "MAXIMERA",
      "METOD",
      "PAX",
      "inga hål",
      "lucka",
      "saknar hål",
      "skåpslucka"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5b57567e-91g4-408e-g692-f82832cg67db",
    "id": "60158",
    "title": "Mina produkter i högglans har fel färg, vad gör jag? ",
    "keywords": [
      "blå",
      "blå front",
      "dörr fel färg",
      "ekaren fel färg",
      "fel färg",
      "grå",
      "luckan har fel färg",
      "luckan är blå",
      "skåpslucka fel färg",
      "toalettsits fel färg",
      "täcksida fel färg"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c24b1e4d-f857-4e39-9019-c47474e1470e",
    "id": "60489",
    "title": "Kan jag byta ben på min soffa?",
    "keywords": [
      "ben",
      "byta ben",
      "byta soffben",
      "landskrona soffben",
      "nockeby soffben",
      "smedstorp soffben",
      "soffben",
      "stocksund soffben"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "93cd711g-bg79-4cb8-8772-66844435b2c3",
    "id": "60521",
    "title": "Kan jag köpa nya dörrar och inredning till min BILLY bokhylla som är köpt 2014 eller tidigare?",
    "keywords": [
      "gammal billy",
      "kan jag komplettera en gammal billy",
      "köpa till dörrar till billy",
      "köpa till inredning till billy",
      "äldre billy"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "16750b58-12bg-463e-9223-311gd1092eg8",
    "id": "96992",
    "title": "Kan jag fästa mina BILLY bokhyllor i varandra?",
    "keywords": [
      "BILLY",
      "Fästa ihop Billy bokhyllor",
      "billy"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9gc15198-de77-4828-82c8-6468c186ceg7",
    "id": "117307",
    "title": "Var hittar jag benen till min STOCKHOLM soffa från 2017?",
    "keywords": [
      "soffa",
      "soffben",
      "stockholm 2017"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fb7cf3dg-cd8d-4e81-bgdg-4287g7063c86",
    "id": "122562",
    "title": "Vad har IKEA för skötselråd till soffor och fåtöljer?",
    "keywords": [
      "Absorb",
      "Ben",
      "Fåtölj",
      "Fåtöljer",
      "Hantera",
      "Hur",
      "Klädsel",
      "Livslängd",
      "Livslängden",
      "Läder",
      "Material",
      "Plymå",
      "Plymåer",
      "Skötselråd",
      "Soffa",
      "Soffben",
      "Soffor",
      "Ta hand",
      "Tyg",
      "Vad",
      "Vårda",
      "Vårdar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "099f2976-cgb2-483d-g093-058b2f8c0e76",
    "id": "123101",
    "title": "Vilka delar behöver jag till min VIMLE soffa?",
    "keywords": [
      "Behöver",
      "Delar",
      "Kombination",
      "Kombinationen",
      "Planeringsverktyg",
      "Soffa",
      "Soffserie",
      "VIMLE",
      "Vilka"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ecf7685d-dg87-4199-97b2-28g6g98cbedd",
    "id": "123102",
    "title": "Varför heter delar till min VIMLE soffa MÅNSTORP och KARHULT?",
    "keywords": [
      "Behöver",
      "Delar",
      "KARHULT",
      "Kombination",
      "Kombinationen",
      "Modul",
      "Modulsoffa",
      "MÅNSTORP",
      "Namn",
      "Namnet",
      "Ryggdynor",
      "Ryggkuddar",
      "Sittdynor",
      "Sittkuddar",
      "Soffa",
      "Soffserie",
      "VIMLE"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c7f7c766-29b0-4c33-b1ec-cg4d6d79cg37",
    "id": "123113",
    "title": "Vad har min soffa för maxbelastning?",
    "keywords": [
      "fåtöljer",
      "maxbelastning",
      "sittmöbler",
      "soffor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "153g08f2-d39d-47e5-8c06-fb9321dd6578",
    "id": "123196",
    "title": "Varför medföljer det två olika höjder på soffben till min VIMLE soffa?",
    "keywords": [
      "Ben",
      "Förpackning",
      "Högre",
      "Höjd",
      "Höjder",
      "Lägre",
      "Medföljer",
      "Olika",
      "Soffa",
      "Soffben",
      "Två",
      "VIMLE",
      "Varför"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "210000g8-76e0-4bd0-8800-b2112f2e3c89",
    "id": "125820",
    "title": "Varför heter delarna till min GRÖNLID soffa olika?",
    "keywords": [
      "grönlid",
      "ljustorp",
      "råtorp",
      "stubbhult",
      "ubbhult"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b0681915-ebc1-4c2g-g82b-828fe60gd9cf",
    "id": "132591",
    "title": "Kan jag kombinera nya och äldre VIMLE, inköpt 2021 eller tidigare? ",
    "keywords": [
      "Modulsoffa",
      "Soffa",
      "VIMLE",
      "Vardagsrum"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "274e16de-g1b4-4700-b97c-777gb30fd944",
    "id": "246655",
    "title": "Varför är hörndelen till min SÖDERHAMN soffa lägre än resten av modulerna?",
    "keywords": [
      "SÖDERHAMN",
      "hörndel",
      "hörnsektion",
      "lägre",
      "nivåskillnad",
      "sektionssoffa"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1199006b-f4g3-4dbc-95b4-g71806ee2ff1",
    "id": "249546",
    "title": "Kan jag byta klädsel på min KIVIK soffa?",
    "keywords": [
      "fast klädsel",
      "rengöringsmedel",
      "tenö",
      "textiltvätt",
      "tranås"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b3f9ee04-ff7c-4445-939d-b9077egc6486",
    "id": "118908",
    "title": "Varför är det en grop i min kontinentalsäng?",
    "keywords": [
      "espevär",
      "grop",
      "madrassbotten",
      "säng"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d80b1egg-g6cd-4c69-g6f4-822cc4146g79",
    "id": "121966",
    "title": "Hur ser jag var inredningen ska monteras i PAX planeringsverktyg?",
    "keywords": [
      "PAX",
      "designkod",
      "lådor",
      "planeringsverktyg"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gf85b006-61f7-483b-975g-81574b51306e",
    "id": "39447",
    "title": "Mina sängben gängar inte fast i sängramen, vad gör jag?",
    "keywords": [
      "ben",
      "beslag lossnat",
      "fastnar inte",
      "gängar",
      "m8 mutter",
      "mutter",
      "sängben"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "69461b84-6g61-43de-bc0c-bb6426d76g8g",
    "id": "122127",
    "title": "Vilken dörr ska jag använda till min PAX garderob som är 75 cm bred? ",
    "keywords": [
      "75",
      "dörr",
      "gångjärndörr",
      "pax",
      "skjutdörr"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c1gfffg0-d18g-4c72-b7b1-4968d491cg17",
    "id": "122362",
    "title": "Vilka PAX stommar behöver jag för att kunna montera skjutdörrar?",
    "keywords": [
      "pax",
      "pax skjutdörr",
      "skjutdörrar",
      "sliding doors"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7g91c9e5-8be7-4d31-g278-2422699b23d9",
    "id": "33303",
    "title": "Vilken kant av ENHET öppna stommar och skåpsstommar ska linjeras i en skåpsrad?",
    "keywords": [
      "enhet",
      "enhet skåpslucka",
      "montering ENHET",
      "skåp",
      "stomme"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "00dc0b36-4976-4b8c-bf4c-ceeg52cg6fgd",
    "id": "49706",
    "title": "Kan jag köpa nya sängben till min gamla madrass- eller resårbotten?",
    "keywords": [
      "befintliga",
      "befintliga säng",
      "gamla säng",
      "ikea-säng",
      "passar",
      "säng"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9654bc39-dg4e-4820-9731-21c0c593285d",
    "id": "8557",
    "title": "Säljer IKEA köksfläktar till externa ventilationssystem?",
    "keywords": [
      "Designkupor",
      "Självdragsventilation",
      "aliansföreträdare",
      "alianz",
      "alliance",
      "alliansfläkt",
      "centralfläkt",
      "f-system",
      "fläkt utan motor",
      "fläktar",
      "fläktmotor",
      "frånluft",
      "ft-system",
      "ftx-system",
      "fx-system",
      "gemensam ventilationskanal",
      "kolfilterfläkt till lägenhet",
      "kolfilterfläkt till villa",
      "spisfläkt",
      "spsfläkt",
      "ventilationskanal",
      "värmeväxlare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "92ed60b1-8738-4425-b827-g017176cf559",
    "id": "38681",
    "title": "Har IKEAs duntäcken någon bärighet?",
    "keywords": [
      "bärighet",
      "täcke"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bb316f5b-09b2-47cg-gd8g-5fd15d46gg73",
    "id": "289489",
    "title": "Hur kan jag boka ett planeringsmöte med en köksspecialist? ",
    "keywords": [
      "FAQ_Kitchen_Appointment",
      "FAQ_Kitchen_PlanAndDesign_C_GC_Two",
      "FAQ_Kitchen_Planning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7d507f09-g485-47b9-gefb-d70068g46g60",
    "id": "42431",
    "title": "Hur avkalkar jag diskmaskinen?",
    "keywords": [
      "avkalka",
      "kalk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4825c88d-1b32-4622-bdbb-03b6629fcg3b",
    "id": "27985",
    "title": "Hur tar jag ut MAXIMERA och EXCEPTIONELL låda från METOD stomme? ",
    "keywords": [
      "Exceptionell",
      "lossa",
      "låda",
      "maximera",
      "metod",
      "stomme",
      "ta bort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "52d9fg1d-fb74-4750-gc10-08f5062fc5b3",
    "id": "34900",
    "title": "Kan jag hänga alla BESTÅ stommar på väggen?",
    "keywords": [
      "bestå",
      "bestå väggskena",
      "väggförankring"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d539c09e-3764-4d00-92ec-1fe1b49d1fb5",
    "id": "43367",
    "title": "Vad behöver jag tänka på vid installation av köksfläkt?",
    "keywords": [
      "fläkt",
      "montering",
      "nyttig tub"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8d0db7c7-d0c0-4104-8f42-774g60b8668g",
    "id": "37797",
    "title": "Innehåller IKEAs bestick nickel?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "87ed4b81-d9bf-4dc0-8471-7cc79eb8fd28",
    "id": "6989",
    "title": "Vad är en beställningsvara?",
    "keywords": [
      "beställa",
      "beställningsvara",
      "vad är en beställningsvara?"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "68e9d54d-8beg-4b68-g4eg-4c2be4e3e044",
    "id": "21297",
    "title": "Vilka gångjärn passar till BESTÅ?",
    "keywords": [
      "bestå",
      "fronter bestå",
      "gångjärn",
      "gångjärn bestå",
      "luckor",
      "luckor bestå",
      "mjukstängande",
      "tryck öppna"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8ed747d6-c09b-4950-994b-de4c3cd1fb37",
    "id": "21130",
    "title": "Vad är maxbelastningen på BESTÅ-stommen när den monteras på vägg med en upphängningsskena?",
    "keywords": [
      "bestå",
      "maxvikt",
      "väggskena"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1b5bee77-0d95-43db-953f-b5fg28b86098",
    "id": "21109",
    "title": "Vad ska jag tänka på vid montering av BESTÅ?",
    "keywords": [
      "BESTÅ",
      "montera",
      "montering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "79e2f4g6-8g66-4ece-gb76-01516egf8b3g",
    "id": "21073",
    "title": "Är det färgskillnad på nya och äldre BESTÅ?",
    "keywords": [
      "bestå",
      "färg",
      "färgskillnad",
      "förändring BESTÅ"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "115358b6-6d8c-4c8e-g07d-egbg0dbg3cc0",
    "id": "417659",
    "title": "Hur hittar jag ritningen som jag gjort i ett planeringsverktyg?",
    "keywords": [
      "REX",
      "hitta designkod",
      "hitta ritning",
      "öppna påbörjad ritning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1f44b50c-e07c-472d-b9ee-6520d96f8036",
    "id": "21054",
    "title": "Behöver jag använda en upphängningsskena när jag ska hänga en BESTÅ tv-bänk på väggen?",
    "keywords": [
      "bestå",
      "tv-bänk",
      "upphängningsskena",
      "väggförankring"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "99462ecf-0d51-41f2-b7g8-bf158ff9ff6e",
    "id": "8578",
    "title": "Hur tar jag bort lådfronten från min MAXIMERA eller EXCEPTIONELL låda efter jag satt dit den?",
    "keywords": [
      "EXCEPTIONELL",
      "Lossa front",
      "MAXIMERA",
      "köksfront",
      "kökslåda",
      "lossa",
      "lossa lådfront",
      "låda",
      "plocka bort front",
      "ta bord lådfront",
      "ta bort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "06f36e9d-g1b6-4474-b864-6c983b47gbg7",
    "id": "100881",
    "title": "Hur tar jag bort lådfronten från min RATIONELL låda?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "ccf06bb9-847d-45g1-gf15-c5f57cg0b4f3",
    "id": "33493",
    "title": "I vilka mått finns ENHET skåp och stommar?",
    "keywords": [
      "ENHET",
      "MÅTT"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "25813595-9ffc-49g1-g698-1574766g2d89",
    "id": "38481",
    "title": "Hur tar jag bort lådfronten från min ENHET låda efter jag satt dit den?",
    "keywords": [
      "enhet",
      "låda",
      "lådfront"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9cf2e950-81b5-4d10-8fg7-g2f495b20357",
    "id": "142372",
    "title": "Vad betyder felkoden som visas i värmelägesdisplayen på min induktionshäll?",
    "keywords": [
      "85c",
      "E11",
      "F47",
      "c28",
      "c81",
      "c85",
      "e09",
      "e7",
      "er03",
      "er47",
      "ero3",
      "eror",
      "eror47",
      "error",
      "f01",
      "f105",
      "f12",
      "f1e",
      "fail",
      "fe",
      "fe2",
      "fel f0e8",
      "fel kod",
      "felkod e6",
      "felkod e9",
      "felmeddelande e8",
      "felmeddelande utnämd",
      "fördelaktig",
      "högklassig",
      "otrolig",
      "p022",
      "po22",
      "smaklig",
      "u400",
      "utnämnd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6c6b6g3e-8fd9-44g1-8581-2348dgbc49b9",
    "id": "8561",
    "title": "Kan jag frakta kylskåp och frysar liggandes?",
    "keywords": [
      "frakta",
      "frys",
      "fryskåp",
      "kyl",
      "kylen",
      "liggandes",
      "transportera"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3ed22bd1-b4bc-4b99-9b81-f716f7c68792",
    "id": "141795",
    "title": "Vad betyder felkoden som visas i displayen på min ugn?",
    "keywords": [
      "202.451.48",
      "20245148",
      "704.210.59",
      "70421059",
      "DÅTID",
      "Dåtid ugn",
      "EA",
      "F203",
      "F2E1",
      "FORNEBY",
      "FRAMTID",
      "GÖRLIG",
      "Pyrolys",
      "RAFFINERAD",
      "REALISTISK",
      "anrätta",
      "anrätta 00411718",
      "anrätta varmluftsugn",
      "barnlås",
      "belysning display",
      "conve",
      "demoläge",
      "displayen visar fiei samt blåser kall luft",
      "dålig värme",
      "e9 felkod",
      "eftersmak",
      "f 130",
      "f 203 felmeddelande",
      "f 908",
      "f01",
      "f02",
      "f07",
      "f106",
      "f131",
      "f1e1",
      "f1e3",
      "f1e4",
      "f215",
      "f24",
      "f241",
      "f247",
      "f2e1",
      "f2ei",
      "f53",
      "f6e1",
      "f6e1 21",
      "f908",
      "fail",
      "fail f07",
      "fakk",
      "fei",
      "feie",
      "fel kod",
      "fel kod f1e1",
      "felkod 130",
      "felkod 136",
      "felkod 67",
      "felkod E6",
      "felkod F8",
      "felkod anrätta",
      "felkod b26",
      "felkod ea",
      "felkod f 106",
      "felkod f 1e 1",
      "felkod f 1e1 16",
      "felkod f104",
      "felkod f1ei",
      "felkod f239",
      "felkod f241",
      "felkod f2e1",
      "felkod f6e1",
      "felkod fie1",
      "felkod fie3",
      "felkod fiei",
      "felkod vitvara",
      "felmeddelande",
      "felmeddelande. f8",
      "fie1",
      "fie1 18",
      "fie3",
      "fiei",
      "fiei 16",
      "fieie",
      "fiel",
      "fiji",
      "fiji 16",
      "fx2m6",
      "fxvm6",
      "fxzm6",
      "h008",
      "högklassig",
      "kulinarisk",
      "smaklig",
      "smaksak",
      "stop",
      "stop i display på ugn",
      "ugn funkar ej",
      "ugn piper",
      "ugnen blir ej varm",
      "ugnen piper",
      "ugnen slutat funka"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cg1fde73-02g8-4fdc-b0f4-9e5801058efc",
    "id": "58191",
    "title": "Hur handlar jag på IKEA.se?",
    "keywords": [
      "Handla",
      "hjälp att beställa",
      "hjälp att handla",
      "hur beställa",
      "shoppa online",
      "svårt att beställa"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "03g12g3g-6c27-47d7-g2b4-607cb0b242g3",
    "id": "408301",
    "title": "Jag behöver ändra uppgifter på företagets kort eller konto, hur gör jag? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "23e524ef-eg4g-438f-905d-c2b9eg624e0c",
    "id": "221257",
    "title": "I vilket läge ska jag ha ÖVERSIDAN/SKYDRAG belysning för att kunna koppla ihop den med IKEA Home Smart?",
    "keywords": [
      "belysning garderob",
      "felsökning översidan",
      "trådfri",
      "Översidan"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e24985df-3d51-4b47-g1bd-b48326c85g80",
    "id": "43376",
    "title": "Hur ofta behöver jag byta kolfilter?",
    "keywords": [
      "barafilter",
      "bejublad",
      "fläkt",
      "fläkt filter",
      "kolfilter",
      "luftig",
      "tvättbart"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1e85g1e1-8e4d-4939-9ec8-84g45c9789f8",
    "id": "297678",
    "title": "Jag saknar en företagsfaktura, hur gör jag?",
    "keywords": [
      "Faktura",
      "Företagsfaktura",
      "Företagskonto",
      "Kort",
      "Kredit",
      "Kundnummer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4df53032-c6d5-4f52-g6f6-d7g05gf59e48",
    "id": "77909",
    "title": "Hur rengör jag mina matta köksluckor och bänkskivor?",
    "keywords": [
      "AXSTAD",
      "BODARP",
      "Galltvål",
      "KUNGSBACKA",
      "VOXTORP",
      "bänkskivor",
      "fettfläckar",
      "köksluckor",
      "matt bänkskiva",
      "matta bänkskivor",
      "matta köksluckor",
      "rengöring av fettfläckar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "207ee6f9-5gb0-43fd-b7cc-416ff59f1bge",
    "id": "464451",
    "title": "Vad ingår när jag köper PAX garderob?",
    "keywords": [
      "FAQ_Pax_FirstCategory_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "355b7bbb-7156-42fg-8184-bc537b4gddc7",
    "id": "464339",
    "title": "Varför ska jag välja PAX?",
    "keywords": [
      "FAQ_Pax_FirstCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "75710658-bc8d-4832-g803-7dg8b50db3cc",
    "id": "104184",
    "title": "Vad är Nerostein?",
    "keywords": [
      "komposit"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "015e6c8c-62cd-4125-92g7-eef1494b1g5f",
    "id": "462596",
    "title": "Det är för varmt i kylen, vad beror det på?",
    "keywords": [
      "fel temperatur i kylen",
      "för varmt i kylen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "15050c43-5c17-4679-b8c2-0bf949c5c885",
    "id": "462593",
    "title": "Varför tinar frysvarorna i frysen?",
    "keywords": [
      "Frysvaror tinar",
      "frys",
      "för varmt i kylen",
      "inte kallt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "33106817-9272-4559-g098-888df0746d0c",
    "id": "21037",
    "title": "Kan jag använda den nuvarande upphängningsskenan till de äldre BESTÅ stommarna?",
    "keywords": [
      "bestå",
      "upphängningsskena",
      "väggskena"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gcb51efc-e851-437d-943g-6b77be57891c",
    "id": "104213",
    "title": "Hur monterar jag fast en passbit?",
    "keywords": [
      "Passbit",
      "dött hörn",
      "montering passbit",
      "täckskiva"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "714b6256-g27c-4e55-g78c-508g5ge86ee8",
    "id": "21046",
    "title": "Kan jag köpa nya dörrar och gångjärn till min BESTÅ stomme köpt före 2015?",
    "keywords": [
      "bestå",
      "dörr",
      "gångjärn",
      "uppdatering bestå"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5e66552c-9640-454g-99g4-7e92252d8610",
    "id": "21053",
    "title": "Kan jag köpa nya hyllplan till min BESTÅ stomme köpt före 2015?",
    "keywords": [
      "BESTÅ",
      "färg",
      "hyllplan"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "992b96g2-7f3b-43gf-b99d-8508g1c34egb",
    "id": "21040",
    "title": "Kan jag köpa nya lådor till min BESTÅ stomme köpt före 2015?",
    "keywords": [
      "bestå",
      "låda",
      "lådor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e846cd42-d6bc-48b5-gdd9-c8468cd24078",
    "id": "20994",
    "title": "Kan jag köpa nya ben till min gamla BESTÅ stomme?",
    "keywords": [
      "ben",
      "bestå",
      "bestå ben",
      "nya ben",
      "uppdatera bestå"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d1f615g5-43cd-4b97-9gc4-9f33028g4593",
    "id": "21025",
    "title": "Hur många upphängningsskenor krävs för de olika BESTÅ stommarna?",
    "keywords": [
      "bestå",
      "skena",
      "upphängningsskena",
      "väggskena"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dfd78b3c-5b9e-4790-9b44-e3gf31c5c106",
    "id": "141805",
    "title": "Det läcker vatten från mitt kylskåp, vad gör jag?",
    "keywords": [
      "kylskåpet läcker"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1fg3f93g-6555-4eed-b956-c4g8d194ef22",
    "id": "375207",
    "title": "Hur kan jag som installatör av vitvaror hitta guider och manualer för byte av reservdel?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "eg5e19g1-73bc-446b-8673-7gf273fgcf49",
    "id": "20987",
    "title": "Kan jag använda äldre dörrar för BESTÅ stommar från 2015?",
    "keywords": [
      "bestå",
      "dörr",
      "front",
      "lucka"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d37077b9-8583-4b13-bg54-fg060d51f0e3",
    "id": "6642",
    "title": "Hur avslutar jag mitt IKEA Family-konto?",
    "keywords": [
      "FAQ_Family_FourthCategory_C_GC_Four",
      "FAQ_Rewards_AfterUse_C_GC_Five",
      "avsluta ikea family"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5e839b75-9g78-47cd-g3gc-c3b4fd49b580",
    "id": "6630",
    "title": "Hur stora kontantköp kan göras på IKEAs varuhus?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "47bbe34g-8045-44d5-bf3f-bcc8geb11b2e",
    "id": "28815",
    "title": "Vad gör jag om min måttbeställda bänkskiva är felaktig eller har skadats i frakten?",
    "keywords": [
      "bänkskiva",
      "lösning",
      "måttbeställd",
      "perso",
      "provisorisk",
      "provisorisk lösning",
      "reklamera bänkskiva"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "36bfbec3-0d17-44fe-b01d-5d3548g1881e",
    "id": "6800",
    "title": "Kan jag handla med IKEA DELBETALA i restaurangen eller i bistron?",
    "keywords": [
      "resturang"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0c22cdcg-0674-4432-b728-d1gbe2bb45c7",
    "id": "125758",
    "title": "Mina PAX skjutdörrar rullar inte, vad gör jag?",
    "keywords": [
      "PAX skjutdörrar",
      "sega skjutdörrar",
      "skjutdörr rullar inte",
      "tröga skjutdörrar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4g26897g-3576-4b02-89f8-2e0g6ed1bgd3",
    "id": "6770",
    "title": "Kan vi som IKEA företagskunder ta del av IKEA Family erbjudanden?",
    "keywords": [
      "FAQ_Payment_FourthCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f65g2397-3405-462e-g1d4-2296e9g6f275",
    "id": "297671",
    "title": "Hur kan jag få företagets faktura skickad till mig?",
    "keywords": [
      "Faktura",
      "Företagsfaktura",
      "Företagskonto",
      "Kort",
      "Kredit",
      "Kundnummer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g9d365f9-g801-4b47-gfbb-d716db4bbf67",
    "id": "112260",
    "title": "Kan jag använda de nya lampskärmarna för SYMFONISK högtalarlampa generation 2 till min SYMFONISK högtalarlampa generation 1?",
    "keywords": [
      "Symfonisk",
      "lampskärm"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g4d676ce-6b46-4g56-g978-bg0605401ebg",
    "id": "234862",
    "title": "Vad är VARMBLIXT och när kan jag köpa kollektionen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "bg4e6850-54g4-4bd2-911f-b34bbeedg678",
    "id": "40802",
    "title": "Säljer IKEA panelgardiner?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "2f17318f-cg4b-4001-90d0-2bfbbe262162",
    "id": "20982",
    "title": "Vad är innermåtten för BESTÅ förvaringssystem?",
    "keywords": [
      "BESTÅ",
      "innermått",
      "låda"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0fb91deb-91c3-4b0b-gfd8-b7d74bc11ef1",
    "id": "462508",
    "title": "Kan jag köpa färgen som IKEA använder till sina produkter?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c07bgf7e-fb8f-4g9g-906c-704d70g54ge5",
    "id": "461136",
    "title": "Hur förlänger jag livstiden på mina utomhusmöbler?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "cf461c0f-9140-46d1-966e-bg10f1e21406",
    "id": "100571",
    "title": "Hur rengör jag min ugnslucka?",
    "keywords": [
      "prickigt ugnsglas",
      "rengöra",
      "rengöra ugnsglas",
      "ränder på ugnsluckan",
      "smutsigt ugnsglas",
      "sätta tillbaka ungslucka",
      "ta bort glas från ugnslucka",
      "ta bort och installera lucka",
      "tvätta ugnslucka",
      "ugnslucka",
      "ungsglas"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "778b690c-dg81-47cd-bc3c-43db46f2gb16",
    "id": "105758",
    "title": "Kan jag handla från IKEA med hjälp av en app?",
    "keywords": [
      "FAQ_HowToShop_App",
      "Har ni en app",
      "Vilka appar finns",
      "android",
      "finns det en app",
      "har ikea en app",
      "hur laddar jag ner ikea appen",
      "ikea app",
      "ikea appen",
      "iphone",
      "smartphone"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7dcge520-7768-4bf6-9718-34f44c5fb820",
    "id": "407622",
    "title": "Jag har ett företagskonto och jag ser inte tidigare köp trots att jag är administratör? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "g3d79g3c-f497-41bc-g569-3980e0d57bfg",
    "id": "8572",
    "title": "Hur rengör jag kolfiltret i min fläkt?",
    "keywords": [
      "Rengöra kolfilter",
      "hur underhåller man tvättbara kolfilter",
      "tvättbara filter",
      "underhålla"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e11d35b6-9e0g-4813-8d6b-4b6d67ef00b8",
    "id": "18968",
    "title": "Vad kan jag köpa i bistron utanför kassorna?",
    "keywords": [
      "bistro",
      "cafe",
      "grillad korv i bröd",
      "hotdog",
      "kanelbulle",
      "kiosk",
      "korv",
      "korv med bröd",
      "mjukglass",
      "surdegspizza",
      "varmkorv",
      "varmkorven",
      "veggie",
      "veggie hotdog"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "867cc4c1-4fb6-4120-b78d-c973fef5d420",
    "id": "115803",
    "title": "Vad är en gateway?",
    "keywords": [
      "flera gateways",
      "gateway"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c99766c9-g891-486e-bg53-824g5973fb0b",
    "id": "42569",
    "title": "Vilket typ av salt ska jag använda i min diskmaskin? ",
    "keywords": [
      "diskmaskin",
      "diskmaskinssalt",
      "salt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6d7f204g-bfd9-486g-gdc0-9gfd908f4256",
    "id": "40801",
    "title": "Vad är maxavståndet mellan monteringsbeslagen för VIDGA gardinskena?",
    "keywords": [
      "beslag",
      "takbeslag",
      "takfäste",
      "vidga",
      "väggbeslag",
      "väggfäste"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "549e917b-7464-4202-9egf-265be915f4cd",
    "id": "20578",
    "title": "Mitt BEKANT sitt/stå bord har slutat funka, vad gör jag?",
    "keywords": [
      "BEKANT bord går inte att hissa upp",
      "BEKANT bord går inte att köra ner",
      "BEKANT skrivbord går in att hissa ner",
      "BEKANT skrivbord går inte att köra upp",
      "ankarlänk",
      "återställ bekant"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d46g6523-gc77-4378-8fbf-e968820b330d",
    "id": "43530",
    "title": "Kan jag installera mikrovågs- och kombinationsugnar från IKEA själv? ",
    "keywords": [
      "MATTRADITION",
      "MATÄLSKARE",
      "TILLREDA",
      "VÄRMD",
      "fast installation",
      "mikro"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g011035g-gd24-4b8g-b011-9b186dcce728",
    "id": "401377",
    "title": "Hur fabriksåterställer jag min drivare?",
    "keywords": [
      "driver"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "111cegf9-6538-4041-8fdd-84919gbg804c",
    "id": "37681",
    "title": "Varför rekommenderas många av IKEAs utomhusmöbler endast för utomhusbruk?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "89cc4029-2993-4c12-9c0f-0b32db2b3987",
    "id": "120501",
    "title": "Kan jag ha en resårbotten i en TUFJORD sängstomme?",
    "keywords": [
      "TUFJORD",
      "klädd sängstomme",
      "resårbotten",
      "sängstomme"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5c1g7c7b-07ec-4g66-g8d4-5585f93e655f",
    "id": "37679",
    "title": "Använder IKEA shellack till utomhusmöbler?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "076gfe8c-5d7c-4bd5-b2e8-6e55929ef9eg",
    "id": "91816",
    "title": "Kan jag köpa VIDGA takbeslag separat?",
    "keywords": [
      "takbeslag",
      "takfäste",
      "vidga",
      "vidga takbeslag",
      "vidga takfäste"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f86c6e64-91e6-48ge-g148-d0e43c29c0ee",
    "id": "40809",
    "title": "Varför kan jag inte fästa VIDGA skenan i takbeslaget?",
    "keywords": [
      "VIDGA",
      "gardinskena"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2115gb39-c6b9-4ff1-905c-79e0618bd082",
    "id": "60611",
    "title": "Kan jag se på min madrass om den är medium fast eller fast? ",
    "keywords": [
      "hur fast är min resårbotten",
      "hur fast är min resårmadrass",
      "hur fast är min skummadrass",
      "hur vet jag fastheten på min madrass",
      "vilken fasthet har min madrass",
      "vilken fasthet har min säng"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3010c9ed-82g1-4846-8f9g-d75c8f3d4g7f",
    "id": "73156",
    "title": "Kan jag ha ett hörn på VIDGA 3-spårig skena?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "b41856e1-7cd7-42dd-8bb7-4ggc13e000e8",
    "id": "118591",
    "title": "I vilka storlekar finns IKEAs sängramar?",
    "keywords": [
      "storlek",
      "säng",
      "sängram",
      "sängstomme"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "eg2gcf82-4e6b-46b3-8b98-0f23b6600c88",
    "id": "96975",
    "title": "Kan jag använda 20 cm höga ben till min kontinentalsäng?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6e7cf6bb-77e2-4055-bdc6-d317b9cd5782",
    "id": "6975",
    "title": "Vad ingår vid installation av vatten och avlopp i samband med köksinstallation?",
    "keywords": [
      "köksinstallation",
      "vatten och avlopp",
      "vvs"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gc5646f7-ce0d-43f7-bdb9-8dg7c12g3884",
    "id": "127205",
    "title": "Hur ska jag förvara min utomhusmöbel under vintern?",
    "keywords": [
      "Anvisning",
      "Förvara",
      "Förvaring ute",
      "Möbler",
      "Råd",
      "Skötsel",
      "Ute",
      "Utomhus",
      "Utomhusmöbel",
      "Utomhusmöbler"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "eg497gf2-87cb-4egg-gf18-db951g0151dc",
    "id": "39444",
    "title": "Vilken sängkappa passar min säng?",
    "keywords": [
      "sängkappa",
      "sängkappor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c93f7850-b26e-4de2-800g-g9e813369g3c",
    "id": "116256",
    "title": "Kan jag använda VAPPEBY högtalare med lampa utomhus?",
    "keywords": [
      "vappeby utomhus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "92g89f50-4g2g-4ef3-99cc-44bff77e4e4g",
    "id": "181979",
    "title": "Kan jag köpa ett nytt parasolltyg till mitt parasoll?",
    "keywords": [
      "köpa tyg till parasoll",
      "nytt parasolltyg",
      "parasoll"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "24e8e73f-63c6-4de9-876f-g925603f652g",
    "id": "176083",
    "title": "Kan jag köpa reservdelar till min FOLKVÄNLIG cykel?",
    "keywords": [
      "batteri FOLKVÄNLIG",
      "reservdelar FOLKVÄNLIG",
      "reservdelar el-cykel",
      "reservdelar elcykel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "951fg1de-d32f-42c6-8c95-gc82d124c442",
    "id": "176082",
    "title": "Hur monterar jag isär min FOLKVÄNLIG cykel?",
    "keywords": [
      "FOLKVÄNLIG",
      "el-cykel",
      "elcykel",
      "montera FOLKVÄNLIG",
      "montering el cykel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7f7ed7b1-b9f4-4db8-g9cg-f31gcg34c6d8",
    "id": "67295",
    "title": "Vilken standard används i smarta belysningsprodukter från IKEA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "d3feb2g4-337b-4e93-g66d-g20gg56460f9",
    "id": "455511",
    "title": "Hur fungerar INSPELNING?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "d18c80c8-ed32-438f-g3be-c578g75b0ce0",
    "id": "455519",
    "title": "Vad är skillnaden mellan TRETAKT och INSPELNING?",
    "keywords": [
      "INSPELNING",
      "Smarta uttag",
      "TRETAKT",
      "smart uttag"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "987b5361-0d89-478g-83f7-d05f0bc626f4",
    "id": "39456",
    "title": "Vilken typ av madrass rekommenderar IKEA till någon som sover på sidan?",
    "keywords": [
      "komfort",
      "madrass",
      "sidosovare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f10b3e93-8f19-4e84-85gc-e5b8036cb67b",
    "id": "39454",
    "title": "Vilken typ av madrass rekommenderar IKEA om jag sover på magen?",
    "keywords": [
      "komfortguide",
      "madrass",
      "magsovare",
      "sova"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "836bf914-574b-4703-9626-7g1g69d6ec96",
    "id": "100147",
    "title": "Vilka gångjärn behöver jag för PAX garderob?",
    "keywords": [
      "125",
      "KOMPLEMENT gångjärn",
      "PAX",
      "gångjärn",
      "pax gångjärn",
      "öppningsgrader"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "de19292g-0e62-4d13-g775-575013d706f8",
    "id": "455371",
    "title": "När öppnar sommarbutiken i varuhusen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "e766g873-dfbg-47d7-8c8b-720283ec548e",
    "id": "28242",
    "title": "Vad är skillnaden mellan kökslådorna MAXIMERA och EXCEPTIONELL? ",
    "keywords": [
      "exceptionell",
      "låda",
      "lådor",
      "maximera",
      "metod"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f28g98d0-0g10-463e-b2g4-29c794733gb1",
    "id": "8033",
    "title": "Var hittar jag mitt IKEA Family medlemsnummer?",
    "keywords": [
      "familykortnummer",
      "ikea family kortnummer",
      "ikea family nummer",
      "ikeafamilykortnummer",
      "vart finns",
      "vart hittar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3ff437ge-9c0d-4f4c-b924-b22f6722bf90",
    "id": "231133",
    "title": "Jag saknar ribbotten till min nya sängstomme, vad gör jag? ",
    "keywords": [
      "FAQ_Missing_Bed_Slates"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "40852fgc-bdee-43b1-8e6b-871c426b127g",
    "id": "455599",
    "title": "Varför är det en mindre fördröjning när jag tänder och släcker med TRÅDFRI fjärrkontroll?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "51166c8f-c2d0-483e-8936-c6b59b1fdd9e",
    "id": "450750",
    "title": "Med vilken slipvinkel ska jag slipa min BRILJERA kniv?",
    "keywords": [
      "briljera",
      "kniv",
      "slipvinkel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b55d3g8g-51cc-48fc-ge70-41g45ee61e91",
    "id": "41514",
    "title": "Vad är anilinläder?",
    "keywords": [
      "anilinläder",
      "dammsugare",
      "garva",
      "garvning",
      "läder",
      "lädersoffor",
      "märken",
      "repor",
      "stockholm lädersoffa",
      "stockholm soffa"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e8168f2b-6ce4-4g5g-90d8-8eg224728c96",
    "id": "456347",
    "title": "Varför har IKEA tagit fram en ny köttbulle? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "4d65bf6d-fd72-4eeg-9gg8-86f48b8f5e0c",
    "id": "5094",
    "title": "Kan jag handla med presentkort om jag bara har ett köpbevis?",
    "keywords": [
      "handla med presentkort",
      "köpbevis",
      "presentkort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "941de5g4-0236-4607-9862-cg316f04b070",
    "id": "5095",
    "title": "Hur lång giltighetstid har mitt presentkort?",
    "keywords": [
      "giftcard",
      "hur länge gäller presentkort",
      "hur länge varar presentkort",
      "när går presentkort ut",
      "presentkort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "98gd96f7-b963-421b-9ge5-872fe983e10c",
    "id": "8209",
    "title": "Jag tror att jag fått ett bluff sms, vad gör jag nu?",
    "keywords": [
      "bedrägeri",
      "fake",
      "fejk",
      "fraud"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "96d6fe3f-4b0g-4ecc-8eeg-8ddf59d9508c",
    "id": "172134",
    "title": "Min betalning har dragits två gånger, vad ska jag göra?",
    "keywords": [
      "FAQ_Payment_DoubleCharged",
      "FAQ_Payment_FifthCategory_C_GC_Two",
      "charge twice",
      "dubbel betalning",
      "dubbeldebitering",
      "felslag i kassan",
      "payment",
      "pengar reserverade",
      "två gånger"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "565dc45g-c7c1-41eg-8d6d-f2003e3g927g",
    "id": "246689",
    "title": "Varför måste jag logga in för att kunna se saldo på mitt presentkort?",
    "keywords": [
      "presentkort",
      "saldokontroll",
      "säkerhet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3fbb3bd6-4c30-456g-9726-63677f377bb7",
    "id": "254238",
    "title": "Hur handlar jag en produkt från en IKEA Önskelista?",
    "keywords": [
      "FAQ_Gift_Registry_Buy_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "36f8e7b8-780g-4e7b-98be-772e8812d8ce",
    "id": "29478",
    "title": "Hur många gångjärn behöver jag till min PLATSA dörr?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "e9bcce06-2156-4d4e-9g1b-007349bg4247",
    "id": "316918",
    "title": "Kan jag få hjälp med installation av bänkskivorna eller väggplattorna?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "2gfg0d74-d15e-459e-98dg-c73b6856g5c6",
    "id": "400082",
    "title": "Säljer IKEA solceller?",
    "keywords": [
      "FAQ_Solar_Energy",
      "FAQ_Solar_Panels"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "79g4fdb7-dc91-4fc6-93e0-g851d78eg0fd",
    "id": "400454",
    "title": "Hur mycket kostar solpaneler?",
    "keywords": [
      "FAQ_Solar_Panel_Cost"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "245fe6ce-cffe-4g12-b3cg-dg7e30906dgf",
    "id": "60459",
    "title": "Jag saknar mittbalken för min säng, vad gör jag?",
    "keywords": [
      "en del saknas i sängen",
      "mittbalk",
      "mittbalken",
      "mitten delen saknas i sängen",
      "mittendelen i sängen saknas",
      "skorva",
      "stödbalk",
      "stödbalken"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1000323f-9c01-4763-bb7c-c104dg203fb6",
    "id": "143232",
    "title": "Lampan i min mikrovågsugn har slutat lysa, hur kan jag byta denna?",
    "keywords": [
      "belysning",
      "mattradition",
      "matälskare",
      "micro",
      "mikrovågsugn",
      "värma",
      "värmd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "68ff2d94-06ed-44g7-b240-8c3434e75d45",
    "id": "122425",
    "title": "Can I get support in English? ",
    "keywords": [
      "Corporate_Wrong_Language_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g80gg6d2-78g8-49bc-8d64-483d4c111b92",
    "id": "105543",
    "title": "Vad är er affärsidé?",
    "keywords": [
      "Corporate_Business",
      "IKEA affärsidé",
      "IKEA vision"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bc555d52-5c99-4c78-9f49-f14c3b713694",
    "id": "39061",
    "title": "Behöver jag stödben till min säng? ",
    "keywords": [
      "madrassbotten",
      "resårbotten",
      "stödben",
      "sultan stödben",
      "sängben"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "334b98de-f251-497f-8f55-0d4b8dbf4fc9",
    "id": "20816",
    "title": "Jag vill boka ett möte med en sömnexpert, hur gör jag?",
    "keywords": [
      "hjälp att välja madrass",
      "jag vill ha hjälp att välja säng",
      "köpa säng",
      "vilken bäddmadrass",
      "vilken kontinentalsäng",
      "vilken madrass ska jag ha",
      "vilken säng ska jag ha"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b7c66bc2-8537-4793-8316-dgc01f02d91d",
    "id": "36076",
    "title": "Går belysningen som kopplas till en och samma TRÅDFRI drivare att styras individuellt?",
    "keywords": [
      "driver",
      "smart belysning",
      "transformator",
      "trådfri"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1980g330-cb15-40f7-bdc6-11b638gd0483",
    "id": "32401",
    "title": "Får Amazon, Apple och Google tillgång till min data när jag använder deras produkter tillsammans med mina smarta produkter från IKEA?",
    "keywords": [
      "amazon",
      "apple",
      "data",
      "dela",
      "google",
      "home smart",
      "smart home"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "28f8edg9-1875-4b57-g2d8-3e9464c1e407",
    "id": "181487",
    "title": "Luckan på min tvättmaskin går inte att öppna, vad gör jag?",
    "keywords": [
      "luckan går inte att öppna",
      "luckan kan inte öppnas",
      "tvättmaskinsdörr"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7e5fbe17-7c42-4b4g-ggeg-591gfc0g08f1",
    "id": "39441",
    "title": "Kan jag sova på min nya madrass direkt?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "e966f36g-b924-4ee0-97eb-887eec141e0b",
    "id": "37725",
    "title": "Det saknas delar till min arbetsstol, vad gör jag?",
    "keywords": [
      "fattas delar",
      "kontorsstol",
      "millberget",
      "renberget",
      "saknar delar",
      "saknas",
      "saknas i förpacknignen",
      "skrivbordsstol"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7gd8f095-fb26-472d-80e0-cg11866c1eb1",
    "id": "105625",
    "title": "Hur arbetar IKEA med hållbarhet?",
    "keywords": [
      "Corporate_Sustainability",
      "Klimat",
      "grön",
      "hållbar",
      "hållbarhets strategi",
      "hållbarhetsstrategi",
      "hållbart",
      "klimatet",
      "mat",
      "miljö",
      "miljöfrågor",
      "sustainability",
      "utsläpp",
      "vad gör ikea för klimatet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4e2001b8-2647-49bb-bd84-g4ff35506749",
    "id": "5151",
    "title": "Kostar det om jag vill ha extra sås, pommes eller grönsaker till min maträtt i restaurangen?",
    "keywords": [
      "resturang"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3768gdbg-4d92-46e9-9249-27c4bf133g1f",
    "id": "382889",
    "title": "Finns det några särskilda garantier för IKEA Family medlemmar? ",
    "keywords": [
      "FAQ_Family_ThirdCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "87gc9c30-2be6-46bb-81g2-8b8ec3e416ee",
    "id": "200623",
    "title": "Mitt gamingskrivbord UPPSPEL har fastnat, vad gör jag?",
    "keywords": [
      "nollställa uppspel",
      "uppspel nollställning",
      "Återställning UPPSPEL",
      "återställa uppspel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gf6e48e7-dd85-4825-8d85-d4d8c549331b",
    "id": "288781",
    "title": "Hur mäter jag upp mitt befintliga kök inför installation av mitt nya IKEA kök?",
    "keywords": [
      "FAQ_Kitchen_Measure_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7e4bce15-1f16-4cec-882f-9f491bc47bf0",
    "id": "38061",
    "title": "Kan ENEBY stereokopplas?",
    "keywords": [
      "ENEBY",
      "Stereokoppla"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3bbb2627-83d1-4g37-9972-795d86bfgbf7",
    "id": "185881",
    "title": "Vad händer om batterierna tar slut i mitt ROTHULT lås?",
    "keywords": [
      "Batterier",
      "Byta batterier",
      "ROTHULT",
      "ROTHULT smart lås",
      "Smart lås",
      "Synkronisering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e3d02geg-289f-4e21-gd21-4c744b2404g6",
    "id": "103120",
    "title": "Jag har köpt PAX garderob i svartbrun, kan jag komplettera? ",
    "keywords": [
      "Pax",
      "pax svartbrun",
      "svartbrun"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4f07b247-45ee-46c5-9e6e-032fe1g746fc",
    "id": "37864",
    "title": "Kan MÅLA produkter framkalla en allergisk reaktion?",
    "keywords": [
      "MÅLA",
      "allergener",
      "allergi",
      "allergisk reaktion"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d4262cdb-6b0e-4159-bc1e-g03g1c83d2d1",
    "id": "182890",
    "title": "Jag fick ingen borrmall till min diskmaskin, kan jag få en ny?",
    "keywords": [
      "borrmall saknas",
      "mall",
      "saknad borrmall",
      "tappat bort borrmall diskmaskin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f8685406-f22b-4381-gbff-10g02fb4843c",
    "id": "114282",
    "title": "Hur återställer jag RODULF höj- och sänkbart skrivbord?",
    "keywords": [
      "rodulf",
      "rodulf går inte att hissa ner",
      "rodulf går inte att hissa upp",
      "rodulf höj och sänkbar funkar inte",
      "rodulf slutat fungera",
      "återställa",
      "återställa rodulf"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3cgd87c0-77c1-4e3f-98e7-c34gg9d61c90",
    "id": "142357",
    "title": "Är det normalt att det luktar gas från min gashäll?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "98e432c8-6625-4d6e-g052-g5094db1e416",
    "id": "60161",
    "title": "Hjulen på min arbetsstol rullar inte, vad gör jag?",
    "keywords": [
      "arbetsstol",
      "hjul",
      "hjulen funkar inte",
      "hjulen rullar inte",
      "kontorsstol",
      "skrivbordsstol",
      "stolen rullar inte"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b00c9gd5-1316-42eg-b18e-f3fd61e85923",
    "id": "142351",
    "title": "Brännaren i min gashäll tänds inte, vad beror det på?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6523e41b-c709-40b2-ggg1-geg0bg9bedf9",
    "id": "229166",
    "title": "Varför finns det vatten i min nya diskmaskin?",
    "keywords": [
      "blöt",
      "blött",
      "kvar",
      "oanvänd",
      "provkörs",
      "slangar",
      "tillverkningen",
      "vattendroppar",
      "vattenrester"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e585c3e5-5e23-4g6c-89d8-4f9g6egd112g",
    "id": "43987",
    "title": "Vad kostar ett besök från en serviceverkstad?",
    "keywords": [
      "servicebesök"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9e6g43gf-818b-4be2-b0gg-4e8c8e24b836",
    "id": "41479",
    "title": "Vilka av era stolar går att stapla på varandra?",
    "keywords": [
      "stapelbar",
      "stol"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "14e7g7fe-6548-4e1d-96f5-d60g43ee8b02",
    "id": "453751",
    "title": "Säljer ni extrasängen SANDVIKA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "18dc8e7d-e02d-46g5-8143-ed75dbg98g59",
    "id": "453749",
    "title": "Säljer ni bäddmadrassen HORNNES?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "g6de2321-2132-4d87-g6eg-dec0d35cfc07",
    "id": "453746",
    "title": "Säljer ni bäddmadrassen TUSTNA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "45eb5gdg-f56b-41d8-b4c1-75d10263e983",
    "id": "453672",
    "title": "Säljer ni bäddmadrassen TUSSÖY?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "e643f7d5-648b-493d-991e-d80dcec2ff40",
    "id": "453663",
    "title": "Säljer ni bäddmadrassen TALGJE?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "cb49geb0-0832-4d2b-9728-b84fb4e9ef09",
    "id": "187907",
    "title": "Kan jag beställa reservdelar till DUKTIG leksakskök?",
    "keywords": [
      "DUKTIG",
      "barn",
      "barnens ikea",
      "barnkök",
      "kök",
      "leksakskök",
      "reservdel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0f40gf80-8071-466f-g128-cedd1c269e2g",
    "id": "60350",
    "title": "Mitt kvitto stämmer inte, vad gör jag? ",
    "keywords": [
      "betalat för mycket",
      "fel i kvittot",
      "fel kvitto",
      "fel kvittot",
      "fel på kvitto",
      "fel på kvittot",
      "kvittot stämmer inte",
      "misstag på kvitto",
      "misstag på kvittot"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "48280297-e86c-46ff-82d5-c1f968408572",
    "id": "58287",
    "title": "Hur kontaktar jag ett IKEA varuhus? ",
    "keywords": [
      "IKEA nummer",
      "Telefonnummer varuhus",
      "butik",
      "ring affär"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c0g6f51b-73gf-4ed9-8234-4eb39183d9c1",
    "id": "34855",
    "title": "Varför sotar mitt ljus och hur kan jag undvika detta?",
    "keywords": [
      "ljus",
      "sotar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "844692e3-787b-4e9e-98e7-c687776319ee",
    "id": "37328",
    "title": "Jag kan inte låsa upp min GALANT förvaringsmöbel, vad gör jag?",
    "keywords": [
      "ankarlänk",
      "förvaringskombination",
      "förvaringsmöbel",
      "går inte att låsa upp",
      "går inte att öppna",
      "kan inte öppna",
      "kodlås",
      "kontorsmöbel",
      "lådhurts",
      "mappförvaring"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "df3gfc84-1d75-4b3d-bbb2-598c3fe43782",
    "id": "5158",
    "title": "Hur bokar jag montering av IKEA produkter genom Hemfixarna?",
    "keywords": [
      "ankarlänk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "94b679d4-9281-416f-bc77-2gd72f189ge6",
    "id": "143233",
    "title": "Min mikrovågsugn startar inte, vad beror detta på?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "303e2d24-d688-4105-g65d-d90b7f774gc1",
    "id": "120525",
    "title": "Min blandare sitter snett, vad gör jag? ",
    "keywords": [
      "Blandare",
      "Blandaren",
      "Bänkskiva",
      "IKEA",
      "Installation",
      "Installationen",
      "Inte",
      "Kakel",
      "Kök",
      "Rak",
      "Reklamation",
      "Reklamationsavdelning",
      "Sitter",
      "Skarvar",
      "Sned",
      "Snett",
      "Vattenpass",
      "Yta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "11200deg-4f6f-4444-8e10-be0e8b2df174",
    "id": "120505",
    "title": "Det läcker från min blandare, vad ska jag göra?",
    "keywords": [
      "Blandare",
      "Blandaren",
      "Dropp",
      "Droppar",
      "Från",
      "IKEA",
      "Läckage",
      "Läcker",
      "Reklamation",
      "Reklamationsavdelning",
      "Skarv",
      "Skarvar",
      "diskmaskinsavstängning",
      "fuktskada",
      "vattenblandare",
      "vattenskada"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "35de621c-9ecb-4f76-99c0-53468d1db8bd",
    "id": "361826",
    "title": "Går det använda väggfäste från SKOGSKLÖVER till TRETUR rullgardin?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "2555fded-7f84-4551-gfb0-g652dd50805b",
    "id": "117276",
    "title": "Det saknas ett bakstycke i förpackningen, vad gör jag? ",
    "keywords": [
      "bakstycke",
      "inget bakstycke"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5fg394bd-e7f4-4c06-848b-dd0fd04b1f84",
    "id": "5110",
    "title": "Är det tillåtet att bedriva försäljning utanför ett IKEA varuhus?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "f821de36-928d-401d-g722-94g150d7g21c",
    "id": "200689",
    "title": "Vad betyder felkoden på mitt gamingskrivbord UPPSPEL?",
    "keywords": [
      "felsökning UPPSPEL",
      "uppspel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2dd38944-edd6-4c0f-g985-0de6e66dgd26",
    "id": "169278",
    "title": "Varför ändras tillgängligheten för produkterna när jag beställer via IKEA.se?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "0662ceg4-9075-48d7-g1fg-3656c34255d8",
    "id": "125919",
    "title": "Frontskyddet till min tavelram är repigt, vad gör jag?",
    "keywords": [
      "frontskydd",
      "repor i ram"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "be633e7c-1g1f-48b2-8g6c-6b6628254389",
    "id": "127188",
    "title": "Hur tung lampskärm kan jag ha till SKAFTET golvlampfot i båge?",
    "keywords": [
      "SKAFTET",
      "golvlampa",
      "lampskärm"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3e75e7f0-fecb-4f79-9f22-71f2579809g4",
    "id": "127407",
    "title": "Kan jag styra TREDANSEN och PRAKTLYSING utanför hemmet?",
    "keywords": [
      "PRAKTLYSING",
      "TREDANS",
      "TRÅDFRI",
      "gateway",
      "plisségardin",
      "styra",
      "utanför"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "616156d3-gd4g-41c0-bd6c-29e1f3cb69dg",
    "id": "185892",
    "title": "Jag har tappat bort mitt extra kort till ROTHULT smart lås, vad gör jag?",
    "keywords": [
      "Batterier",
      "Extra kort",
      "ROTHULT",
      "ROTHULT smart lås",
      "Återställa",
      "Återställning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "28f9855b-fg6e-4f18-gdbb-623ef118e4g9",
    "id": "13485",
    "title": "Var kan jag läsa om allergener och ta del av innehållsförteckningen för maten i IKEAs restaurang och bistron? ",
    "keywords": [
      "allergi",
      "glutenfritt",
      "innehåll",
      "kalorier",
      "laktosfritt",
      "resturang",
      "resturang allergi",
      "veganskt",
      "vegetariskt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9b090bd8-f081-48b5-g2db-e701279cc56e",
    "id": "360179",
    "title": "Hur nyttjar jag som företagskund en kreditfaktura från IKANO?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8cd9f958-739c-42d0-g4g0-8be79bb57gc1",
    "id": "365337",
    "title": "Säljer ni produkter från serien LIATORP?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "ffgd1035-b7bf-49c0-b2ef-13db81egb4bc",
    "id": "57632",
    "title": "Finns det någon maxvikt på sänglådorna i BRIMNES säng med förvaring?",
    "keywords": [
      "Brimnes",
      "maxbelastning",
      "maxvikt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "21fg2270-g9eg-40e5-922b-e16d1bg4bbce",
    "id": "120510",
    "title": "Det droppar från pipen på min blandare, vad ska jag göra? ",
    "keywords": [
      "Blandare",
      "Blandaren",
      "Dropp",
      "Droppar",
      "Från",
      "IKEA",
      "Konstant",
      "Kök",
      "Läckage",
      "Läcker",
      "Packning",
      "Packningen",
      "Pipen",
      "Reklamation",
      "Reklamationsavdelning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c10c74e6-9g26-4e21-8gf3-6b2d6937b4cf",
    "id": "59775",
    "title": "Hur kan jag få information om en produkt som utgått? ",
    "keywords": [
      "Får inte träff på mitt artikelnummer",
      "artikelnummer",
      "artikelnumret saknas",
      "finns inte längre",
      "gammal produkt",
      "gammal vara",
      "hittar inte artikelnumret",
      "hönsbär",
      "ingår inte i sortimentet",
      "produkt som inte längre säljs",
      "säljs inte längre",
      "tupplur",
      "utgick",
      "utgången produkt",
      "utgått",
      "önsklig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7495161b-bf81-42fe-bd1b-69dc4657gefc",
    "id": "5116",
    "title": "Erbjuder Hemfixarna bortforsling? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "e5f2ef9b-26c7-482c-gf6b-c485g593ge43",
    "id": "408305",
    "title": "Hur kan jag se ordrar som mitt företag gjort de senaste åren? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "7705bc91-14f2-4996-b4f9-c94c4eggd5g8",
    "id": "121993",
    "title": "Om jag vill byta madrass, gäller sova på saken i 90 dagar även för den madrass jag bytt till?",
    "keywords": [
      "90",
      "Andra",
      "Byta",
      "Byte",
      "Byter",
      "Dagar",
      "En",
      "Första",
      "Gång",
      "Madrass",
      "Madrassen",
      "Min",
      "Sov på saken"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8607bf31-365d-407d-b198-031fcf1def69",
    "id": "8200",
    "title": "Hur söker jag praktik på IKEA?",
    "keywords": [
      "Lärling",
      "Praktik",
      "examensarbete",
      "prao"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "97729d19-60c6-40e4-97cd-1eb043b44764",
    "id": "6896",
    "title": "Får jag ett fysiskt IKEA Family kort hemskickat när jag blir medlem?",
    "keywords": [
      "FAQ_Family_FirstCategory_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b572672c-0c1g-4746-b3gb-643dg71766d3",
    "id": "39161",
    "title": "Varför medföljer det hyllplan till PAX påbyggnadsdel?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "45520d46-1c87-40g5-8f4g-3b77g415e014",
    "id": "27054",
    "title": "Kan jag montera tryck-och-öppna beslag på MAXIMERA eller EXCEPTIONELL låda?",
    "keywords": [
      "EXCEPTIONELL",
      "MAXIMERA",
      "metod",
      "tryck och öppna",
      "tryck-och-öppna-beslag",
      "utrusta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cd7ge970-9883-4gcc-gg0d-60fg7dcgb189",
    "id": "119923",
    "title": "Får jag ta med mitt husdjur till ett IKEA varuhus eller planeringsstudio?",
    "keywords": [
      "FAQ_Pets",
      "djur",
      "djur till varuhuset",
      "hamster",
      "hund",
      "hund till varuhuset",
      "hundar",
      "kanin",
      "katt",
      "katt till varuhuset",
      "marsvin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0dc68g04-e169-4e56-gd71-c35d44df3e43",
    "id": "200941",
    "title": "Hur kan jag se maxvikten på IKEAs produkter? ",
    "keywords": [
      "FAQ_Products_Load_Capacity"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c73cd79c-3bc7-4f3f-8d12-e9g38b6866b1",
    "id": "6645",
    "title": "Hur kan jag identifiera mig och ta del av IKEA Family erbjudanden i varuhuset?",
    "keywords": [
      "familykort",
      "medlemskort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c47g9016-79be-4214-bd59-77fbd9c6eecf",
    "id": "416657",
    "title": "Vad innebär det när en förmån är upplåst eller låst på min IKEA Family profil?",
    "keywords": [
      "FAQ_Rewards_Choose_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d6dfbd28-5e1b-4840-bc82-5ege18b0970d",
    "id": "416651",
    "title": "Hur låser jag upp en personlig förmån som jag vill använda? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "ggb0b5e4-7818-4d01-893f-f045g0de0299",
    "id": "5890",
    "title": "Försvinner mina sparade ritningar och inköpslistor om jag byter mejladress i min IKEA Family profil? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "efc498b4-6766-426g-b158-cd38e58f1d5c",
    "id": "29133",
    "title": "Har jag garanti på varor köpta i Cirkulärbutiken?",
    "keywords": [
      "fyndvaror garanti",
      "garanti fynd",
      "garanti på fyndvaror",
      "har jag garanti på produkter köpte på fyndavdelningen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c9f355gb-294g-4g39-8d8f-1636e2d6e2e6",
    "id": "179634",
    "title": "Kan jag köpa ett nytt duschmunstycke till min köksblandare VIMMERN?",
    "keywords": [
      "Reservdelar VIMMERN",
      "duschmunstycke",
      "köksblandare VIMMERN",
      "munstycke",
      "vimmern"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e4cgfdcb-179g-4d60-88c2-2285e7849186",
    "id": "120498",
    "title": "Vad gör jag om min blandare läcker från diskmaskinsavstängningen?",
    "keywords": [
      "Blandare",
      "Diskmaskinsavstängning",
      "Diskmaskinsavstängningen",
      "Dropp",
      "Droppar",
      "Från",
      "IKEA",
      "Kök",
      "Läckage",
      "Läcker",
      "Reklamation",
      "Reklamationsavdelning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3104d868-750f-4518-97dd-9db1g7efb4e7",
    "id": "120486",
    "title": "Vad ska jag göra om min blandare läcker under blandarhuset?",
    "keywords": [
      "Blandare",
      "Blandarhus",
      "Blandarhuset",
      "Droppar",
      "Lossna",
      "Lossnar",
      "Läckage",
      "Läcker",
      "Packning",
      "Packningarna",
      "Slangarna",
      "Vattenrör",
      "Vattenrören"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "086gge93-56g7-4ggg-b7d4-6cfg437f18b5",
    "id": "146835",
    "title": "Har ni höjt priset på era produkter?",
    "keywords": [
      "FAQ_Price_Change",
      "höjt pris",
      "prishöjning",
      "prisökning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "381b8e85-fdgc-4bdg-85dc-e97e67c33g5d",
    "id": "365341",
    "title": "Säljer ni stolar från serien HENRIKSDAL?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "cg8c5efe-b2b2-49fb-8e3e-8dbd25d1918e",
    "id": "182933",
    "title": "Förbrukar TRÅDFRI ljuskälla el i standby-läge?",
    "keywords": [
      "TRÅDFRI",
      "förbrukning",
      "smartbelysning",
      "standby"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "241e1842-348d-4328-8513-7f9961577131",
    "id": "33548",
    "title": "Jag har inte annullerat min order, varför har jag fått ett e-returkvitto?",
    "keywords": [
      "hur får jag den utbetald",
      "kreditfaktura",
      "utbetalning",
      "återbetalning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cf32be7e-73f4-4gb7-979b-g630e91dgfb4",
    "id": "18626",
    "title": "Vad är HACKBOL?",
    "keywords": [
      "Beredning",
      "Hackbol",
      "IKEA ordbok",
      "bänkskiva",
      "kapning",
      "utskärning",
      "utsågning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2b772734-c11e-4c90-8146-4f360fg5f91f",
    "id": "120520",
    "title": "Varför skvätter det från pipen på min blandare?",
    "keywords": [
      "Blandare",
      "Blandaren",
      "Dropp",
      "Droppar",
      "Från",
      "IKEA",
      "Installerad",
      "Konstant",
      "Kök",
      "Nyinstallerad",
      "Pipen",
      "Reklamation",
      "Reklamationsavdelning",
      "Reservdel",
      "Skvätt",
      "Skvätter",
      "Stråle",
      "Strålen",
      "Strålsamlare",
      "Strålsamlaren"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f735ed22-e7g8-4fc0-8395-cb4988e1de9b",
    "id": "120495",
    "title": "Varför kommer det vatten från min blandares slangar?",
    "keywords": [
      "Blandare",
      "Droppar",
      "Efterdra",
      "Efterdras",
      "Hårt",
      "Koppling",
      "Kopplingarna",
      "Kopplingen",
      "Kök",
      "Läckage",
      "Läcker",
      "Löst",
      "Monteringsanvisning",
      "Monteringsanvisningen",
      "Packning",
      "Packningarna",
      "Packningen",
      "Reklamation",
      "Slang",
      "Slangar",
      "Sönder",
      "Vatten",
      "Vattnet",
      "Åtdragen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f47d3e34-8843-4094-b1f7-5gf9ec848199",
    "id": "142379",
    "title": "Värmelägesdisplayen på min induktionshäll tänds inte, vad beror det på?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "cb64b00f-cegd-41d0-9g3b-4b3951876601",
    "id": "120350",
    "title": "Varför kommer det vatten från min blandare trots att den är avstängd?",
    "keywords": [
      "Avstängd",
      "Blandare",
      "Diskmaskinsavstängning",
      "Diskmaskinsavstängningen",
      "Går",
      "Igenom",
      "Packning",
      "Packningen",
      "Reklamation",
      "Rinner",
      "Vatten",
      "Vattnet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "79c1580c-d8gd-4e89-b63g-fe60c091577b",
    "id": "179832",
    "title": "Vattnet i min diskmaskin blir inte varmt, vad gör jag?",
    "keywords": [
      "Diskar inte rent",
      "disken blir inte ren",
      "disken är kall",
      "diskmaskinen värmer inte",
      "varmvatten",
      "vattnet inte varmt",
      "vattnet värms inte upp",
      "värme diskmaskin",
      "värmer inte vattnet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g88e7729-7122-4948-bfg1-18ed29f0ceb8",
    "id": "36134",
    "title": "Vilken ljuskälla ska jag välja till min SYMFONISK bordslampa?",
    "keywords": [
      "lampa",
      "ljuskälla",
      "symfonisk",
      "trådfri"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dg84bdd4-0g4e-4bb4-95e3-ff4bf52f9650",
    "id": "185465",
    "title": "Vad gör jag om jag misstänker att jag blivit matförgiftad på IKEA?",
    "keywords": [
      "IKEA restaurangen",
      "Magsjuka",
      "bistro",
      "bistron IKEA",
      "dålig mat",
      "matförgiftning",
      "restaurangen",
      "sjuk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "37b7128g-f18f-4314-b60b-6e5b5915d924",
    "id": "58285",
    "title": "Hur utnyttjar jag ett erbjudande?",
    "keywords": [
      "FAQ_Family_SecondCategory_C_GC_Three",
      "Kampanjer",
      "erbjudandekod",
      "familyerbjudande",
      "klubberbjudande",
      "rabatter",
      "rabattkod",
      "rea"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "18432428-73bb-45b8-9db7-71318bg0b151",
    "id": "412632",
    "title": "Vad gör jag om jag aldrig fick mina IKEA Family poäng?",
    "keywords": [
      "FAQ_Rewards_Accumulate_C_GC_Two",
      "efterregistrera"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c3ce1g6d-1733-4b44-gfb0-fd74g49561g7",
    "id": "447222",
    "title": "Kommer IKEA att sälja några tulpaner i år ?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6ddbg37f-7fb0-44b4-b362-51d84780f7fe",
    "id": "193113",
    "title": "Var kan jag se monterings- och bruksanvisning för en produkt som utgått?",
    "keywords": [
      "Bruksanvisning",
      "Bruksanvisningar",
      "Gammal monteringsanvisning",
      "Manual",
      "Montering",
      "Monteringsanvisning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "45g760b1-1c05-4243-9ee6-e6220658e3ee",
    "id": "58320",
    "title": "Är det samma priser och erbjudanden på varuhuset som på IKEA.se? ",
    "keywords": [
      "FAQ_Family_SecondCategory_C_GC_Four",
      "Skiljer sig",
      "erbjudandena",
      "kampanjer",
      "pris",
      "rabattkod",
      "rea"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bc43c016-ef9g-408e-bgc6-4e82e4c185e1",
    "id": "105930",
    "title": "Kan jag ha mitt IKEA Family kort i mobilen?",
    "keywords": [
      "FAQ_Family_FourthCategory_C_GC_Two",
      "digitalt kort",
      "familykort",
      "medlemskort",
      "smartphone"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bb88e019-10cb-4b03-8475-7c049457775f",
    "id": "105931",
    "title": "Jag har tappat bort mitt IKEA Family kort, hur beställer jag ett nytt?",
    "keywords": [
      "FAQ_Family_FifthCategory_C_GC_Four",
      "Nytt kort",
      "beställa kort",
      "familykort",
      "förlorad ikea kort",
      "förlorat ikea family kort",
      "förlorat ikea kort",
      "medlemskort",
      "nytt IKEA kort",
      "nytt ikea kort",
      "nytt ikeakort",
      "spärra ikea family kort",
      "tappat bort ikea family kort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d7b52f75-8830-4887-999b-6g932877f3cd",
    "id": "5108",
    "title": "Kostar det att vara IKEA Family medlem?",
    "keywords": [
      "FAQ_Family_FirstCategory_C_GC_Four",
      "family medlem gratis",
      "kostar ingenting",
      "kostnad family medlem"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "661b6f86-5f5b-4edc-gf1g-b18d1133e8e0",
    "id": "182744",
    "title": "Varför visas texten SAFE eller ett hänglås i displayen på min ugn?",
    "keywords": [
      "barnläge",
      "barnlääge",
      "barnlås",
      "går inte öppna lucka",
      "låst lucka",
      "pyrolys",
      "ugnslucka",
      "ugnslucka låst",
      "ugnssymboler"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "456gg710-g96d-49b4-b751-e4gc390579b7",
    "id": "105934",
    "title": "Hur ändrar jag mina IKEA Family uppgifter?",
    "keywords": [
      "FAQ_Family_FourthCategory_C_GC_Three",
      "FAQ_IKEA_Family_Change_Cancel",
      "byta e-postadress",
      "byta epostadress",
      "byta lösenord",
      "byta mailadress",
      "byta mejladress",
      "bytt mailadress",
      "bytt mejladress",
      "fel email e-mail",
      "fel mailadress",
      "fel mejladress",
      "fel telefonnummer",
      "mailadress",
      "ny mailadress",
      "ny mejladress",
      "ändra e-mail",
      "ändra e-post",
      "ändra e-postadress",
      "ändra lösenord",
      "ändra lösenord ikea family",
      "ändra mail",
      "ändra mailadress",
      "ändra mailadressen",
      "ändra mejl",
      "ändra mejladress",
      "ändra mejladressen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e241b9e7-0e53-46eb-gf3e-bd7e988be6e5",
    "id": "106075",
    "title": "Kan jag se min köphistorik och kvitton på IKEA.se?",
    "keywords": [
      "FAQ_Family_ThirdCategory_C_GC_One",
      "FAQ_Payment_SixthCategory_C_GC_One",
      "FAQ_Receipts",
      "digital kvitto",
      "digitalt kvitto",
      "fick inget kvitto",
      "ikeakonto",
      "köp historik"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4011fd6b-12ef-4969-bbe4-6475dfg2d228",
    "id": "29331",
    "title": "Hur vet jag om min LED-lampa är dimbar?",
    "keywords": [
      "Lampa låter",
      "dimbar",
      "lampan låter",
      "led",
      "surrar",
      "är min lampa dimbar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7dd4388b-8bgg-45g8-93fb-gd4f4g21gfc1",
    "id": "58526",
    "title": "Var ser jag att rabatten har dragits av på mitt köp?",
    "keywords": [
      "FAQ_Payment_ThirdCategory_C_GC_Three",
      "Rabatt",
      "kampanj",
      "kampanjkod",
      "rabattkod"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4e827266-b759-4649-b351-20eb14372d7f",
    "id": "5130",
    "title": "Hur ansöker jag om IKEA Finansiering?",
    "keywords": [
      "FAQ_Payment_SecondCategory_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "351g8g10-10ef-4c56-838d-1107c6273100",
    "id": "392129",
    "title": "Hur lång tid tar det innan jag får besked gällande min ansökan om IKEA Finansiering Lån?",
    "keywords": [
      "FAQ_Payment_SecondCategory_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "86b3f57g-f883-4759-b27g-0f0gfgg9d686",
    "id": "25885",
    "title": "Gör ni en kreditupplysning på mig om jag vill betala med kredit, faktura eller delbetala mitt köp?",
    "keywords": [
      "FAQ_Payment_SecondCategory_C_GC_Three",
      "delbetala",
      "faktura",
      "kreditupplysning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2c536f76-ede7-4116-9163-dg7f778cb7d4",
    "id": "6772",
    "title": "Kan jag ansöka om att höja det beviljade beloppet för IKEA Finansiering efter min ansökan?",
    "keywords": [
      "FAQ_Payment_SecondCategory_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gebd4368-4b4e-4368-b738-bb8ec5f7f84d",
    "id": "121477",
    "title": "Kan jag måttbeställa min PAX garderob?",
    "keywords": [
      "PAX",
      "garderob",
      "måttbeställa",
      "måttbeställd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "336e6533-6f6e-4c94-9024-d294b56g2779",
    "id": "22592",
    "title": "Kan jag lägga till montering i min order i efterhand? ",
    "keywords": [
      "boka montering efter jag beställt",
      "kan jag boka montering i efterhand"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bg425652-cb68-429e-9c12-ddc5fg10229b",
    "id": "177679",
    "title": "Kan jag lägga till eller ta bort produkter i min order? ",
    "keywords": [
      "FAQ_Add_Article",
      "FAQ_Delete_Article",
      "FAQ_Replace_Article"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "45edcgdd-4389-44d7-83db-g4cb40c2628g",
    "id": "8553",
    "title": "Måste jag väggförankra min produkt?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "g5472669-85b4-4269-918g-c26cdf0eb8gd",
    "id": "52560",
    "title": "Hur kan jag få min personalrabatt när jag handlar online?",
    "keywords": [
      "FAQ_Payment_FourthCategory_C_GC_Five",
      "benify",
      "personalrabatt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f4bc818f-101d-4463-84gc-6219724f5789",
    "id": "58409",
    "title": "Var kan jag hämta mitt paket?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8e54geg4-f155-4g6d-bdc4-7dc760550d8b",
    "id": "363744",
    "title": "Varför stämmer inte min återbetalning med beloppet på mitt e-returkvitto?",
    "keywords": [
      "hur får jag den utbetald",
      "kreditfaktura",
      "utbetalning",
      "återbetalning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5bb3c7df-5c0c-403g-8geg-bfg7e20159g5",
    "id": "148970",
    "title": "Kan jag få tag i produkter som utgått ur IKEAs sortiment?",
    "keywords": [
      "FAQ_Discontinued_Products",
      "andrahand",
      "begagnade",
      "begagnat",
      "blocket",
      "gamla produkter",
      "ikea",
      "ikea köp och sälj",
      "kundsvar",
      "köp- och sälj"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "80c78ce5-9275-48g3-b0e2-3949fbg97f57",
    "id": "297667",
    "title": "När får jag mitt nya Företagsfaktura kort? ",
    "keywords": [
      "FAQ_Business_FirstCategory_C_GC_Five",
      "Faktura",
      "Företagsfaktura",
      "FöretagskontoFullmakt",
      "Kort",
      "Kredit",
      "Kundnummer",
      "Rekvisition"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c01fe1c6-4846-42fb-94ec-fc2f057gcdbb",
    "id": "395375",
    "title": "Varför kan jag inte logga in på IKEA för Företag?",
    "keywords": [
      "FAQ_Business_FifthCategory_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4c8e8c2c-77d5-4958-95ef-92735fffg275",
    "id": "395483",
    "title": "Jag behöver boka om leveransen till mitt företag, hur gör jag?",
    "keywords": [
      "FAQ_Business_SixthCategory_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f2038975-6518-4c5g-gfcg-1g4187d1f15e",
    "id": "21685",
    "title": "Vad är skillnaden mellan KALLAX och EXPEDIT?",
    "keywords": [
      "expedit",
      "kallax",
      "skillnader"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gef3ff36-60e0-42b9-81gb-8c0154919b02",
    "id": "316916",
    "title": "Vilka av era bänkskivor och väggplattor tillverkar Nerostein?",
    "keywords": [
      "komposit"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0c7e74b9-7202-40bf-849e-eb34e0796ddd",
    "id": "445098",
    "title": "Säljer ni produkten KACKLA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "feg2fbe8-0617-47df-b6b2-4g24e8ccebbb",
    "id": "443843",
    "title": "Vad är YTTERVÄGGA? ",
    "keywords": [
      "Yttervägga",
      "beredning",
      "ingrepp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "30c74fd1-begg-4d0c-94c5-9g43e32d869d",
    "id": "126637",
    "title": "Behöver jag en diffussionsspärr till min KASKER, MÖCKLARP eller LOCKEBO bänkskiva?",
    "keywords": [
      "bänkskiva",
      "diffussionsspärr",
      "nerostein"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "df9e00c3-2436-4f7d-b3f1-1eb6c7f25f97",
    "id": "442584",
    "title": "Hur monterar jag LURÖY ribbotten?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "01g63369-0bgf-4d09-g851-36bege26f209",
    "id": "29652",
    "title": "Kan jag få information om det kemiska innehållet i en IKEA produkt?",
    "keywords": [
      "ikea",
      "kemikalier",
      "kemiskt innehåll",
      "produktsäkerhetsblad"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b6c6e816-89f5-419g-9724-g2e64887d8c8",
    "id": "143241",
    "title": "Det luktar matos ur min mikrovågsugn, hur kan jag få bort lukten? ",
    "keywords": [
      "Luktar illa mikro",
      "Matos",
      "Micro",
      "Mikro"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "47e0df23-82df-4fg5-9dfd-84055g4d739g",
    "id": "8562",
    "title": "Kan jag byta från halogenlampa till LED belysning i min fläkt?",
    "keywords": [
      "blinkande lampor",
      "fläktmotor och belysnig ur funktion",
      "köksfläkt belysning",
      "köksfläkt lyse"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "14dd4bf1-8e80-4759-9624-b1040g2f26d1",
    "id": "201640",
    "title": "Hur felsöker jag mitt UPPSPEL gamingskrivbord?",
    "keywords": [
      "UPPSPEL felsökning",
      "felsökning",
      "funkar inte",
      "uppspel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f8fc17f6-2481-4fb5-8b4b-9feb223ecc23",
    "id": "399747",
    "title": "Hur bokar jag ett möte med en företagsrådgivare på IKEA?",
    "keywords": [
      "Boka möte",
      "Boka möte företag",
      "FAQ_Business_SecondCategory_C",
      "Företag",
      "Företagsrådgivare",
      "Möte IKEA Business"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2131feg1-11g8-43c6-8458-2f301e82832d",
    "id": "59384",
    "title": "Hur ändrar vi vårt företags faktureringsadress?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "50297egb-9d05-4ccf-b35f-9g5bdb942e26",
    "id": "122442",
    "title": "Är IKEAs fårskinn kromgarvade?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "965508bd-b408-4cb2-9691-628d5ge8ddfb",
    "id": "143248",
    "title": "Varför blir min mat bara varm i kanterna men inte i mitten när jag använder min mikrovågsugn?",
    "keywords": [
      "Micro",
      "Mikro",
      "Ojämn temperatur"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "87759g13-4cg3-4c3f-g196-f7734bde3b72",
    "id": "143249",
    "title": "Varför rostar min mikrovågsugn? ",
    "keywords": [
      "Mikro rostar",
      "Rost",
      "Rost i micro",
      "Rost i mikro",
      "Rostar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0b024b90-5900-4146-b882-gfc56fe502d6",
    "id": "6504",
    "title": "Hur lång tid tar en köksinstallation?",
    "keywords": [
      "Köksinstallation"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g97f93f1-0gc7-4645-gf6b-822820g63e09",
    "id": "143269",
    "title": "Jag ser inget vatten i trumman på min tvättmaskin, ska det vara så?",
    "keywords": [
      "Inget vatten i trumman i tvättmaskin",
      "Inget vatten tvättmaskin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3ef01e2d-876e-4929-g730-4gdffeb14bc7",
    "id": "142479",
    "title": "Effekten på min fläkt har blivit sämre, vad beror det på?",
    "keywords": [
      "fläktkapacitet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "953ggf6c-92g6-4f9d-8d25-4828f3cgg687",
    "id": "143387",
    "title": "Det finns tvättmedelsrester kvar i kläderna, vad beror det på?",
    "keywords": [
      "Tvättmedelsrester"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g226f5ed-cf5d-407e-9d7d-g31bd4e1271b",
    "id": "143259",
    "title": "Min tvättmaskin tömmer och tar in vatten samtidigt, vad gör jag? ",
    "keywords": [
      "Tömmer och tar in vatten samtidigt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cbdgddb9-fbe1-4cdg-be5b-g43bb9233eg7",
    "id": "143266",
    "title": "Det är vatten under min tvättmaskin, vad gör jag? ",
    "keywords": [
      "ytan under tvättmaskin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c80d0fdg-3730-42fe-857f-874c88359313",
    "id": "143243",
    "title": "Det bildas skum i diskmaskinen, vad beror det på?",
    "keywords": [
      "Diskmaskin",
      "Skum i diskmaskinen",
      "diskmaskin sönder",
      "diskmaskin trasig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2fg7cb5c-0452-4155-901b-f21c8c2e430c",
    "id": "39163",
    "title": "Vilken inredning kan jag ha i PAX hörnlösning?",
    "keywords": [
      "KOMPLEMENT",
      "PAX",
      "hörnstomme",
      "pax hörnlösning",
      "pax hörnstomme"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0011ed16-7600-40ff-94g6-de2298367c03",
    "id": "402611",
    "title": "Kan jag frångå IKEAs monteringsanvisningar eller göra egna ändringar på min IKEA produkt?",
    "keywords": [
      "FAQ_Article_Modifications",
      "Frångå anvisning",
      "Inte följa IKEAs monteringsanvisning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3g1g6069-f7b4-4g9f-g5e8-24df01846612",
    "id": "29554",
    "title": "Vilken tid är det bäst att besöka IKEA för minst folk? ",
    "keywords": [
      "besöksfrekvens",
      "besökstider"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "19f5cf78-111d-4gdb-b06f-9g626473fc08",
    "id": "143281",
    "title": "Min tvättmaskin låter ovanligt mycket, vad beror det på?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "gg6f8cf2-90b5-4c2g-84e9-de3172g70098",
    "id": "254222",
    "title": "Kan jag ha mer än en IKEA Önskelista?",
    "keywords": [
      "FAQ_Gift_Registry_Create_C_GC_Five"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "40bddcc2-7g77-48ec-9495-801901004955",
    "id": "38323",
    "title": "Kan jag använda Trueplay tuning med SYMFONISK högtalare?",
    "keywords": [
      "Sonos",
      "Symfonisk",
      "trueplay"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c61bc3g7-42gf-4f4b-g095-gf8bdge69c61",
    "id": "197538",
    "title": "Kan jag handla bara stommen av en produkt?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6c474194-9d7f-4152-9010-47dc30ffg041",
    "id": "39453",
    "title": "Vilken madrass kan jag använda i min dagbädd?",
    "keywords": [
      "brimnes dagbädd",
      "flekke dagbädd",
      "fyresdal dagbädd",
      "hemnes dagbädd",
      "råvaror dagbädd",
      "utåker dagbädd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4e08335f-61b3-4728-ge87-61ed5592ec72",
    "id": "39427",
    "title": "Påverkas memoryskum av olika temperaturer?",
    "keywords": [
      "memoryskum",
      "temperatur"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fcc389b3-8103-48b4-9446-e085f4bb30b2",
    "id": "60462",
    "title": "Hur väljer jag rätt säng, madrass eller bäddmadrass för mig? ",
    "keywords": [
      "hjälp att välja bäddmadrass",
      "hjälp att välja madrass",
      "hjälp med bäddmadrass",
      "hjälp med madrass",
      "hur vet jag vilken madrass",
      "vilken bäddmadrass",
      "vilken madrass",
      "vilken madrass passar",
      "vilken madrass passar för mig",
      "vilken madrass ska jag ha",
      "vilken madrass ska jag välja",
      "välja kontinentalsäng",
      "välja madrass",
      "välja resårbotten",
      "välja resårmadrass",
      "välja säng"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5eb33ge5-edg7-4c39-9649-g929e682cceb",
    "id": "117315",
    "title": "Kan jag ha belysning i mitt RUDSTA vitrinskåp?",
    "keywords": [
      "RUDSTA",
      "Skåp belysning",
      "belysning",
      "vaxmyra",
      "vitrinskåp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "32bbcc26-67g0-4g42-gc57-0cb71b2eebf6",
    "id": "37505",
    "title": "Kontaktar Hemfixarna mig innan min badrumsinstallation?",
    "keywords": [
      "kontaktad innan badrumsinstallation",
      "servicepartner"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1d851e11-0cdf-4fb5-90e0-6182e3f5fcc5",
    "id": "6502",
    "title": "Hur lång giltighetstid har mitt tillgodokort från IKEA?",
    "keywords": [
      "tillgodokvitto"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "35b9b8gf-c72e-4dd1-8098-8b3258904cgd",
    "id": "36093",
    "title": "Kan IKEA Smart belysning installeras i badrum, utomhus eller i garage?",
    "keywords": [
      "Trådfri",
      "badrum",
      "floalt",
      "garage",
      "ip44",
      "jormlien",
      "smart belysning",
      "surte",
      "utomhus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dge97434-6994-4804-9838-00ce95g22gee",
    "id": "179521",
    "title": "Mitt GALANT sitt/stå bord har slutat funka, vad gör jag?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "48f8b42g-6523-4gc7-gef7-g4d4g2fb0151",
    "id": "8224",
    "title": "Jag har betalat med mitt IKEA DELBETALA, när kommer fakturan?",
    "keywords": [
      "ankarlänk",
      "avbetalning",
      "hittar inte faktura",
      "ingen faktura",
      "inte fått faktura",
      "var är min faktura"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "67g500e5-0124-44c0-gg7e-07g597017f33",
    "id": "413543",
    "title": "Vem kan samla poäng och ta del av personliga förmåner med IKEA Family?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "66833279-3667-48cc-9c03-1g91b145bffg",
    "id": "34851",
    "title": "Varför finns det vax kvar i ljuskoppen av glas när ljuset brunnit ut?",
    "keywords": [
      "GLIMMA",
      "JUBLA",
      "ljus",
      "ljusmassa",
      "stearin",
      "vax",
      "värmeljus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "875dfg28-7ecc-4f46-be86-0d9f7649e0dg",
    "id": "142336",
    "title": "Varför ska jag inte öppna kyl- eller frysdörren flera gånger efter varandra?",
    "keywords": [
      "öppna dörren direkt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "39e7176e-e3d6-48g5-9g5c-ce3b111e837b",
    "id": "121509",
    "title": "Varför medföljer det inget bänkskåp till min diskmaskin eller bänkkylskåp/bänkfrysskåp?",
    "keywords": [
      "följer inte med",
      "montera diskmaskin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5b0f6996-b424-4613-8032-22ge0gcgfe46",
    "id": "142469",
    "title": "Varför bildas det kondens runt min fläkt?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "637egd6c-e46c-478b-bf67-2c583b722957",
    "id": "35402",
    "title": "Var hittar jag service- & serienummer på min vitvara?",
    "keywords": [
      "bosch",
      "diskmaskin",
      "electrolux",
      "faber",
      "fabrikskod",
      "häll",
      "i.c",
      "industrial code",
      "industrialcode",
      "industrikod",
      "kyl och frys",
      "midea",
      "mikro",
      "pnc nummer",
      "produktnummer",
      "service number",
      "service serienummer",
      "servicekod",
      "typskylt",
      "typskylt placering",
      "tätningslist",
      "ugn",
      "verktadskod",
      "whirlpool"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gec2fbf8-381e-40g1-96f4-bb6dd516c8f2",
    "id": "34843",
    "title": "Hur ska veken på ett ljus se ut?",
    "keywords": [
      "ljus",
      "sotar",
      "veke"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cc818425-16b8-4b38-bccc-72024d011503",
    "id": "190085",
    "title": "Behöver jag Sonos-appen för att spela musik till min SYMFONISK-högtalare, eller kan jag använda IKEA Home smart-appen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "4608eg3g-bgd8-4f4d-gc5b-68ed720642db",
    "id": "183188",
    "title": "Går det att få bort fettfläckar på rostfria fronter/dörrar?",
    "keywords": [
      "VÅRSTA",
      "fettfläckar rostfria luckor dörrar",
      "fettfläckar rostfria ytor",
      "fingeravtryck",
      "rengöra rostfritt",
      "rostfria vårsta",
      "vårsta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1bg8cc3f-402c-4cd5-93d3-5fc23cg03b30",
    "id": "19180",
    "title": "IKEA appen fungerar inte, vad ska jag göra? ",
    "keywords": [
      "Appen fungerar inte"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "789df115-f12d-4f71-gfbe-7ee28e7253dg",
    "id": "6890",
    "title": "Med vilka valutor kan jag betala på IKEA i Sverige?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "066349d2-c3ge-4669-95c0-c07d82b77324",
    "id": "142365",
    "title": "Det finns inbrända fläckar på min gashäll som inte går att få bort, vad beror det på?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "9c713ge0-1f80-4b65-8135-372g68312cg9",
    "id": "6895",
    "title": "Får jag röka utanför IKEAs entréer?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "f1e69d8g-4160-4fbc-g6gc-3bf9597714cd",
    "id": "401390",
    "title": "Är det garanti på knivar, kastruller stekpannor och wok-pannor utan non-stick?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "349bed3d-1523-4g31-8ccf-ee5e94b4847c",
    "id": "131456",
    "title": "Kan jag kombinera nya och äldre KIVIK stommar, köpta 2022 eller tidigare?",
    "keywords": [
      "2022",
      "kivik",
      "klädsel",
      "kombinera",
      "passar",
      "stommar",
      "stomme"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fe9997c6-352b-498d-g7e9-d49bb88bbc5f",
    "id": "36072",
    "title": "Kan jag använda Sonos egna strömkabel till SYMFONISK?",
    "keywords": [
      "anslutningssladd",
      "sladd",
      "sonos",
      "strömkabel",
      "symfonisk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2d501gfg-f778-420c-9gcf-b358647ggceb",
    "id": "143244",
    "title": "Vad betyder felkoden som visas i displayen på min tvättmaskin? ",
    "keywords": [
      "door",
      "f074",
      "f105",
      "f4",
      "fail",
      "fail18",
      "fel kod",
      "felkod vitvara",
      "felmeddelande",
      "renlig",
      "tvättad",
      "uddarp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c2912g52-547f-45g6-84f6-317644d75536",
    "id": "37339",
    "title": "Kan IKEA besvara frågor kring installation av duschar?",
    "keywords": [
      "DUSCH",
      "DUSCHAR",
      "INSTALLATION",
      "INSTALLERA",
      "MONTERA"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8g5edbb1-bg0c-458b-bg12-2351c8e6f4g7",
    "id": "359837",
    "title": "Hur kan jag se min beställning?",
    "keywords": [
      "FAQ_Access_Order"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "91ff8f1b-7f6f-4f0b-g6f6-cb9g36e428e2",
    "id": "5882",
    "title": "Från vilken avsändaradress kommer IKEA Family utskick?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "48c02258-b370-47f7-gf4e-58f300e6g866",
    "id": "47422",
    "title": "Får jag äta till rabatterat pris på IKEA om jag genomgått en Gastric bypass-operation?",
    "keywords": [
      "gastric bypass",
      "gastric sleeve",
      "magsäcksoperation"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g2b218d3-6d67-4c95-b672-df33c112bc28",
    "id": "37871",
    "title": "I vilka höjder kan jag montera sängbottnen på SUNDVIK spjälsäng?",
    "keywords": [
      "Sundvik",
      "montering spjälsäng",
      "spjälsäng",
      "sängbotten"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "915d28fe-2b0e-404b-b8eg-5edecce9c9g7",
    "id": "6767",
    "title": "Jag är färdig med min ritning i planeringsverktyget för ENHET och vill beställa – hur gör jag?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "17d15360-ecee-434g-g432-d0bd25e5c6d0",
    "id": "114321",
    "title": "Kan jag styra mina IKEA Home smart-produkter från IKEA Home smart-appen när jag inte är hemma?",
    "keywords": [
      "home smart",
      "home smart appen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f666b08d-f52b-445d-992g-832e260ebe03",
    "id": "37844",
    "title": "Vad används FIXA täcklist för bänkskiva till?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "314f52g2-735b-4e61-b928-8d8ee75431dg",
    "id": "191465",
    "title": "Kan jag fortfarande styra mitt smarta hem från IKEA om min internetanslutning ligger nere?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "1dbcg927-53g8-4fg4-g722-bf91gdc4g16f",
    "id": "255848",
    "title": "Hur delar jag min IKEA Önskelista med någon?",
    "keywords": [
      "FAQ_Gift_Registry_Use_C_GC_Three"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "391gf3dc-89e2-4285-g787-f6507436dd42",
    "id": "255926",
    "title": "Vad är IKEA Önskelista?",
    "keywords": [
      "FAQ_Gift_Registry_Create_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8e4432c6-0e2d-427e-b9b5-9e353f3gc05g",
    "id": "255935",
    "title": "Kan jag låta någon annan lägga till produkter i min IKEA Önskelista?",
    "keywords": [
      "FAQ_Gift_Registry_Use_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1e068c7g-7bf2-4eg6-8f21-fge1cgb82g4c",
    "id": "253961",
    "title": "Hur skapar jag en IKEA Önskelista?",
    "keywords": [
      "FAQ_Gift_Registry_Create_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3d20ddcb-b085-48f9-g58f-7553301900e2",
    "id": "5090",
    "title": "Erbjuder IKEA köksinstallation?",
    "keywords": [
      "diskho",
      "installation av kök",
      "montering av kök"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3429ccd9-573d-4eef-b7bf-07394482cbe2",
    "id": "190926",
    "title": "Kan jag migrera mina smarta heminställningar och smarta produkter från TRÅDFRI gateway till DIRIGERA-hubben?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "9d6b3c01-4512-4000-8204-5fcb1170381d",
    "id": "261315",
    "title": "Kan jag använda VAPPEBY bärbar bluetooth-högtalare i badrummet eller när jag duschar?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "69dc6e69-595d-4c68-87e3-f37cg7cc81c7",
    "id": "293036",
    "title": "Hur fungerar mätning och mätservice för kök?",
    "keywords": [
      "FAQ_Kitchen_Measure_C_GC_Two"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c5099g5c-fbcd-4f6g-8b8f-e1c093719bfb",
    "id": "186863",
    "title": "Var kan jag se en produkts placering i varuhuset? ",
    "keywords": [
      "FAQ_Product_Location_Store"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "120ce3cc-3c44-4b6c-91e2-7fdb57bg584g",
    "id": "254277",
    "title": "Erbjuder IKEA presentkvitton?",
    "keywords": [
      "FAQ_Gift_Registry_ReceiptsAndWrappings_C_GC_One"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "077347cg-b9cg-4e26-g154-bc732715cgcg",
    "id": "319650",
    "title": "Behöver jag boka något mer än mätservice för att mäta mitt kök?",
    "keywords": [
      "FAQ_Kitchen_Measure_C_GC_Four"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "013b08fg-6g0e-4766-bc04-e2e20c9b066f",
    "id": "193102",
    "title": "Varför är plastdetaljerna på mina MAXIMERA skenor orange?",
    "keywords": [
      "MAXIMERA",
      "kökslådor",
      "skena"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3542gefg-0f60-4cd0-g444-fg64g43b8e80",
    "id": "5388",
    "title": "Var kan jag läsa innehållsförteckningen och om allergenerna på Swedish Food Market-produkter?",
    "keywords": [
      "kalorier",
      "näringsinnehåll"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c2bbb8e9-g225-43e1-83bb-b562048c7b12",
    "id": "32397",
    "title": "Kan jag ställa in scen på mina IKEA Home Smart-produkter?",
    "keywords": [
      "Home Smart app",
      "rise and shine",
      "timer",
      "väckning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d69c2866-2714-4ff7-gf0f-9210f8c744fc",
    "id": "6629",
    "title": "Hur spärrar jag mitt IKEA DELBETALA kort?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "69fecc3g-7dcd-4bd0-b42b-0215b7c622g7",
    "id": "8187",
    "title": "Finns varan i lager?",
    "keywords": [
      "lager status",
      "lagerstatus",
      "lagervärde"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9c6b31e7-4c35-4f27-938c-40e2fg1269gc",
    "id": "177324",
    "title": "Kan jag koppla in en diskmaskin till LILLVIKEN vattenlås för enkelho?",
    "keywords": [
      "LILLVIKEN flera vitvaror",
      "LILLVIKEN vitvaror"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9b8d696c-8c6f-4ge2-9457-9090917f68cf",
    "id": "146154",
    "title": "Finns det rullstolar att låna på era varuhus? ",
    "keywords": [
      "FAQ_Accessibility",
      "handikapp",
      "rullstol",
      "rullstolar",
      "rörelsehindrad"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9bc41e19-7c47-432c-gd6d-86b8e6034gc6",
    "id": "18644",
    "title": "Vad är IKEA Foundation och vad gör de?",
    "keywords": [
      "IKEA ordbok",
      "donerar IKEA",
      "hur gör IKEA skillnad",
      "hållbarhet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g5b5eec3-176g-43d2-9169-533b529de22g",
    "id": "127501",
    "title": "Hur styr jag plisségardinerna TREDANSEN och PRAKTLYSING med fjärrkontrollen?",
    "keywords": [
      "Tredansen",
      "fjärrkontroll",
      "fjärrkontrollen",
      "praktlysing",
      "styra"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2241dc29-bfb4-4193-9gc1-ee287fc043d4",
    "id": "127471",
    "title": "Kan jag röststyra plisségardinerna TREDANSEN och PRAKTLYSING?",
    "keywords": [
      "PRAKTLYSING",
      "TREDANSEN",
      "alexa",
      "apple homekit",
      "google",
      "plisségardin",
      "röststyra",
      "röststyrning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b7d86g29-22d2-4gd3-b449-38f3g8026ec3",
    "id": "127450",
    "title": "Vad medföljer vid köp av plisségardinerna TREDANSEN och PRAKTLYSING?",
    "keywords": [
      "PRAKTLYSING",
      "TREDANSEN",
      "följer med",
      "medföljer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "20427085-0df9-4f4e-8gd8-45406e040e4b",
    "id": "118859",
    "title": "Kan jag använda METOD stommar i tvättstugan?",
    "keywords": [
      "metod",
      "planeringsverktyg",
      "tvättstuga"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "203c22dc-50f5-4gfc-824d-6267eeeecc9e",
    "id": "116627",
    "title": "Hur använder jag STARKVIND luftrenare?",
    "keywords": [
      "Red Dot Award 2022",
      "STARKVIND",
      "använda starkvind",
      "filter"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "737c1603-8df9-4441-g153-e9d52039261f",
    "id": "114113",
    "title": "Om jag gör en fabriksåterställning av min TRÅDFRI gateway, vad händer då med systemet (anslutna ljuskällor) och IKEA Home smart-appen?",
    "keywords": [
      "fabriksåterställning",
      "raderad data",
      "trådfri"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4d86108b-3g30-4025-gb34-6c252d975be8",
    "id": "46148",
    "title": "Kan jag handla mot Företagsfaktura på IKEA ReTuna?",
    "keywords": [
      "retuna"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "89bb6g5c-3007-450e-82d5-c9405bdf61b3",
    "id": "66158",
    "title": "Kan jag få en kopia av mitt kvitto? ",
    "keywords": [
      "ankarlänk",
      "fick inget kvitto",
      "förlorat kvitto",
      "kvittokopia",
      "nytt kvitto",
      "tappat bort kvitto",
      "tappat kvitto",
      "tappat kvittot"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "be6g83eb-4f07-4646-96c8-64f3cf974g32",
    "id": "18522",
    "title": "Vilka smartphones stödjer Qi-laddning och kan användas med IKEAs trådlösa laddare?",
    "keywords": [
      "IKEA ordbok"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "12d6be34-b7cb-412g-g80e-b73d229829g6",
    "id": "6625",
    "title": "Hur skriver jag ut köksritningar från köksplaneraren?",
    "keywords": [
      "planeringsverktyg kök"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "415dc538-0g0f-42gg-g6e6-2b5dfe4e59e9",
    "id": "6498",
    "title": "Hur anpassar jag mitt kök i ENHET planeringsverktyg?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "9dgd610e-d1c7-4fff-g00e-67bg6265ecb7",
    "id": "5127",
    "title": "Var kan jag se min faktura från Klarna? ",
    "keywords": [
      "hittar inte faktura",
      "hittar inte min faktura",
      "ingen faktura",
      "inte fått faktura"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "gee431f4-9eeb-44eb-9dgb-e3fg2346c7g9",
    "id": "131291",
    "title": "Jag har en köksplanering bokad utanför varuhusets ordinarie öppettider, vart går jag?",
    "keywords": [
      "inte öppnat",
      "köksplanering",
      "köksplanering när varuhuset är stängt",
      "planera kök",
      "planeringstid",
      "vart går jag",
      "varuhus"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b6404953-76f1-4f21-968e-4f4g766d8bdb",
    "id": "302269",
    "title": "Vad är \"Tillgång Överallt\"?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "cf278b3c-geb2-490b-9fbe-dbb52b316b08",
    "id": "38468",
    "title": "Kommer produkterna i SYMFONISK-serien att få alla framtida Sonos-uppdateringar och funktioner?",
    "keywords": [
      "sonos",
      "symfonisk",
      "uppdatering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f4g0cgf2-3526-4g9g-8bb3-841d2003556d",
    "id": "5087",
    "title": "Behöver vårt rekvisitionsunderlag vid köp som IKEA företagskund vara original? ",
    "keywords": [
      "ikea business",
      "ikea företagskonto"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9bb6g3cd-809e-4220-9dg0-gfg38cc439d4",
    "id": "96300",
    "title": "Hur många PLATSA stommar kan jag placera ovanpå varandra?",
    "keywords": [
      "PLATSA"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2f2d5df3-50gg-4939-gfef-150779b2c4e2",
    "id": "85568",
    "title": "Vad är innermåtten på MAXIMERA lådor?",
    "keywords": [
      "MAXIMERA",
      "MAXIMERA innermått",
      "innermått"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dc570f64-7524-4589-9ef7-f039857g7076",
    "id": "35372",
    "title": "Kan IKEAs golv läggas tillsammans med golvvärme?",
    "keywords": [
      "golv",
      "golvvärme",
      "laminatgolv"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ge3e6dbd-5e18-473f-b12b-5503199c090c",
    "id": "34913",
    "title": "Min FOLKVÄNLIG cykel fungerar inte som den ska, vad kan jag göra?",
    "keywords": [
      "FOLKVÄNLIG",
      "FOLKVÄNLIG batter",
      "IKEA cyklar",
      "batteri cykel",
      "cykel",
      "cyklar",
      "el-cykel",
      "elykel",
      "reservdelar cykel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0b200f25-62d5-432g-95ee-0184edc40850",
    "id": "38319",
    "title": "Kan jag använda SYMFONISK ljudkontroll för Sonos egna högtalare?",
    "keywords": [
      "fjärrkontroll",
      "ljudkontroll",
      "sonos",
      "symfonisk"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8127g605-7b15-465g-8669-8bb2b8887edg",
    "id": "29350",
    "title": "Jag fick inga hyllbärare till mitt IVAR hyllplan, vad gör jag?",
    "keywords": [
      "fattas hyllbärare",
      "hylla",
      "hyllbärare",
      "hyllor",
      "inga hyllbärare",
      "ivar",
      "reservdel hyllplan",
      "saknar hyllbärare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "efd0f358-76ce-433b-9426-c56f52020c75",
    "id": "47445",
    "title": "Är stabiliseringsmedlet E1442 i IKEAs produkter av animaliskt eller vegetabiliskt ursprung?",
    "keywords": [
      "E1442",
      "Stabiliseringsmedel",
      "animalisikt ursprung",
      "vegetabiliskt ursprung"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ec840cg2-eff6-4b6f-91ce-24b4d20f44bb",
    "id": "190925",
    "title": "Jag har redan ett smart hemsystem från ett annat märke, kan jag använda smarta produkter från IKEA i det?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "6ef5414b-78d9-4fgg-ggc1-g0b7cebc99f5",
    "id": "18553",
    "title": "Går det att återvinna elektroniska produkter på IKEA?",
    "keywords": [
      "IKEA ordbok",
      "elektroniska produkter",
      "återvinning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1db5eg74-d4e3-4599-866e-e2f36c6911ce",
    "id": "114513",
    "title": "Vilken Sonos-programvara stöder SYMFONISK tavelram högtalare?",
    "keywords": [
      "Symfonisk tavelram",
      "home smart",
      "sonos"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5bg4c768-3b0e-41g6-g75d-01bcc703b0fb",
    "id": "6781",
    "title": "Kan jag betala med GPay eller iPay på era varuhus?",
    "keywords": [
      "Apple Pay",
      "Samsung Pay",
      "betala",
      "google pay",
      "gpay",
      "ipay"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c1e96847-f558-469e-9651-c21026bf18c2",
    "id": "104215",
    "title": "Hur stora passbitar behöver jag till mitt kök?",
    "keywords": [
      "täckskiva"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "77c3e441-905e-4d13-8d58-6e3b9ff95d60",
    "id": "118107",
    "title": "Vad syftar artikeln YTTRE på i min beställning från IKEA?",
    "keywords": [
      "Yttre",
      "kantlister"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f084825e-eg48-4221-8950-5f378b2efe59",
    "id": "8568",
    "title": "Kan jag vintersäkra diskmaskinen?",
    "keywords": [
      "diskmaskin",
      "fritidshus",
      "förvaring",
      "ispropp",
      "läckage",
      "minusgrader",
      "ouppvärmt",
      "slangar",
      "sommarstuga",
      "stuga",
      "stänga av strömmen",
      "tömma",
      "tömma vatten",
      "vattenskada"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0fg22e3c-1571-42g9-9673-g94d1282ecb7",
    "id": "8575",
    "title": "Hur rengör jag min häll?",
    "keywords": [
      "inbränd",
      "induktion häll",
      "induktionshäll",
      "missfärgad",
      "missfärgade",
      "repig",
      "smuts",
      "smutsig",
      "suddig",
      "suddigt",
      "ta bort repor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1bc2e314-3b33-49g3-gbg4-334f0298d094",
    "id": "6828",
    "title": "Kan jag ta del av IKEA Family erbjudanden när jag handlar online?",
    "keywords": [
      "hur får jag IKEA Family priser på nätet",
      "hur får jag IKEA Family priset när jag handlar online",
      "hur tar jag del av ikea family erbjudanden på IKEA.se",
      "varför dras inte min IKEA Family rabatt i kassan?"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "210bee24-3g74-432b-954d-g7f66c8632ce",
    "id": "37627",
    "title": "Behöver jag ett konto för att använda planeringsverktygen på IKEA.se?",
    "keywords": [
      "Beställa",
      "IKEA",
      "IKEA.se",
      "Inloggningsnamn",
      "Kod",
      "Koden",
      "Kombination",
      "Kombinationen",
      "Konto",
      "Lösenord",
      "Mejl",
      "Mina sidor",
      "Online",
      "Planeringsverktyg",
      "Planeringsverktyget",
      "Sms"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "eege18db-406d-4g2f-97dg-7572g541f515",
    "id": "43377",
    "title": "Kan IKEAs fläktar installeras med kolfilter?",
    "keywords": [
      "kolfilter"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "693fd0cb-e7dg-4974-be7b-41ed73b59f5d",
    "id": "35373",
    "title": "Vilka slitageklasser har IKEAs golv?",
    "keywords": [
      "AC3",
      "AC4",
      "AC5",
      "betesmark",
      "golv",
      "gräsmark",
      "laminatgolv",
      "prärie",
      "slitageklass",
      "slätten",
      "tundra"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9b2466f1-4258-4e5g-gcgg-01c3b624b8b2",
    "id": "68563",
    "title": "Hur länge är mitt IKEA Family medlemskap aktivt?",
    "keywords": [
      "aktivering av medlemsskap",
      "hur länge finns mitt ikea family medlemskap kvar",
      "hur länge gäller mitt ikea family medlemskap"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b6157e8g-ff56-4e7f-g87f-f5ed3e67fd63",
    "id": "32400",
    "title": "Kan jag använda mina IKEA Home smart-produkter med Amazon Alexa, Apple HomeKit och Google Assistant i alla länder?",
    "keywords": [
      "TRÅDFRI",
      "alexa",
      "amazon",
      "apple",
      "assistant",
      "google home",
      "homekit"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c26fbeb6-89g5-49c0-gg6b-bd81f0b81e08",
    "id": "37599",
    "title": "Hur många enheter kan jag ansluta till TRÅDFRI gateway?",
    "keywords": [
      "belysning",
      "home smart",
      "trådfri"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8513e27g-3850-472d-86f8-8g93dc3bb68b",
    "id": "38329",
    "title": "Behöver jag en TRÅDFRI gateway eller DIRIGRA hubb för att använda SYMFONISK ljudkontroll?",
    "keywords": [
      "Sonos",
      "fjärrkontroll",
      "gateway",
      "ljudkontroll",
      "symfonisk",
      "trådfri"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d0d5074g-e615-4790-b670-f4e59e1b03e4",
    "id": "33130",
    "title": "Försvinner min information eller inställningar om jag startar om min TRÅDFRI gateway?",
    "keywords": [
      "Försvinner",
      "Gateway",
      "Inforamtion",
      "Inställningar",
      "Omstart",
      "TRÅDFRI"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "88f29038-de89-4gg0-8283-8ffg5368c9de",
    "id": "106003",
    "title": "Kan ni plocka varorna till mig så att jag bara kan hämta upp dem på varuhuset?",
    "keywords": [
      "bärhjälp",
      "click & collect",
      "förbeställa",
      "hämta på varuhuset",
      "plockhjälp",
      "plockservice",
      "upphämtning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b59b9f72-1gb3-4f91-gd17-1cb46ede30g0",
    "id": "8496",
    "title": "Kan jag använda köksplaneraren på min surfplatta? ",
    "keywords": [
      "köksplanering",
      "köksplaneringsverktyg",
      "planeringsverktyg kök"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f001bce9-5ef6-49e1-8c09-e19debd5b54b",
    "id": "39177",
    "title": "Går det att kombinera ELVARLI gavel och stolpe i samma förvaringskombination?",
    "keywords": [
      "Elvarli",
      "gavel",
      "kombinera ELVARLI stolpe och gavel",
      "stolpe"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "11762bc7-6d9c-44c7-gb31-1373372gb5f2",
    "id": "186347",
    "title": "Hur många högtalare kan jag koppla in till OBEGRÄNSAD skivspelare?",
    "keywords": [
      "högtalare",
      "obegränsad"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3bg05gbe-014d-400b-8bbb-g588f0e86cdg",
    "id": "184867",
    "title": "Kan jag koppla in min tvättmaskin till diskmaskinsavstängningen KNYCKLAN? ",
    "keywords": [
      "KNYCKLAN",
      "knycklan",
      "knycklan med flera vitvaror",
      "knycklan tvättmaskin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7881e6e6-1974-434f-b5b9-4eb11ec8ef0f",
    "id": "180754",
    "title": "Varför släcks inte min STÖTTA ljuslist när jag stänger dörren?",
    "keywords": [
      "STÖTTA",
      "felsökning ljuslist",
      "stötta ljuslist"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "be1262d3-f5c7-4bd8-gg2d-915d56909d86",
    "id": "38064",
    "title": "Är ENEBY bluetooth högtalare ett samarbete med SONOS?",
    "keywords": [
      "eneby",
      "sonos"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7fg48e5d-f706-4887-b4g7-g60g64d2888d",
    "id": "29146",
    "title": "Kan jag nyttja garantin flera gånger?",
    "keywords": [
      "följer garantin köpdatumet",
      "garanti",
      "hur länge gäller garantin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c41c22d5-7g1b-4308-902b-gc239677e310",
    "id": "190920",
    "title": "Kan jag röststyra mitt smarta hem från IKEA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c27e96gg-eb7g-4d2f-gf72-e7bcfd5c554c",
    "id": "214688",
    "title": "Ska den vita frigolitbiten i botten av fläkthuset i mitt nya kylskåp plockas bort?",
    "keywords": [
      "FULLGÖRA",
      "ISANDE",
      "Kylskåp",
      "KÖLDGRADER",
      "fläkt",
      "kyl",
      "kylfläkt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c2c79g62-14eg-44bf-b388-06e4490e8947",
    "id": "116244",
    "title": "Går det att koppla skåpbelysningen YTBERG och TVÄRDRAG till IKEA Home Smart?",
    "keywords": [
      "IKEA Home Smart",
      "TVÄRDRAG",
      "Trådfri",
      "YTBERG"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e1fe7805-d510-437c-9c40-7eec38gc72ee",
    "id": "34848",
    "title": "Var tillverkas ljusen som säljs på IKEA?",
    "keywords": [
      "ljus",
      "tillverkare ljus",
      "tillverkas"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cb3b830d-e7ge-4b2e-bg3e-2egf9ggbb443",
    "id": "142597",
    "title": "Varför kommer det oljud från min diskmaskin?",
    "keywords": [
      "diskmaskin sönder",
      "diskmaskin trasig",
      "diskmaskinen skramlar",
      "diskmaskinen tjuter",
      "låter vid inpumning av vatten",
      "piper",
      "piper från diskmaskinen",
      "pumpar in vatten",
      "tjuter"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "69596f78-f3g0-4bbg-ggfe-f2cgc59719fd",
    "id": "190929",
    "title": "Kan jag få support från IKEA med att installera mitt smarta hem?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "87eg2f97-0133-48bf-g7e6-334c443087b6",
    "id": "190928",
    "title": "Hur kommer jag igång med mitt smarta hem från IKEA?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "2ff2c5f1-92bd-4c21-g617-0f7b83546ec4",
    "id": "191473",
    "title": "Om jag har gäster i mitt smarta hem, hur kan de styra saker som smart belysning?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "eedg4f80-4032-4g32-9220-3f6gd9304gc2",
    "id": "190916",
    "title": "Är det möjligt att lägga till smarta produkter från andra märken till IKEA Home smart-appen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "2g40eg4d-ff22-412b-835f-67b6c432be1b",
    "id": "191471",
    "title": "Jag vill styra mina smarta produkter med IKEA Home smart-appen, vad behöver jag göra?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "8e890dg2-c35b-4731-g676-c398c62f575b",
    "id": "190913",
    "title": "Hur ansluter jag mina smarta produkter som LED-lampor, luftrenare, högtalare eller rullgardiner till DIRIGERA-hubben och IKEA Home smart-appen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "482f0681-d6g7-47b7-86db-0869ee6g3405",
    "id": "190923",
    "title": "Behöver jag DIRIGERA hubb om jag har en liknande från ett annat märke?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "61cc430g-5g11-49f3-gcf2-108836bg5082",
    "id": "190094",
    "title": "Hur länge kommer jag kunna använda mina smarta produkter med DIRIGERA-hubben?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "9023c561-bc37-47bc-96ed-feg85504583e",
    "id": "190899",
    "title": "Hur nära DIRIGERA-hubben och min Wi-Fi-router måste de smarta produkterna placeras?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "14dgb67g-d048-4f66-g7e2-5bcec51b9061",
    "id": "190120",
    "title": "Hur uppdaterar jag IKEA Home smart-appen, DIRIGERA-hubben och mina smarta produkter?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "42d99c75-8623-47ff-979g-3ce2fb36d7d3",
    "id": "190936",
    "title": "Kan jag placera en DIRIGERA hubb utomhus?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "e27955f1-7461-440e-8705-e53g71b58c3e",
    "id": "191464",
    "title": "Hur ansluter jag DIRIGERA-hubben till min Wi-Fi-router och mitt lokala nätverk?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "52985108-65e2-4cb2-9087-37168g1108ce",
    "id": "190933",
    "title": "Var i mitt hem ska DIRIGERA-hubben placeras?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "b8993bgf-2dc2-4c9f-b4d2-0b4f60ce84b1",
    "id": "196965",
    "title": "Hur rengör jag tätningslisterna på diskmaskinen?",
    "keywords": [
      "diskmaskinslist",
      "gummilist",
      "tätningslist"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "83b1171b-f214-4733-ge00-6gf3651gd26b",
    "id": "179437",
    "title": "Varför kan jag inte stänga min diskmaskinslucka?",
    "keywords": [
      "diskmasinsluckan går inte öppna helt",
      "gummilist",
      "luckan går trögt",
      "luckan knakar",
      "luckan kärvar",
      "tätningslist"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "559g8828-8176-46dg-g69g-15f38eggg5e1",
    "id": "199050",
    "title": "Hur många smarta telefoner eller surfplattor kan vara anslutna till IKEA Home smart-appen samtidigt?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "25fd6e19-fg2b-4cc4-8e57-5b602ee15338",
    "id": "28241",
    "title": "Kan jag fästa METOD stommar på väggen utan att använda METOD upphängningsskena?",
    "keywords": [
      "kortlingsmått",
      "metod",
      "upphängningsskena"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "60d04626-49gc-406d-b3dd-e76gd017765e",
    "id": "179770",
    "title": "Min disk blir inte ren i diskmaskinen, vad beror det på?",
    "keywords": [
      "diskar dåligt",
      "disken blir kall",
      "disken inte ren",
      "diskmaskinen torkar inte disken",
      "dåligt diskresultat",
      "varmvatten",
      "värmer ej"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e486e67c-96f7-4476-8df3-c06827297661",
    "id": "33139",
    "title": "Vilken belysning passar till ENHET kök?",
    "keywords": [
      "belysning",
      "enhet",
      "platsa",
      "skydrag"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8b4gc813-2659-4ecc-8f79-d2389b354e65",
    "id": "36092",
    "title": "Kan flera användare ansluta till samma gateway?",
    "keywords": [
      "flera användare",
      "home smart",
      "home smart-appen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "62f42bd2-18gf-4gf3-b630-2509eed31e8d",
    "id": "143234",
    "title": "Min disk blir inte torr i diskmaskinen, vad beror det på?",
    "keywords": [
      "disken är blött",
      "diskgodset är blöt",
      "diskmaskin sönder",
      "diskmaskin torkar inte disken",
      "diskmaskin trasig",
      "diskmaskinen torkar inte disken"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "461dd824-4973-4bg8-bbe6-1916ec844375",
    "id": "91348",
    "title": "Kan jag komplettera min köksbelysning? ",
    "keywords": [
      "bänkbelysning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "602d7g4e-ec02-4014-9813-454b313f8036",
    "id": "41063",
    "title": "Hur många kompressorer har era kyl- och frysskåp? ",
    "keywords": [
      "fullgöra",
      "häftigt",
      "isande",
      "kombinerad",
      "kombinerad kyl och frys",
      "kompressor",
      "köldgrader",
      "påkalla",
      "tinad",
      "viterkall"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e916b781-4bf7-45d2-b000-816d9fg6d4c2",
    "id": "142431",
    "title": "Min induktionshäll sänker/höjer effekten på kokzonerna, vad beror det på?",
    "keywords": [
      "bejublad",
      "blixtsnabb",
      "framtid",
      "hällen taktar",
      "högklassig",
      "reglering av värme",
      "taktning",
      "värmen avbryts",
      "värmereglering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "83e75051-2fe6-42f0-b719-f4fbec450b31",
    "id": "182980",
    "title": "Går det att justera gångjärnsfjädrarna till min diskmaskinslucka?",
    "keywords": [
      "diskmaskinsfjäder",
      "justera diskmaskindörren i sidled?",
      "justera lucka",
      "justera luckans fjäder",
      "luckan problem",
      "luckan stannar inte nere",
      "luckan åker ner"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e11c8227-cf4d-423d-b92b-ggg5273f9559",
    "id": "27048",
    "title": "Är VÅGLIG kopplingsskena kompatibel med FAKTUM? ",
    "keywords": [
      "70 lucka",
      "diskmaskin",
      "diskmaskinsfront",
      "faktum",
      "paneldörr",
      "våglig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5g7fb88b-fc76-4551-bg5f-11267bf0efdc",
    "id": "182087",
    "title": "Varför kan jag inte starta min ugn?",
    "keywords": [
      "lampa inuti ugnen",
      "löser ut jordfelbrytare",
      "start av ungen",
      "ställa in klockan",
      "ugnen stänger av elen",
      "ugnen är död efter rengöring",
      "värmer ej"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "087238e2-e510-467b-8c4e-b8c306gb72fd",
    "id": "141759",
    "title": "När jag använder varmluftsfunktionen på min ugn blir maten ojämnt tillagad, vad beror det på? ",
    "keywords": [
      "värmer dåligt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "47d073cd-c604-4b21-b2f0-bf0894df2d3g",
    "id": "141787",
    "title": "Min ugnslucka är smutsig efter att ha genomfört pyrolys, vad beror det på? ",
    "keywords": [
      "inbränt",
      "rengöringsprogram",
      "ränder i ugnsglaset"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g470g027-b017-4d52-gb60-bdgec124238e",
    "id": "121512",
    "title": "Varför medföljer det ingen sladd till min spishäll?",
    "keywords": [
      "anslutningskabel",
      "elsladd",
      "häll",
      "nätsladd",
      "perilex",
      "perilexkontakt",
      "perilexuttag",
      "saknad sladd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "933g06e5-64g5-4b9g-bc35-80f12b78e5d6",
    "id": "181325",
    "title": "Hur rengör jag motorn och insidan av min köksfläkt?",
    "keywords": [
      "Rengöringsmedel till köksfläkten",
      "easy clean",
      "fett",
      "fläkthjul",
      "fläktmotor",
      "kolfilterfläkt",
      "motortvätt",
      "rengöra fläktblad",
      "rengöra motorkåpor",
      "rengöring",
      "rengöring kökfsfläkt",
      "sätta tillbaka filter",
      "återcirkulation"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bb34fbc4-b9dd-48ce-8935-0245efdc488f",
    "id": "143230",
    "title": "Varför bildas kondens i matlagningsutrymmet eller innerrutan på min mikrovågsugn? ",
    "keywords": [
      "kondens i ugnsluckan"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ec7c1621-1d5c-4026-8b33-4geef15f4466",
    "id": "142474",
    "title": "Min fläkt låter högt vid koppling till utsug/frånluft, vad beror det på?",
    "keywords": [
      "det slår i fläkten när det blåser"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bf894fg5-f743-4b9g-8dc4-22650d70971c",
    "id": "141784",
    "title": "Varför samlas kondens på insidan av min ugn/mellan glasen på luckan?",
    "keywords": [
      "avkylning",
      "barnsäkerhet",
      "säkerhet",
      "ugnslucka"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "61cc0gfg-fd86-4844-9e2e-853f05d44784",
    "id": "121531",
    "title": "Kan jag montera min diskmaskin i en METOD köksstomme?",
    "keywords": [
      "Diskmaskinsfront",
      "diskmaskin",
      "metod stommar",
      "montering diskmaskin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "745cg11f-667e-4g16-9g6f-7654c1c2b95b",
    "id": "28217",
    "title": "Skiljer sig djupet på METOD skåp om det monteras med eller utan METOD upphängningsskena? ",
    "keywords": [
      "djup",
      "metod",
      "skena",
      "stomme",
      "upphängningskena",
      "upphängningsskena"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5c333ef8-5ebc-4f93-8717-87d6095fd85d",
    "id": "6974",
    "title": "Vad har de medarbetare som arbetar i SMÅLAND för erfarenhet?",
    "keywords": [
      "erfarenhet",
      "medarbetare",
      "småland"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b94bb1cc-e10f-41d6-gfc6-4c6159b601c1",
    "id": "160820",
    "title": "Behöver jag spärrmåla mitt IVAR skåp innan jag målar det?",
    "keywords": [
      "IVAR",
      "IVAR skåp",
      "diy IVAR",
      "måla",
      "spärrmåla"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "21d441ge-ee6g-441g-bfee-d52b6568642d",
    "id": "58431",
    "title": "Hur är det att jobba på IKEA? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "84ff1bc1-5d48-4gd8-g9e8-9gfc8gggb81c",
    "id": "142604",
    "title": "Min disk får vitaktiga streck/fläckar, eller blåaktiga beläggningar, vad beror det på?",
    "keywords": [
      "diskmaskin sönder",
      "diskmaskin trasig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b377299b-5b82-4005-94eb-d7070ed06c02",
    "id": "142600",
    "title": "Det kommer en lukt från min diskmaskin, vad gör jag?",
    "keywords": [
      "diskmaskin sönder",
      "diskmaskin trasig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8g772gg8-65g6-4e88-gb7c-29b2724d6be1",
    "id": "33524",
    "title": "Kan jag åka buss från centrala Stockholm till IKEA varuhuset i Kungens Kurva? ",
    "keywords": [
      "hur tar jag mig till kungens kurva",
      "ikea bussen",
      "ikeabussen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e316e790-3997-40b0-9c30-ef5g0bbdd03e",
    "id": "33180",
    "title": "Vilka bänkskivor passar till ENHET kök?",
    "keywords": [
      "Enhet",
      "bänkskiva",
      "bänkskivor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2ff7gg13-cf00-41f3-9f2d-g3g14dg7d39f",
    "id": "43467",
    "title": "Kan jag använda gashällen utan el?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c75f0f61-b56d-4b24-9eed-8c908g7de969",
    "id": "141765",
    "title": "Varför rostar min ugn? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "b4d68f51-cb65-44fc-98e1-f39663d9d52c",
    "id": "142481",
    "title": "Matos och ånga sugs inte upp av min fläkt, vad beror det på?",
    "keywords": [
      "fläktkapacitet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8dbc7c38-111f-4g88-g0g6-8336gff08005",
    "id": "142472",
    "title": "Min fläkt med kolfilter låter högt, vad beror det på? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "c102125f-7cd1-4625-geb0-680g73ee6ee3",
    "id": "142471",
    "title": "Det rinner fett ner från min fläkt, vad beror det på?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "2bgd3gc1-51g1-4598-bdf4-7371dbd54g84",
    "id": "31030",
    "title": "Hur får jag bort fläckarna på mitt hällglas?",
    "keywords": [
      "fläck",
      "glas",
      "häll",
      "häll glas",
      "hällglas",
      "missfärgning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "11f49846-1211-4f30-8fgg-33g6g08d23gf",
    "id": "43435",
    "title": "Krävs det att min fläkt är testad för obligatorisk ventilationskontroll (OVK)? ",
    "keywords": [
      "OVK",
      "fläkt",
      "testad"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3gfbffd0-586g-4f2c-817g-d8gg27g8f2fg",
    "id": "30988",
    "title": "Kan jag använda kolfilter till min fläkt? ",
    "keywords": [
      "fläkt",
      "fläktar",
      "kapacitet",
      "köksfläkt",
      "utsugningskapacitet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7bg95dg6-1234-47f2-9efb-g644f230gdb4",
    "id": "43428",
    "title": "Vilken kapacitet behöver min fläkt?",
    "keywords": [
      "fläkt",
      "kapacitet",
      "köksfläkt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "19633e6g-fdbc-42e9-b7g3-53c6f0393d6d",
    "id": "142443",
    "title": "När jag använder min induktionshäll på högsta effektläge stängs den av, vad beror det på?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "61cc5g84-49b2-4gb6-bd1c-0c41b6fg4296",
    "id": "142350",
    "title": "Lågan i min gashäll brinner ojämnt eller för högt, vad beror det på?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "823054b7-7dg6-4b07-8d2e-68b3gd6e9g26",
    "id": "42896",
    "title": "Kan jag placera en kökslåda precis under hällen?",
    "keywords": [
      "Låda under häll",
      "avskiljare",
      "nyttig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "532g1319-gb9f-4dc1-8egc-f6748ff5eb99",
    "id": "33177",
    "title": "Vilken tjocklek behöver bänkskivan ha för att jag ska kunna montera en induktionshäll i mitt ENHET kök?",
    "keywords": [
      "bänkskiva",
      "enhet",
      "häll",
      "induktionshäll"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6838gd7d-6ef0-4441-9762-33c2b0c4e951",
    "id": "8573",
    "title": "Hur ansluter jag min häll till elnätet?",
    "keywords": [
      "installera"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "fe3d7d43-e571-4d6e-8fgb-bgg519018cbb",
    "id": "43519",
    "title": "Varför står det Schott Ceran eller K på glaset till min häll från IKEA? ",
    "keywords": [
      "K",
      "Saint Gobain",
      "electrolux",
      "faber",
      "glaskeramikhäll",
      "häll",
      "hällglas",
      "induktionshäll",
      "schott ceran",
      "whirlpool"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2d5f0807-12c8-45f8-b532-500cg5c92fb8",
    "id": "43465",
    "title": "Hur varmt blir glaset på min häll vid och efter användning?",
    "keywords": [
      "glaskeramikhäll",
      "häll",
      "hällglas",
      "induktionshäll",
      "varmt",
      "värme"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3512ed5f-fd92-4663-b8cg-9dc37b8258d1",
    "id": "43462",
    "title": "Hur rengör jag min häll med keramiskt glas?",
    "keywords": [
      "hällrengöring"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d44g511g-78cc-4d61-bc36-1e7894d444e7",
    "id": "142343",
    "title": "Varför är sidan av min kyl/frys varmare än de övriga delarna? ",
    "keywords": [
      "frysen är varm utanpå",
      "kylskåpet är varmt utanpå"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3d7f3f32-g0d1-4626-b992-g525c2c97g10",
    "id": "141703",
    "title": "Det luktar illa i mitt kylskåp, vad gör jag?",
    "keywords": [
      "illaluktande kyl",
      "kylen stinker",
      "kylskåpet stinker"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3ggd9e47-6fc3-4169-88c3-1d9051355e14",
    "id": "41058",
    "title": "Behöver jag fästbeslag för att montera underbyggnadskyl och frys?",
    "keywords": [
      "beslag",
      "fästbeslag",
      "underbygnadsfrys",
      "underbygnadskyl"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c9f76ffe-f68d-4295-b2g5-65f5f58g5242",
    "id": "41061",
    "title": "Hur fungerar semester-funktionen på kylskåp?",
    "keywords": [
      "semesterfunktion"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "63b81geb-27cc-425e-8df7-gf7b9df2f7ce",
    "id": "27932",
    "title": "Behöver jag såga ut bakstycket i METOD högskåp för kyl eller frys?",
    "keywords": [
      "frys",
      "frysskåp",
      "högskåp",
      "kyl",
      "kylfrys",
      "kylskåp",
      "metod"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "17f00d35-3707-439f-9434-36496951gd63",
    "id": "132322",
    "title": "Behöver jag såga ut i baksidan på METOD bänkskåp för inbyggnadsugn/diskbänk?",
    "keywords": [
      "metod bänkskåp",
      "såga bakstycke",
      "utsågning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3eedgceb-7ffd-4g91-85ec-c5518fecb4fc",
    "id": "143237",
    "title": "Varför går fläkten på min mikrovågsugn igång så fort jag öppnar luckan?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "349g3f0f-e943-4830-8b87-3e2c7f539827",
    "id": "119020",
    "title": "Vilka köksartiklar går bra att använda i mikrovågsugnen?",
    "keywords": [
      "använda i mikro",
      "mikro",
      "mikrougnssäker",
      "mikrovågsugn"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "707fc59f-126f-49g7-8ec2-4258791g92c9",
    "id": "33137",
    "title": "Vart kan jag placera diskmaskinen i mitt ENHET kök?",
    "keywords": [
      "diskmaskin",
      "enhet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "84ge118g-429f-4b5e-g38b-36e44bb46gc4",
    "id": "33136",
    "title": "Kan jag ha delade ENHET fronter på min integrerade diskmaskin?",
    "keywords": [
      "delad front",
      "delad lucka",
      "diskmaskin",
      "enhet",
      "lådfronter"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f1d04eg1-8552-4dc4-bb08-1bc297g235e4",
    "id": "143385",
    "title": "Mina kläder skadas i tvättmaskinen, vad beror det på?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "g0d2cf3f-8e15-41c1-9fe2-4g7g353ec0c1",
    "id": "143283",
    "title": "Min tvättmaskin luktar, vad beror det på?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "96819d80-b3ec-4d8d-80e3-5d82767d9e74",
    "id": "143273",
    "title": "Min tvättmaskin pumpar inte ut vatten ordentligt, vad beror det på? ",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "ded9gf6g-944b-41b5-8f63-0cd2d3769354",
    "id": "35389",
    "title": "Hur kan jag minska slitage och ljudnivå på min tvättmaskin? ",
    "keywords": [
      "tvättmaskin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "4b5580c2-e2e4-4795-9149-69773b683dfe",
    "id": "35408",
    "title": "Varför hoppar min nya tvättmaskin?",
    "keywords": [
      "hoppar",
      "tvättmaskin",
      "tvättmaskin hoppar",
      "vitvara"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0561157c-02gc-4559-b74d-ff8ed88f12be",
    "id": "38104",
    "title": "Varför följer det inte med en kontakt till min lampa?",
    "keywords": [
      "KOPPLA",
      "fast kontakt",
      "ingen kontakt",
      "lampkontakt",
      "lamppropp",
      "saknas kontakt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "d753d364-c3bg-4f61-g354-b907cf433071",
    "id": "35997",
    "title": "Vilka produkter ingår i IKEA Home Smart sortimentet?",
    "keywords": [
      "Home Smart sortiment",
      "Home smart produkter"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0c37b887-979d-473f-bcbd-8g6021263e22",
    "id": "136126",
    "title": "Vad är maxwatten på min ljuskälla?",
    "keywords": [
      "armatur",
      "lampa",
      "lamparmatur",
      "maxwatt",
      "watt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8e8d5c5c-39gd-4415-g860-35fb2ge6510f",
    "id": "15067",
    "title": "Vilken momssats har ni på era produkter? ",
    "keywords": [
      "moms",
      "momssats"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9cgb2998-496d-405e-g1d1-24fe77bceg94",
    "id": "5121",
    "title": "Vilka tider jobbar Hemfixarna?",
    "keywords": [
      "hemfixarna",
      "öppetider"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "15b4898c-fe16-48bg-8g79-7b725c4g0206",
    "id": "5137",
    "title": "Varför skiljer sig IKEA Family erbjudanden mellan olika varuhus?",
    "keywords": [
      "Family",
      "IKEA Family",
      "erbjudande",
      "family erbjudande"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9674bf86-84f6-40g7-86g4-929f4542e576",
    "id": "5146",
    "title": "Varför medföljer inte skruvar eller fästbeslag vid köp av produkter som ska fästas i väggen?",
    "keywords": [
      "beslag",
      "väggbeslag",
      "väggförankring"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2974g625-4d9c-45c4-g992-98f5gd511g06",
    "id": "66783",
    "title": "Varför hittar jag inte produkten när jag söker efter den på er hemsida?",
    "keywords": [
      "ikea hemsida",
      "ikea.se",
      "produktsida"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "614fbd0b-2fc2-4g25-98f6-c36e6e851b90",
    "id": "58317",
    "title": "Var hittar jag mitt närmaste IKEA varuhus? ",
    "keywords": [
      "Adress",
      "Hitta närmsta IKEA",
      "Vägbeskrivning",
      "hitta hit",
      "hur hittar jag till IKEA",
      "mitt närmsta varuhus",
      "var finns ni"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8e4b2166-g385-433c-9212-71d85b2c909f",
    "id": "28130",
    "title": "Vad räknas som kvitto?",
    "keywords": [
      "e kvitto",
      "kvitto",
      "orderbekräftelse",
      "vad är ett kvitto"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e6507deg-d039-4745-bef1-g033fff736g3",
    "id": "132595",
    "title": "Vilken dörrtjocklek passar IKEAs handtag och knoppar till? ",
    "keywords": [
      "Garderob",
      "Garderobsdörr",
      "Handtag",
      "Knopp",
      "PAX"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f56310ec-g4fg-4g9e-9f2g-g5d0b17bg51g",
    "id": "46653",
    "title": "Vad är ett värdekort och hur fungerar det?",
    "keywords": [
      "kampanj",
      "värdekort"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "323281bb-e83f-43g4-gf88-5cg3981de4c1",
    "id": "6762",
    "title": "Ingår installation av IKEA väggplattor i en köksinstallation?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "5f06g839-8g67-4474-9e40-ed43366f7f50",
    "id": "99246",
    "title": "Hur synkar jag TRÅDFRI fjärrkontroll med en ljuskälla?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "09286c25-5f59-48df-g3c7-91351109cb64",
    "id": "4918",
    "title": "Tar er servicepartner av sig skorna vid hembesök?",
    "keywords": [
      "servicepartner",
      "servicetjänster",
      "skor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "8970ff32-7734-4f96-g4d2-0c0f4d4g9bb1",
    "id": "29644",
    "title": "Använder ni flamskyddsmedel i era produkter? ",
    "keywords": [
      "bromerade flamskyddsmedel",
      "flamskyddsmedel",
      "ikea",
      "kemikalier"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "52647414-d4cd-4e22-99ec-d4081g80g5gb",
    "id": "120334",
    "title": "Vad gör jag om det är dåligt tryck på vattnet från min IKEA blandare?",
    "keywords": [
      "Blandare",
      "Dåligt",
      "Filter",
      "Filtret",
      "Gammal",
      "IKEA",
      "Installation",
      "Kalk",
      "Kallt",
      "Kök",
      "Nyinstallerad",
      "På",
      "Strålsamlare",
      "Strålsamlaren",
      "Tryck",
      "VVS",
      "Varm",
      "Varmt",
      "Vatten",
      "Vattnet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b4bbdf38-g159-4ebg-8dg2-1e5f9542864e",
    "id": "120532",
    "title": "Färgen är skavd och trillar bort från min blandare, vad ska jag göra?",
    "keywords": [
      "Blandare",
      "Blandaren",
      "Bort",
      "Delar",
      "Från",
      "IKEA",
      "Kök",
      "Reklamation",
      "Reklamationsavdelning",
      "Skavd",
      "Trilla",
      "Trillar",
      "Vad"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e68744g3-99cg-4772-b0c3-490db3cc6d61",
    "id": "120538",
    "title": "Vad gör jag om min blandare rostar?",
    "keywords": [
      "Blandare",
      "Blandaren",
      "IKEA",
      "Reklamation",
      "Reklamationsavdelning",
      "Rost",
      "Rostar",
      "VVS",
      "VVS:are",
      "Vatten",
      "Vattenledning",
      "Vattenledningar",
      "Vattnet"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "g43d1830-4408-4df6-g326-0gec8bc55fcg",
    "id": "5106",
    "title": "Kan jag lösa in mitt tillgodokort mot kontanter?",
    "keywords": [
      "lösa in",
      "tillgodokort",
      "tillgodokvitto"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e4884132-d245-4089-g067-1e267c36ce37",
    "id": "17845",
    "title": "Kan jag lägga en beställning som skickas så fort produkten är tillbaka i lager?",
    "keywords": [
      "åter i lager"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "950b0d8d-6ccd-4cbe-9467-9bf6bgb5d92g",
    "id": "6803",
    "title": "Kan jag handla med IKEA DELBETALA utomlands?",
    "keywords": [
      "IKEA DELBETALA",
      "delbetala",
      "handla utomlands",
      "ikea utomlands"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7e3123b8-56f6-4072-9g9c-4ee8055700c7",
    "id": "120978",
    "title": "Är HEMMA upphängningssladd jordad?",
    "keywords": [
      "HEMMA",
      "upphägningssladd"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b39e93ge-e524-42d1-gc43-c6d90f59761e",
    "id": "54667",
    "title": "Hur kommer jag i kontakt med IKEA i ett annat land? ",
    "keywords": [
      "ikea danmark",
      "ikea england",
      "ikea finland",
      "ikea frankrike",
      "ikea norge",
      "ikea spanien",
      "ikea tyskland",
      "ikea usa",
      "komma i kontakt med ikea utomlands",
      "kontakta ikea utomlands",
      "utanför sverige",
      "utomlands"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2d85dd57-b335-45f6-9236-cgf7b647gfe2",
    "id": "5103",
    "title": "Kan förpackningar och emballage från IKEA återvinnas?",
    "keywords": [
      "emballage",
      "kartong",
      "återvinna",
      "återvinning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "000fg14g-0d67-4gg2-g966-f35c064be4e7",
    "id": "6801",
    "title": "Kan jag handla med IKEA DELBETALA utan mitt DELBETALA-kort?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "26922942-c9fg-4296-9473-084decf62895",
    "id": "120541",
    "title": "Varför låter min blandare?",
    "keywords": [
      "Av",
      "Blandare",
      "Blandaren",
      "Från",
      "Högfrekvent",
      "Högfrekventa",
      "IKEA",
      "Kök",
      "Ljud",
      "Låter",
      "Reklamation",
      "Reklamationsavdelning",
      "Slag",
      "Stängs",
      "Trycket",
      "VVS",
      "VVS:are",
      "Vattenledning",
      "Vattenledningarna",
      "Ändra",
      "Ändras"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "eg1dg61e-9cc2-406f-9577-9ef27145ff9e",
    "id": "120480",
    "title": "Hur mycket kan jag vrida min blandare?",
    "keywords": [
      "360",
      "Blandare",
      "Grader",
      "Kök",
      "Låsa",
      "Låser",
      "Vrida"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "df4b141f-d1d2-4g05-8049-e55cc8dcd7ge",
    "id": "120341",
    "title": "Varför blir det inte rätt temperatur på vattnet från min blandare?",
    "keywords": [
      "Blandare",
      "Installation",
      "Kallt",
      "Kök",
      "Temperatur",
      "VVS",
      "VVS:are",
      "Varm",
      "Varmt",
      "Vrider"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "12b6f161-6d4f-44ee-g354-b897f37b1f1b",
    "id": "29348",
    "title": "Passar IVAR dörrar i bambu till det vanliga IVAR skåpet? ",
    "keywords": [
      "bambu",
      "dörrar",
      "ivar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "069e6fd6-d3d4-4gb4-9eff-39586b7ffef5",
    "id": "120324",
    "title": "Från vilket avstånd kan jag styra mina smarta rullgardiner?",
    "keywords": [
      "Ansluten",
      "App",
      "Avstånd",
      "FYRTUR",
      "Fjärrkontroll",
      "Fjärrkontrollen",
      "Från",
      "Gateway",
      "Home smart",
      "HomeKit",
      "IKEA",
      "KADRILJ",
      "Kan",
      "Meter",
      "Rullgardiner",
      "Rullgardinerna",
      "Smarta",
      "Styra",
      "TRÅDFRI",
      "Wifi"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6eg59e21-51c0-483g-8827-2e44575d6d7f",
    "id": "120316",
    "title": "Hur ställer jag in maximal neddragning på mina smarta rullgardiner?",
    "keywords": [
      "FYRTUR",
      "Fjärrkontroll",
      "Fjärrkontrollen",
      "Home smart",
      "Hur",
      "KADRILJ",
      "Maximal",
      "Neddragning",
      "Rullgardiner",
      "Smarta",
      "Ställer",
      "elektriska rullgardiner"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dbb9187g-c06f-469c-g824-2726599df0b9",
    "id": "120310",
    "title": "Kan jag fästa fjärrkontrollen till mina smarta rullgardiner på väggen?",
    "keywords": [
      "FYRTUR",
      "Fjärrkontrollen",
      "Fjärrkontrollhållaren",
      "Fästa",
      "Home smart",
      "Hållaren",
      "KADRILJ",
      "På",
      "Rullgardiner",
      "Smarta",
      "Väggen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6g3g75ff-498b-408e-bc5b-d732e6191489",
    "id": "29594",
    "title": "Hur ska jag styra mina smarta rullgardiner?",
    "keywords": [
      "Android",
      "Ansluten",
      "Ansluter",
      "Anvisning",
      "Använder",
      "App Store",
      "Appen",
      "Avstånd",
      "Batteri",
      "Batterilock",
      "Blinkar",
      "Dubbelklicka",
      "Elektriker",
      "Elnätet",
      "Enhet",
      "Enheten",
      "Enheterna",
      "FYRTUR",
      "Fabriksinställningarna",
      "Fast",
      "Fjärrkontroll",
      "Fjärrkontrollen",
      "Flera",
      "Fungerar",
      "Fästa",
      "Gateway",
      "Google Play",
      "Gratis",
      "Hantera",
      "Hastighet",
      "Hastigheter",
      "Hemifrån",
      "HomeKit",
      "Hur",
      "IKEA Home smart",
      "Ihop",
      "Information",
      "Inkluderade",
      "Installera",
      "Installerar",
      "KADRILJ",
      "Klicka",
      "Knapparna",
      "Koppla",
      "Kopplingsknappen",
      "Ladda",
      "Lampa",
      "Leverantörer",
      "Ljus",
      "Manuellt",
      "Maximal",
      "Mellan",
      "Meter",
      "Mina",
      "Mobil",
      "Motoriserade",
      "Ned",
      "Neddragning",
      "Normalt",
      "Paketet",
      "Para",
      "Parar",
      "Parkoppla",
      "Parkoppling",
      "Parkopplingen",
      "Position",
      "Process",
      "På",
      "Rullgardin",
      "Rullgardiner",
      "Röd",
      "Röststyrning",
      "Samma",
      "Sekunder",
      "Signaler",
      "Sken",
      "Smart",
      "Smarta",
      "Stoppa",
      "Styra",
      "Styrning",
      "Ställer",
      "Support",
      "Synkronisera",
      "Synkroniserad",
      "TRÅDFRI",
      "Timer",
      "Tona",
      "Tryck",
      "Trycka",
      "Tryckning",
      "Trådlös",
      "Trådlösa",
      "Upp",
      "Uppladdningsbart",
      "Vitt",
      "Wifi",
      "iOS",
      "Åka",
      "Återställ",
      "Återställer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "57068e3c-d659-4dc3-b17b-fd5c0b7ffg6e",
    "id": "120293",
    "title": "Hur ansluter jag mina smarta rullgardiner till IKEA Home Smart-appen?",
    "keywords": [
      "Ansluter",
      "App Store",
      "Appen",
      "FYRTUR",
      "Google Play",
      "Home smart-appen",
      "Hur",
      "IKEA",
      "Ihop",
      "Jag",
      "KADRILJ",
      "Ladda",
      "Laddar",
      "Lägger",
      "Mobil",
      "Ner",
      "Parar",
      "Rullgardin",
      "Rullgardiner",
      "Smarta",
      "Till"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bb0022cc-2979-4gbg-949d-16c8gb1ccedc",
    "id": "120288",
    "title": "Hur parar jag ihop samma fjärrkontroll med flera FYRTUR eller KADRILJ rullgardiner?",
    "keywords": [
      "FYRTUR",
      "Fjärrkontroll",
      "Flera",
      "Hur",
      "Ihop",
      "Jag",
      "KADRILJ",
      "Med",
      "Mellan",
      "Mina",
      "Para",
      "Parar",
      "Process",
      "Rullgardiner",
      "Rullgardinerna",
      "Samma",
      "Smarta"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "854b2bg4-dggc-4384-8bc5-c9dc1dc5gc9b",
    "id": "120271",
    "title": "Hur tar jag bort parkopplingen mellan mina smarta rullgardiner?",
    "keywords": [
      "Bort",
      "FYRTUR",
      "Hur",
      "Jag",
      "KADRILJ",
      "Mellan",
      "Mina",
      "Para",
      "Parkoppling",
      "Parkopplingen",
      "Rullgardin",
      "Rullgardiner",
      "Smarta",
      "Tar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "18bcb1f4-c10d-4d16-8g0e-c0g5780719b2",
    "id": "39160",
    "title": "Vilken dörr ska handtaget monteras på i PAX hörnlösning?",
    "keywords": [
      "35",
      "58",
      "Cm",
      "Djup",
      "Dörr",
      "Dörrarna",
      "Dörren",
      "Dörrlist",
      "Fritt",
      "Ha",
      "Handtag",
      "Handtaget",
      "Hörnlösning",
      "Kan",
      "Med",
      "Monterad",
      "Monteras",
      "Monteringsanvisningen",
      "Pax",
      "Placering",
      "På",
      "Påbyggnadsdel",
      "Sitta",
      "Stommen",
      "Täcklisten",
      "Valfri",
      "Öppnas"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2419ec9e-19dc-47g8-bfbb-240178dc73c1",
    "id": "119022",
    "title": "Hur kopplar jag min TRÅDFRI rörelsesensor till mitt TRÅDFRI trådlösa uttag?",
    "keywords": [
      "10",
      "Kopplar",
      "Lampa",
      "Min",
      "Mitt",
      "Rörelsesensor",
      "Samtidigt",
      "Sekunder",
      "Sensorn",
      "Synkroniseringsknappen",
      "TRÅDFRI",
      "Till",
      "Trådlösa",
      "Uttag",
      "Uttaget"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0e38b1b4-dc20-4d51-bdg0-206ee344f48f",
    "id": "41440",
    "title": "Vilka fyllnadsmaterial har IKEA i sina kuddar och täcken?",
    "keywords": [
      "fiber",
      "fiberkuddar",
      "fyllnadsmaterial",
      "kuddar",
      "naturkuddar",
      "naturmaterial",
      "täcken"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c6bb08d7-6c24-4c15-9gd2-402d384c2f94",
    "id": "41438",
    "title": "Vilka skötselråd gäller för täcken och kuddar i fibermaterial? ",
    "keywords": [
      "Fibermaterial",
      "Kudde",
      "Täcke"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "19e02ed9-0b55-4b4d-920d-8e73eb29e7b4",
    "id": "41439",
    "title": "Vilka skötselråd gäller för täcken och kuddar i naturmaterial? ",
    "keywords": [
      "kudde",
      "naturmaterial",
      "täcke"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "09b3fb5c-bgdf-4156-b0b3-48b48fc0933g",
    "id": "118839",
    "title": "Kan jag använda en sockel som takanslutning i mitt kök?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "cef70d34-12df-4gg8-94f0-69gdd45c4g33",
    "id": "33333",
    "title": "I vilka färger finns ENHET sockel?",
    "keywords": [
      "ENHET",
      "ben",
      "sockel"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f0g96g54-5890-4f23-ge3e-cg181e72342b",
    "id": "37800",
    "title": "Kan jag använda metallredskap i teflonkärl?",
    "keywords": [
      "teflon"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "be188c1b-b6d4-440e-bf8e-975cf3b635e0",
    "id": "28248",
    "title": "Varför bytte IKEA köksystem från FAKTUM till METOD? ",
    "keywords": [
      "faktum",
      "metod",
      "skillnad"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "ee354g5f-f7dc-4g65-g1bc-0g586e0c4g3b",
    "id": "43524",
    "title": "Är keramiskt glas härdat?",
    "keywords": [
      "härdat",
      "keramiskt glas"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "68gdg94f-geb3-4cb6-8e14-2f219fe4b990",
    "id": "117305",
    "title": "Hur kopplar jag ÅSKVÄDER med en styrenhet?",
    "keywords": [
      "åskväder"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "31fgfce6-091f-4b55-940c-8cgd6f7g220e",
    "id": "38342",
    "title": "Vilka routrar är kompatibla med TRÅDFRI? ",
    "keywords": [
      "router",
      "routrar"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6c2797b9-4cc4-4e31-99gd-6e678885g6g6",
    "id": "36079",
    "title": "Har smarta belysningsprodukter från IKEA en minnesfunktion?",
    "keywords": [
      "Minne",
      "Minnesfunktion"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "2gg976ed-102g-4gbd-bgb8-7ccf1cf5b0d6",
    "id": "116624",
    "title": "Kan individuella TRÅDFRI-ljuskällor ha olika ljusstyrkor?",
    "keywords": [
      "Individuella ljuskällor",
      "Olika ljusstyrka",
      "ljusstyrka"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "06e3cf07-1db2-4094-8g99-8352g0gd820g",
    "id": "29225",
    "title": "Vilken ljuskälla ska jag välja?",
    "keywords": [
      "Dimma",
      "Ej",
      "LEDARE",
      "LUNNMON",
      "Livslängd",
      "Ljuskällan",
      "Ljuskällor",
      "Läsa",
      "RYET",
      "Sken",
      "Skillnaden",
      "TRÅDFRI",
      "Tänd",
      "Varmt sken",
      "Varmvitt"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cf46d068-bbc1-4df2-9342-940800f8f80b",
    "id": "114971",
    "title": "Var hittar jag versionsnumret på IKEA Home smart-appen?",
    "keywords": [
      "Home smart",
      "app",
      "home smart app",
      "versionsnummer"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f195d864-6g80-467c-g1fe-c9f502edb495",
    "id": "29320",
    "title": "Kan jag köpa LED-ljuskällor till alla lampor i IKEAs sortiment?",
    "keywords": [
      "100%",
      "Belysningssortiment",
      "Energi",
      "Förbrukar",
      "Glödlampor",
      "Inbyggda",
      "Koldioxidutsläpp",
      "LED-lampor",
      "LED-ljuskällor",
      "LEDARE",
      "Lampor",
      "Ljusdioder",
      "RYET",
      "TRÅDFRI"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "307gg742-901b-4f19-g6b0-42cbe77beg39",
    "id": "38346",
    "title": "Vilka lampor är kompatibla med TRÅDFRI?",
    "keywords": [
      "Dimmer",
      "Fungerar",
      "Inbyggd",
      "Kompatibla",
      "Lampor",
      "Ljuskälla",
      "TRÅDFRI"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "10c1f7dd-g746-4g3b-8d51-d5613457bef6",
    "id": "32404",
    "title": "Vad kan jag göra i IKEA Home smart-appen?",
    "keywords": [
      "Byta låt",
      "IKEA Home smart-appen",
      "Justera",
      "Kontrolluttaget",
      "Luftrenare",
      "Styra",
      "Ställa in",
      "Ändra volym"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "1eb83gg3-c81f-4393-bgc1-gf1904fcc6e9",
    "id": "36083",
    "title": "Hur installerar jag en uppdatering i IKEA Home smart-appen?",
    "keywords": [
      "IKEA Home smart-appen",
      "Notis",
      "Uppdatering"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "3gddc22g-21b0-457b-9f46-3632e2d39d93",
    "id": "33129",
    "title": "Jag har ett system utan gateway och vill ansluta en TRÅDFRI gateway, visas mina nuvarande smarta belysningsprodukter från IKEA automatiskt i IKEA Home smart-appen?",
    "keywords": [
      "Gateway",
      "IKEA Home smart-appen"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "cc231g2f-g030-4gfc-8d2d-16d7f1b65f05",
    "id": "38417",
    "title": "Hur skiljer sig IKEA SYMFONISK från en vanlig Sonos-högtalare?",
    "keywords": [
      "Symfonisk",
      "sonos"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "07587710-ff37-4d17-gbdb-7d00316ee8fg",
    "id": "29565",
    "title": "Behövs det en elektriker för att installera de smarta rullgardinerna?",
    "keywords": [
      "elektriker",
      "fyrtur",
      "kadrilj",
      "rullgardin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c591g23d-7e68-43cc-93fe-3g3g77e01410",
    "id": "29568",
    "title": "De smarta rullgardinerna har olika hastigheter i hur snabbt de går ner och upp, är det normalt?",
    "keywords": [
      "Fyrtur",
      "kadrilj"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "20bfe9g4-de61-496g-98g8-803323687646",
    "id": "29592",
    "title": "Hur många smarta rullgardiner kan anslutas till en och samma fjärrkontroll?",
    "keywords": [
      "fyrtur",
      "hur många",
      "kadrilj",
      "parkoppla",
      "rullgardin"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "03fg5cd3-f413-415d-b0e8-c462d590g00d",
    "id": "29597",
    "title": "Jag har kopplat ihop signalförstärkaren med FYRTUR eller KADRILJ men inget händer, vad gör jag?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "932gb7gb-f0dc-4319-89g8-dgf00bf20cd4",
    "id": "29595",
    "title": "Hur styr jag de smarta rullgardinerna FYRTUR och KADRILJ med fjärrkontrollen?",
    "keywords": [
      "FYRTUR",
      "KADRILJ",
      "smarta rullgardiner"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "99b85b6d-c3b6-4fdb-bd11-605gf607e717",
    "id": "29591",
    "title": "Hur lång tid tar det att ladda batteriet till FYRTUR och KADRILJ?",
    "keywords": [
      "batteri",
      "fyrtur",
      "kadrilj",
      "smart rullgardin",
      "smarta rullgardiner"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "30bfbgf1-8bc2-401b-99e4-17325c7265fe",
    "id": "29599",
    "title": "Vad händer om batteriet för smarta rullgardiner tar slut innan det används?",
    "keywords": [
      "Batteri",
      "fyrtur",
      "kadrilj"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e70079e2-cdcd-43ef-9gd2-3e242g8eg886",
    "id": "29606",
    "title": "Kan jag röststyra de smarta rullgardinerna FYRTUR och KADRILJ?",
    "keywords": [
      "Fyrtur",
      "Kadrilj",
      "alexa",
      "apple homekit",
      "google",
      "röststyra",
      "röststyrning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "b5b6b583-8585-4606-bb63-b952b9f1cdb4",
    "id": "23057",
    "title": "Kan jag få hjälp med att lasta mina varor i min bil eller släpvagn på varuhuset?",
    "keywords": [
      "Släpvagn",
      "bär hjälp",
      "bärhjälp",
      "lasta bilen",
      "lyfta",
      "packa bilen",
      "släpkärra"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "9d109541-1740-4b26-b741-99968e3dfd38",
    "id": "96984",
    "title": "Varför är botten på mitt kokkärl ojämnt?",
    "keywords": [
      "ojämn gryta",
      "ojämn kastrull",
      "ojämn stekpanna"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f55f3f39-f1db-4b4f-921d-373355f04969",
    "id": "25832",
    "title": "Varför har IKEA slutat producera IKEA katalogen?",
    "keywords": [
      "digital katalog",
      "e-katalog",
      "ikeakatalog",
      "ikeakatalogen",
      "online katalog",
      "onlinekatalog"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "bb9e6936-gc80-4077-99e6-0bg87e37731d",
    "id": "100891",
    "title": "Hur rengör jag mina köksluckor från IKEA?",
    "keywords": [
      "kundsvar",
      "köksluckor",
      "rengöra köksluckor"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c243e225-031b-4b49-9b70-5186dd6d0e9e",
    "id": "88613",
    "title": "Går det att ersätta ATLANT diskhopropp med en diskhopropp från sortimentet som finns idag?",
    "keywords": [
      "atlant",
      "diskho",
      "diskhopropp"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "e27b55e2-g139-4173-b5ec-056f13c7647b",
    "id": "5866",
    "title": "Varför ingår inte dryck i glas vid köp av maträtt i restaurangen?",
    "keywords": [
      "resturang"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "46g84g6d-8417-4358-g870-286b44bc114f",
    "id": "5862",
    "title": "Varför kan jag inte beställa en halv portion i restaurangen?",
    "keywords": [
      "resturang"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f2c86d1f-6312-4108-9853-38907490g57b",
    "id": "29650",
    "title": "Produkten som jag precis köpt har en obehaglig lukt, ska det vara så?",
    "keywords": [
      "illaluktande produkt",
      "illaluktande produkter",
      "madrass luktar",
      "skadlig",
      "stinker",
      "är doften farlig",
      "är lukten farlig"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "7f44g6b3-25c8-494c-gg92-0eecgf516904",
    "id": "8143",
    "title": "Var meddelar jag min adressändring?",
    "keywords": [
      "Jag har flyttat",
      "Ny adress",
      "byta adress",
      "bytt adress",
      "fel adress",
      "flytt till ny adress"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "404d261c-902d-4953-8205-07576g858c93",
    "id": "17803",
    "title": "Var hittar jag måtten för en viss produkt? ",
    "keywords": [
      "bredd",
      "djup",
      "emballage",
      "förpackning storlek",
      "förpackningsmått",
      "går förpackningen in i bilen",
      "hur stor",
      "hur stor är förpackningen",
      "höjd",
      "längd",
      "mått på emballage",
      "mått på förpackning",
      "paket storlek",
      "storlek",
      "storlek förpackning"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "157243g0-2302-42f8-958b-693c211d4c07",
    "id": "5136",
    "title": "Finns det gratis Wi-Fi på alla IKEA varuhus i Sverige? ",
    "keywords": [
      "gratis internet",
      "internet",
      "kostnadsfritt wi-fi",
      "kostnadsfritt wifi",
      "uppkoppling",
      "wifi"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "c82f76g9-gc9g-4g35-b8fd-917gd8945069",
    "id": "60464",
    "title": "Hur hanterar IKEA mina personuppgifter? ",
    "keywords": [
      "GDPR",
      "behandling av personuppgifter",
      "hur länge lagras data",
      "hur samlar ni in data",
      "integritet",
      "mina personuppgifter",
      "personlig integritet",
      "personliga uppgifter",
      "vilken data sparar ni"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "36621965-146d-4ee3-bf8g-c30cc6770bd2",
    "id": "60149",
    "title": "Jag är journalist eller representerar media, hur kommer jag i kontakt med IKEAs pressjour?",
    "keywords": [
      "media",
      "pr",
      "press",
      "pressjour",
      "pressrum"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "dc184272-0ccd-411d-8741-3c917e47e7c3",
    "id": "17797",
    "title": "Var hittar jag skötselråden för min produkt? ",
    "keywords": [
      "Sköta om",
      "rengöra",
      "skötsel soffa",
      "skötselråd",
      "ta hand om",
      "tvättråd",
      "tvättråd soffa",
      "vårda"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "6499b6cf-82f8-44b8-9849-3c751fb6c64f",
    "id": "58011",
    "title": "Hur gammal måste jag vara för att beställa?",
    "keywords": [
      "barn",
      "myndig",
      "Åldersgräns"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "f5361c7b-533f-4753-gb4f-c101380431ec",
    "id": "55090",
    "title": "Kan vi göra studiebesök på IKEA? ",
    "keywords": [
      "besöka ikea med skolan",
      "ikea ab",
      "ikea communications",
      "ikea of sweden",
      "ikea älmhult",
      "ios",
      "studiebesök"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "0g55gb7e-be65-4gbc-8fc3-53227fd52ddb",
    "id": "5150",
    "title": "Hur betalar jag för tjänsten Hemfixarna?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "5385e9e9-6153-479f-8589-b8d24e84908b",
    "id": "5085",
    "title": "Vad är Hemfixarna?",
    "keywords": [
      "svårt att få tag i hemfixare"
    ],
    "marketCode": "SE"
  },
  {
    "guid": "5303g315-b15g-41e7-g148-bd2de038c9d5",
    "id": "17800",
    "title": "Hur ser jag lagersaldo på ett varuhus i annat land?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "bd5b5g0c-32c1-468d-8b82-f2fd23ce26b9",
    "id": "19169",
    "title": "Är det möjligt att använda era planeringsverktyg i IKEA appen?",
    "keywords": [],
    "marketCode": "SE"
  },
  {
    "guid": "58239d45-1c64-4g1d-9150-54b1236cb22g",
    "id": "29570",
    "title": "Varför finns artikeln inte på mitt varuhus?",
    "keywords": [
      "ej fullsortiment",
      "fullsortiment",
      "mindre varuhus"
    ],
    "marketCode": "SE"
  }
]